define(["require", "exports", "jquery"], function (require, exports, $) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CtiClock = void 0;
    var CtiClock = (function () {
        function CtiClock(elementId) {
            this.ctiToken = 'ORACLE_OSVC_CTI';
            this.callDuration = '00:00:00';
            this.isRunning = false;
            this.elementId = elementId;
        }
        CtiClock.prototype.startClock = function () {
            var _this = this;
            this.callStartTime = new Date();
            this.isRunning = true;
            if (typeof (Worker) !== "undefined") {
                this.worker = new Worker('../scripts/util/ctiClockWorker.js');
                this.worker.onmessage = function (event) {
                    if (event && event.data) {
                        var data = JSON.parse(event.data);
                        if (data.token === _this.ctiToken) {
                            _this.callDuration = data.duration;
                            _this.callLength = data.duration;
                            $('#' + _this.elementId).html(data.duration);
                        }
                    }
                };
                this.worker.postMessage(JSON.stringify({ token: this.ctiToken, command: 'START' }));
            }
        };
        CtiClock.prototype.resetUI = function () {
            $('#' + this.elementId).html(this.callDuration);
        };
        CtiClock.prototype.stopClock = function () {
            if (this.isRunning) {
                this.worker.terminate();
                this.callEndTime = new Date();
                this.callLength = this.callDuration;
                this.callDuration = '00:00:00';
                $('#' + this.elementId).html(this.callLength);
                this.isRunning = false;
            }
        };
        CtiClock.prototype.getCallLength = function () {
            return this.callLength;
        };
        CtiClock.prototype.getClockStartTime = function () {
            return this.callStartTime;
        };
        CtiClock.prototype.getClockEndTime = function () {
            return this.callEndTime ? this.callEndTime : new Date();
        };
        return CtiClock;
    }());
    exports.CtiClock = CtiClock;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3RpQ2xvY2suanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjdGlDbG9jay50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0lBU0E7UUFVSSxrQkFBbUIsU0FBaUI7WUFKNUIsYUFBUSxHQUFXLGlCQUFpQixDQUFDO1lBQ3JDLGlCQUFZLEdBQVcsVUFBVSxDQUFDO1lBQ2xDLGNBQVMsR0FBWSxLQUFLLENBQUM7WUFHL0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7UUFDL0IsQ0FBQztRQUVNLDZCQUFVLEdBQWpCO1lBQUEsaUJBa0JDO1lBakJHLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUNoQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztZQUN0QixJQUFHLE9BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxXQUFXLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUMsbUNBQW1DLENBQUMsQ0FBQztnQkFDOUQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEdBQUcsVUFBQyxLQUFVO29CQUMvQixJQUFHLEtBQUssSUFBSSxLQUFLLENBQUMsSUFBSSxFQUFDO3dCQUNuQixJQUFJLElBQUksR0FBUSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDdkMsSUFBRyxJQUFJLENBQUMsS0FBSyxLQUFLLEtBQUksQ0FBQyxRQUFRLEVBQUM7NEJBQzVCLEtBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQzs0QkFDbEMsS0FBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDOzRCQUNoQyxDQUFDLENBQUMsR0FBRyxHQUFDLEtBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3lCQUM3QztxQkFDSjtnQkFDTCxDQUFDLENBQUM7Z0JBRUYsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUMsQ0FBQyxDQUFDLENBQUM7YUFDckY7UUFDTCxDQUFDO1FBRU0sMEJBQU8sR0FBZDtZQUNJLENBQUMsQ0FBQyxHQUFHLEdBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDbEQsQ0FBQztRQUVNLDRCQUFTLEdBQWhCO1lBQ0ksSUFBRyxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUNmLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ3hCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDOUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO2dCQUNwQyxJQUFJLENBQUMsWUFBWSxHQUFHLFVBQVUsQ0FBQztnQkFDL0IsQ0FBQyxDQUFDLEdBQUcsR0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDNUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7YUFDMUI7UUFDTCxDQUFDO1FBT00sZ0NBQWEsR0FBcEI7WUFDSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUM7UUFDM0IsQ0FBQztRQU1NLG9DQUFpQixHQUF4QjtZQUNJLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUM5QixDQUFDO1FBT00sa0NBQWUsR0FBdEI7WUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUEsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFFLENBQUM7UUFDM0QsQ0FBQztRQUNMLGVBQUM7SUFBRCxDQUFDLEFBMUVELElBMEVDO0lBMUVZLDRCQUFRIiwic291cmNlc0NvbnRlbnQiOlsiLyogKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgJEFDQ0VMRVJBVE9SX0hFQURFUl9QTEFDRV9IT0xERVIkXG4gKiAgU0hBMTogJElkOiBiM2MwN2ZmMjc1MGU3YjY5M2Q0NzdlMjIzMTVjYTI3Y2UyZWM4NTkwICRcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogIEZpbGU6ICRBQ0NFTEVSQVRPUl9IRUFERVJfRklMRV9OQU1FX1BMQUNFX0hPTERFUiRcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xuXG5pbXBvcnQgJCA9IHJlcXVpcmUoJ2pxdWVyeScpO1xuXG5leHBvcnQgY2xhc3MgQ3RpQ2xvY2sge1xuICAgIHByaXZhdGUgd29ya2VyOiBXb3JrZXI7XG4gICAgcHJpdmF0ZSBlbGVtZW50SWQ6IHN0cmluZztcbiAgICBwcml2YXRlIGNhbGxMZW5ndGg6IHN0cmluZztcbiAgICBwcml2YXRlIGNhbGxTdGFydFRpbWU6IERhdGU7XG4gICAgcHJpdmF0ZSBjYWxsRW5kVGltZTogRGF0ZTtcbiAgICBwcml2YXRlIGN0aVRva2VuOiBzdHJpbmcgPSAnT1JBQ0xFX09TVkNfQ1RJJztcbiAgICBwcml2YXRlIGNhbGxEdXJhdGlvbjogc3RyaW5nID0gJzAwOjAwOjAwJztcbiAgICBwcml2YXRlIGlzUnVubmluZzogYm9vbGVhbiA9IGZhbHNlO1xuICAgIFxuICAgIHB1YmxpYyBjb25zdHJ1Y3RvcihlbGVtZW50SWQ6IHN0cmluZykge1xuICAgICAgICB0aGlzLmVsZW1lbnRJZCA9IGVsZW1lbnRJZDtcbiAgICB9XG5cbiAgICBwdWJsaWMgc3RhcnRDbG9jaygpOiB2b2lkIHtcbiAgICAgICAgdGhpcy5jYWxsU3RhcnRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgdGhpcy5pc1J1bm5pbmcgPSB0cnVlO1xuICAgICAgICBpZih0eXBlb2YoV29ya2VyKSAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgdGhpcy53b3JrZXIgPSBuZXcgV29ya2VyKCcuLi9zY3JpcHRzL3V0aWwvY3RpQ2xvY2tXb3JrZXIuanMnKTtcbiAgICAgICAgICAgIHRoaXMud29ya2VyLm9ubWVzc2FnZSA9IChldmVudDogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYoZXZlbnQgJiYgZXZlbnQuZGF0YSl7XG4gICAgICAgICAgICAgICAgICAgIHZhciBkYXRhOiBhbnkgPSBKU09OLnBhcnNlKGV2ZW50LmRhdGEpO1xuICAgICAgICAgICAgICAgICAgICBpZihkYXRhLnRva2VuID09PSB0aGlzLmN0aVRva2VuKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2FsbER1cmF0aW9uID0gZGF0YS5kdXJhdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2FsbExlbmd0aCA9IGRhdGEuZHVyYXRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAkKCcjJyt0aGlzLmVsZW1lbnRJZCkuaHRtbChkYXRhLmR1cmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHRoaXMud29ya2VyLnBvc3RNZXNzYWdlKEpTT04uc3RyaW5naWZ5KHt0b2tlbjogdGhpcy5jdGlUb2tlbiwgY29tbWFuZDogJ1NUQVJUJ30pKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHB1YmxpYyByZXNldFVJKCk6dm9pZCB7XG4gICAgICAgICQoJyMnK3RoaXMuZWxlbWVudElkKS5odG1sKHRoaXMuY2FsbER1cmF0aW9uKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgc3RvcENsb2NrKCk6IHZvaWQge1xuICAgICAgICBpZih0aGlzLmlzUnVubmluZykge1xuICAgICAgICAgICAgdGhpcy53b3JrZXIudGVybWluYXRlKCk7XG4gICAgICAgICAgICB0aGlzLmNhbGxFbmRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgIHRoaXMuY2FsbExlbmd0aCA9IHRoaXMuY2FsbER1cmF0aW9uO1xuICAgICAgICAgICAgdGhpcy5jYWxsRHVyYXRpb24gPSAnMDA6MDA6MDAnO1xuICAgICAgICAgICAgJCgnIycrdGhpcy5lbGVtZW50SWQpLmh0bWwodGhpcy5jYWxsTGVuZ3RoKTtcbiAgICAgICAgICAgIHRoaXMuaXNSdW5uaW5nID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUaGlzIG1ldGhvZCByZXR1cm5zIHRoZSBjYWxsIGR1cmF0aW9uIGFzIGEgc3RyaW5nXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyB7c3RyaW5nfVxuICAgICAqL1xuICAgIHB1YmxpYyBnZXRDYWxsTGVuZ3RoKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiB0aGlzLmNhbGxMZW5ndGg7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVGhpcyBtZXRob2QgcmV0dXJucyB0aGUgc3RhcnQgdGltZSBvZiB0aGUgY2xvY2sgYXMgYSBkYXRlIG9iamVjdFxuICAgICAqIEByZXR1cm5zIHtEYXRlfVxuICAgICAqL1xuICAgIHB1YmxpYyBnZXRDbG9ja1N0YXJ0VGltZSgpOiBEYXRlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY2FsbFN0YXJ0VGltZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBUaGlzIG1ldGhvZCByZXR1cm5zIHRoZSBlbmQgdGltZSBvZiBjbG9jayBhcyBhIGRhdGUgb2JqZWN0XG4gICAgICpcbiAgICAgKiBAcmV0dXJucyB7RGF0ZX1cbiAgICAgKi9cbiAgICBwdWJsaWMgZ2V0Q2xvY2tFbmRUaW1lKCk6IERhdGUge1xuICAgICAgICByZXR1cm4gdGhpcy5jYWxsRW5kVGltZT8gdGhpcy5jYWxsRW5kVGltZSA6IG5ldyBEYXRlKCk7XG4gICAgfVxufSJdfQ==