define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AgentProfile = void 0;
    var AgentProfile = (function () {
        function AgentProfile() {
        }
        return AgentProfile;
    }());
    exports.AgentProfile = AgentProfile;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWdlbnRQcm9maWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYWdlbnRQcm9maWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7SUFPQTtRQUFBO1FBSUEsQ0FBQztRQUFELG1CQUFDO0lBQUQsQ0FBQyxBQUpELElBSUM7SUFKWSxvQ0FBWSIsInNvdXJjZXNDb250ZW50IjpbIi8qICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICRBQ0NFTEVSQVRPUl9IRUFERVJfUExBQ0VfSE9MREVSJFxuICogIFNIQTE6ICRJZDogMzczYTBmYWNlMGEwMWVmOGMzZDM5NTgxZjRmOGMxNjBmMzJhNzNmMyAkXG4gKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICBGaWxlOiAkQUNDRUxFUkFUT1JfSEVBREVSX0ZJTEVfTkFNRV9QTEFDRV9IT0xERVIkXG4gKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogKi9cblxuZXhwb3J0IGNsYXNzIEFnZW50UHJvZmlsZSB7XG4gIGludGVyZmFjZVVybDogc3RyaW5nO1xuICBhY2NvdW50SWQ6IHN0cmluZztcbiAgc2Vzc2lvbklkOiBzdHJpbmc7XG59XG4iXX0=