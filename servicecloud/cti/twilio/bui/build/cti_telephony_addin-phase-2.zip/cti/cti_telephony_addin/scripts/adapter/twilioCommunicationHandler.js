define(["require", "exports", "./serverEventHandler", "jquery", "../util/ctiConstants", "../util/ctiLogger", "../util/ctiMessages"], function (require, exports, serverEventHandler_1, $, ctiConstants_1, ctiLogger_1, ctiMessages_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.TwilioCommunicationHandler = void 0;
    var TwilioCommunicationHandler = (function () {
        function TwilioCommunicationHandler() {
            var _this = this;
            this.activities = {};
            this.loggedIn = false;
            this.firstLogin = true;
            this.logPreMessage = 'TwilioCommunicationHandler' + ctiMessages_1.CtiMessages.MESSAGE_APPENDER;
            this.initializeTwilioDevice = function (data) {
                _this.dequeueConfigId = data.config.number;
                _this.deviceToken = data.device;
                _this.workerToken = data.worker;
                _this.routes = data.config.routes;
                _this.ICE = data.ICE;
                if (_this.firstLogin) {
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                        ctiMessages_1.CtiMessages.MESSAGE_DEVICE_INITIALIZE);
                    Twilio.Device.setup(_this.deviceToken, {
                        iceServers: data.ICE
                    });
                    Twilio.Device.incoming(function (conn) {
                        ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                            ctiMessages_1.CtiMessages.MESSAGE_INCOMING_CONNECTION + conn.parameters.From);
                        conn.accept();
                    });
                    Twilio.Device.connect(function (conn) {
                        ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                            ctiMessages_1.CtiMessages.MESSAGE_CONNECTION_ESTABLISHED);
                        var data = {
                            contact: _this.contactInfo,
                            incident: _this.incidentId,
                            hangup: function () {
                                conn.disconnect();
                                _this.updateActivity("Ready");
                            },
                            mute: function (flag) {
                                conn.mute(flag);
                            }
                        };
                        _this.callSid = conn.parameters.CallSid;
                        _this.serverEventHandler.despatch("connected", data);
                    });
                    Twilio.Device.disconnect(function (conn) {
                        ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                            ctiMessages_1.CtiMessages.MESSAGE_CONNECTION_BROKE);
                        _this.attributes = null;
                        _this.incidentId = null;
                        _this.updateActivity("Ready");
                        _this.serverEventHandler.despatch("disconnected", {});
                    });
                }
                if (_this.workerToken == null) {
                    throw ("Worker token is null. Cannot provide access to Twilio for this user.");
                }
                _this.worker = new Twilio.TaskRouter.Worker(_this.workerToken);
                _this.worker.on("ready", function (worker) {
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage + "Worker " + worker.friendlyName + " is ready");
                    _this.loggedIn = true;
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                        ctiMessages_1.CtiMessages.MESSAGE_DISPATCH_LOGIN_SUCCESS);
                    _this.serverEventHandler.despatch('login.success', name);
                    _this.updateActivity("Ready");
                });
                _this.worker.on("reservation.created", function (reservation) {
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                        ctiMessages_1.CtiMessages.MESSAGE_RESERVATION_CREATED);
                    _this.reservation = reservation;
                    var phone = reservation.task.attributes.from;
                    _this.attributes = reservation.task.attributes;
                    phone = phone.replace("client:", "");
                    var timeout = 30;
                    var contact = reservation.task.attributes.contact;
                    _this.incidentId = reservation.task.attributes.incident;
                    contact['name'] = contact.firstName + " " + contact.lastName;
                    _this.contactInfo = contact;
                    var data = {
                        timeout: timeout,
                        accept: function () {
                            clearTimeout(_this.timeoutHandle);
                            reservation.dequeue(_this.dequeueConfigId);
                        },
                        reject: function () {
                            clearTimeout(_this.timeoutHandle);
                            _this.attributes = null;
                            _this.incidentId = null;
                            reservation.reject();
                        }
                    };
                    data["contact"] = contact;
                    _this.timeoutHandle = setTimeout(function () {
                        _this.serverEventHandler.despatch("timeout", {});
                        if (_this.reservation) {
                            _this.reservation.reject();
                            _this.reservation = null;
                        }
                        _this.attributes = null;
                        _this.incidentId = null;
                    }, timeout * 1000);
                    _this.serverEventHandler.despatch("incoming", data);
                });
                _this.worker.on("reservation.canceled", function (reservation) {
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                        ctiMessages_1.CtiMessages.MESSAGE_RESERVATION_CANCELLED);
                    _this.attributes = null;
                    _this.incidentId = null;
                    clearTimeout(_this.timeoutHandle);
                    _this.serverEventHandler.despatch("canceled", {});
                });
                _this.worker.on("reservation.accepted", function (reservation) {
                    clearTimeout(_this.timeoutHandle);
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                        ctiMessages_1.CtiMessages.MESSAGE_RESERVATION_ACCEPTED);
                });
                _this.worker.on("reservation.rejected", function (reservation) {
                    clearTimeout(_this.timeoutHandle);
                    _this.attributes = null;
                    _this.incidentId = null;
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                        ctiMessages_1.CtiMessages.MESSAGE_RESERVATION_REJECTED);
                    _this.serverEventHandler.despatch("canceled", {});
                });
                _this.worker.on("token.expired", function () {
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                        ctiMessages_1.CtiMessages.MESSAGE_TOKEN_EXPIRED);
                    _this.serverEventHandler.despatch('token.expired', {});
                });
                _this.worker.on("activity.update", function (worker) {
                    _this.serverEventHandler.despatch('activity.update', worker.activityName);
                });
                _this.worker.activities.fetch(function (error, activityList) {
                    if (error) {
                        ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage + error.code);
                        ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage + error.message);
                        return;
                    }
                    var data = activityList.data;
                    for (var i = 0; i < data.length; i++) {
                        _this.activities[data[i].friendlyName] = data[i].sid;
                    }
                    _this.worker.update("ActivitySid", _this.activities["Ready"], function (error, worker) {
                        if (error) {
                            ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage + error.code);
                            ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage + error.message);
                        }
                        else {
                            ctiLogger_1.CtiLogger.logInfoMessage(worker.activityName);
                        }
                    });
                });
            };
            this.serverEventHandler = new serverEventHandler_1.ServerEventHandler();
        }
        TwilioCommunicationHandler.prototype.login = function (serverURI, sessionId, agentId) {
            var _this = this;
            this.sessionId = sessionId;
            this.agentId = agentId;
            this.serverURI = serverURI.replace(/\/$/, "");
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_LOGIN);
            $.ajax({
                url: this.serverURI + "/login",
                type: "POST",
                data: {
                    session_id: this.sessionId
                },
                dataType: "JSON"
            })
                .done(function (data) {
                if (data && !data.success) {
                    ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_LOGIN_ERROR_DEVICE +
                        JSON.stringify(data));
                    _this.serverEventHandler.despatch('login.failed', data);
                    return;
                }
                try {
                    _this.initializeTwilioDevice(data);
                    _this.firstLogin = false;
                }
                catch (exception) {
                    ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage +
                        ctiMessages_1.CtiMessages.MESSAGE_EVENT_DISPATCH + JSON.stringify(exception));
                    _this.serverEventHandler.despatch('login.failed', {});
                }
            })
                .fail(function (failureMessage) {
                ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage +
                    ctiMessages_1.CtiMessages.MESSAGE_LOGIN_FAILURE + JSON.stringify(failureMessage));
                _this.serverEventHandler.despatch('login.failed', name);
            });
        };
        TwilioCommunicationHandler.prototype.logout = function () {
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_LOGOUT);
            this.updateActivity(ctiConstants_1.CtiConstants.NOT_AVAILABLE);
            this.workerName = null;
            this.worker = null;
            this.sessionId = null;
            this.agentId = null;
            this.loggedIn = false;
        };
        TwilioCommunicationHandler.prototype.updateActivity = function (name) {
            var _this = this;
            if (!this.loggedIn) {
                throw (ctiMessages_1.CtiMessages.MESSAGE_NOT_LOGGEDIN_FOR_ACTION);
            }
            if (name in this.activities) {
                ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage +
                    ctiMessages_1.CtiMessages.MESSAGE_REQUEST_ACTIVITY_UPDATE +
                    ctiMessages_1.CtiMessages.MESSAGE_APPENDER + name);
                this.worker.update("ActivitySid", this.activities[name], function (error, worker) {
                    if (error) {
                        ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage +
                            ctiMessages_1.CtiMessages.MESSAGE_ACTIVITY_UPDATE_ERROR + JSON.stringify(error));
                    }
                    else {
                        ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage + worker.activityName);
                    }
                });
            }
        };
        TwilioCommunicationHandler.prototype.getServerEventHandler = function () {
            return this.serverEventHandler;
        };
        TwilioCommunicationHandler.prototype.searchContact = function (contact, sessionId) {
            var _this = this;
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage +
                ctiMessages_1.CtiMessages.MESSAGE_CONTACT_SEARCH +
                ctiMessages_1.CtiMessages.MESSAGE_APPENDER + contact);
            $.ajax({
                url: this.serverURI + '/searchPhone',
                type: 'POST',
                data: {
                    phone: contact,
                    session_id: sessionId
                }
            }).done(function (searchResult) {
                ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                    ctiMessages_1.CtiMessages.MESSAGE_CONTACT_SEARCH_SUCCESS +
                    ctiMessages_1.CtiMessages.MESSAGE_APPENDER + searchResult);
                var searchResultJson = JSON.parse(searchResult);
                _this.dialedContact = searchResultJson.contact;
                _this.serverEventHandler.despatch('search.contact.complete', searchResultJson);
            }).fail(function (message) {
                ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage + 'Contact search failed >> ' + message);
                _this.serverEventHandler.despatch('search.contact.failed', { success: false });
            });
        };
        TwilioCommunicationHandler.prototype.dialANumber = function (contact) {
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage +
                ctiMessages_1.CtiMessages.MESSAGE_DIALING +
                ctiMessages_1.CtiMessages.MESSAGE_APPENDER + contact);
            Twilio.Device.connect({ To: contact,
                Direction: 'outbound' });
        };
        TwilioCommunicationHandler.prototype.getAvailableAgents = function (sessionId) {
            var _this = this;
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage +
                ctiMessages_1.CtiMessages.MESSAGE_SEARCH_AVAILABLE_AGENTS);
            this.sessionId = sessionId;
            $.ajax({
                url: this.serverURI + '/getConnectedAgents',
                type: 'POST',
                data: {
                    session_id: sessionId
                }
            }).done(function (searchResult) {
                ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                    ctiMessages_1.CtiMessages.MESSAGE_AGENT_SEARCH_SUCCESS +
                    ctiMessages_1.CtiMessages.MESSAGE_APPENDER + searchResult);
                _this.serverEventHandler.despatch('search.agentlist.complete', JSON.parse(searchResult));
            }).fail(function (message) {
                ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage +
                    ctiMessages_1.CtiMessages.MESSAGE_AGENT_SEARCH_FAILURE +
                    ctiMessages_1.CtiMessages.MESSAGE_APPENDER + message);
                _this.serverEventHandler.despatch('search.agentlist.complete', []);
            });
        };
        TwilioCommunicationHandler.prototype.isCtiEnabled = function (interfaceUrl, servicePath, sessionId) {
            var _this = this;
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_CTI_AUTHORIZE);
            var requestUrl = interfaceUrl.match(/^[^\/]+:\/\/[^\/]+\//)[0].replace(/^http(?!s)/i, 'https')
                + servicePath + '/isCTIEnabled';
            $.ajax({
                url: requestUrl,
                type: 'POST',
                data: {
                    session_id: sessionId
                }
            }).done(function (data) {
                var jsonData = JSON.parse(data);
                if (jsonData && jsonData.enabled) {
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_CTI_ENABLED);
                    _this.serverEventHandler.despatch('cti.enabled', {});
                }
                else {
                    _this.serverEventHandler.despatch('cti.disabled', {});
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_CTI_DISABLED);
                }
            }).fail(function (data) {
                _this.serverEventHandler.despatch('cti.disabled', {});
                ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage +
                    ctiMessages_1.CtiMessages.MESSAGE_CTI_AUTHORIZATION_FAILURE +
                    ctiMessages_1.CtiMessages.MESSAGE_APPENDER + data);
            });
        };
        TwilioCommunicationHandler.prototype.transferCurrentCall = function (sessionId, workerId, incidentId) {
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage +
                ctiMessages_1.CtiMessages.MESSAGE_REQUEST_CALL_TRANSFER +
                ctiMessages_1.CtiMessages.MESSAGE_APPENDER + workerId);
            this.sessionId = sessionId;
            var lookup = false;
            if (!this.attributes) {
                lookup = true;
                this.attributes = {
                    callSid: this.callSid,
                    contact: this.dialedContact,
                    incident: null
                };
            }
            if (incidentId) {
                this.attributes.incident = incidentId;
            }
            else {
                this.attributes.incident = null;
            }
            $.ajax({
                url: this.serverURI + '/transferCall',
                type: 'POST',
                data: {
                    session_id: sessionId,
                    attributes: JSON.stringify(this.attributes),
                    worker: workerId,
                    lookup: lookup
                }
            });
        };
        TwilioCommunicationHandler.prototype.renewToken = function (sessionId) {
            var _this = this;
            $.ajax({
                type: "POST",
                url: this.serverURI + "/renewTokens",
                data: {
                    session_id: sessionId,
                    tokens: 'device,worker'
                }
            })
                .done(function (data) {
                ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_UPDATE_DEVICE);
                var jsonData = JSON.parse(data);
                _this.workerToken = jsonData.worker;
                _this.deviceToken = jsonData.device;
                ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage + jsonData);
                Twilio.Device.setup(_this.deviceToken, {
                    iceServers: _this.ICE
                });
                try {
                    _this.worker.updateToken(_this.workerToken);
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_UPDATE_DEVICE_SUCCESS);
                }
                catch (message) {
                    ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage +
                        ctiMessages_1.CtiMessages.MESSAGE_TOKEN_UPDATE_FAILURE +
                        ctiMessages_1.CtiMessages.MESSAGE_APPENDER + message);
                }
            })
                .fail(function (message) {
                ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage +
                    ctiMessages_1.CtiMessages.MESSAGE_TOKEN_UPDATE_FAILURE +
                    ctiMessages_1.CtiMessages.MESSAGE_APPENDER + message);
            });
        };
        ;
        TwilioCommunicationHandler.prototype.logAuditMessage = function (sessionId, message) {
            var _this = this;
            $.ajax({
                type: "POST",
                url: this.serverURI + "/logCallAction",
                data: {
                    session_id: sessionId,
                    action: message
                }
            })
                .done(function (data) {
                ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage +
                    ctiMessages_1.CtiMessages.MESSAGE_LOG_ACTION +
                    ctiMessages_1.CtiMessages.MESSAGE_APPENDER + message);
            })
                .fail(function (message) {
                ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage +
                    ctiMessages_1.CtiMessages.MESSAGE_LOG_ATION_FAILURE +
                    ctiMessages_1.CtiMessages.MESSAGE_APPENDER + message);
            });
        };
        return TwilioCommunicationHandler;
    }());
    exports.TwilioCommunicationHandler = TwilioCommunicationHandler;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHdpbGlvQ29tbXVuaWNhdGlvbkhhbmRsZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ0d2lsaW9Db21tdW5pY2F0aW9uSGFuZGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0lBcUJBO1FBMEJJO1lBQUEsaUJBRUM7WUEzQk8sZUFBVSxHQUFRLEVBQUUsQ0FBQztZQUNyQixhQUFRLEdBQVksS0FBSyxDQUFDO1lBZ0IxQixlQUFVLEdBQVksSUFBSSxDQUFDO1lBTTNCLGtCQUFhLEdBQVcsNEJBQTRCLEdBQUcseUJBQVcsQ0FBQyxnQkFBZ0IsQ0FBQztZQStVcEYsMkJBQXNCLEdBQUcsVUFBQyxJQUFTO2dCQUN2QyxLQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2dCQUMxQyxLQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7Z0JBQy9CLEtBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztnQkFDL0IsS0FBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQkFDakMsS0FBSSxDQUFDLEdBQUcsR0FBRSxJQUFJLENBQUMsR0FBRyxDQUFDO2dCQUVuQixJQUFHLEtBQUksQ0FBQyxVQUFVLEVBQUM7b0JBQ2YscUJBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLGFBQWE7d0JBQ3ZDLHlCQUFXLENBQUMseUJBQXlCLENBQUUsQ0FBQztvQkFFNUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUUsS0FBSSxDQUFDLFdBQVcsRUFBRTt3QkFDbkMsVUFBVSxFQUFFLElBQUksQ0FBQyxHQUFHO3FCQUN2QixDQUFFLENBQUM7b0JBRUosTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUUsVUFBQyxJQUFTO3dCQUM5QixxQkFBUyxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsYUFBYTs0QkFDdkMseUJBQVcsQ0FBQywyQkFBMkIsR0FBRSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNuRSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ2xCLENBQUMsQ0FBQyxDQUFDO29CQUVILE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFFLFVBQUMsSUFBUzt3QkFDN0IscUJBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLGFBQWE7NEJBQ3ZDLHlCQUFXLENBQUMsOEJBQThCLENBQUMsQ0FBQzt3QkFDaEQsSUFBSSxJQUFJLEdBQUc7NEJBQ1AsT0FBTyxFQUFFLEtBQUksQ0FBQyxXQUFXOzRCQUN6QixRQUFRLEVBQUUsS0FBSSxDQUFDLFVBQVU7NEJBRXpCLE1BQU0sRUFBRTtnQ0FDSixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0NBQ2xCLEtBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUM7NEJBQ2pDLENBQUM7NEJBRUQsSUFBSSxFQUFFLFVBQUUsSUFBSTtnQ0FDUixJQUFJLENBQUMsSUFBSSxDQUFFLElBQUksQ0FBRSxDQUFDOzRCQUN0QixDQUFDO3lCQUNKLENBQUM7d0JBQ0YsS0FBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQzt3QkFDdkMsS0FBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBRSxXQUFXLEVBQUUsSUFBSSxDQUFFLENBQUM7b0JBQzFELENBQUMsQ0FBQyxDQUFDO29CQUVILE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFFLFVBQUMsSUFBUzt3QkFDaEMscUJBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLGFBQWE7NEJBQ3ZDLHlCQUFXLENBQUMsd0JBQXdCLENBQUMsQ0FBQzt3QkFDMUMsS0FBSSxDQUFDLFVBQVUsR0FBRSxJQUFJLENBQUM7d0JBQ3RCLEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO3dCQUN2QixLQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3dCQUM3QixLQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFFLGNBQWMsRUFBRSxFQUFFLENBQUUsQ0FBQztvQkFDM0QsQ0FBQyxDQUFDLENBQUM7aUJBQ047Z0JBRUQsSUFBRyxLQUFJLENBQUMsV0FBVyxJQUFJLElBQUksRUFBQztvQkFDeEIsTUFBSyxDQUFDLHNFQUFzRSxDQUFDLENBQUM7aUJBQ2pGO2dCQUVELEtBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBRSxLQUFJLENBQUMsV0FBVyxDQUFFLENBQUM7Z0JBRS9ELEtBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRyxVQUFFLE1BQVc7b0JBQ2xDLHFCQUFTLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxhQUFhLEdBQUcsU0FBUyxHQUFHLE1BQU0sQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDLENBQUM7b0JBQzdGLEtBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUNyQixxQkFBUyxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsYUFBYTt3QkFDdkMseUJBQVcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO29CQUNoRCxLQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFFLGVBQWUsRUFBRSxJQUFJLENBQUUsQ0FBQztvQkFDMUQsS0FBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDakMsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsS0FBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMscUJBQXFCLEVBQUUsVUFBQyxXQUFnQjtvQkFDbkQscUJBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLGFBQWE7d0JBQ3ZDLHlCQUFXLENBQUMsMkJBQTJCLENBQUMsQ0FBQztvQkFDN0MsS0FBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7b0JBQy9CLElBQUksS0FBSyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztvQkFDN0MsS0FBSSxDQUFDLFVBQVUsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztvQkFDOUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFDLEVBQUUsQ0FBQyxDQUFDO29CQUNwQyxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7b0JBRWpCLElBQUksT0FBTyxHQUFRLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztvQkFDdkQsS0FBSSxDQUFDLFVBQVUsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7b0JBRXZELE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxPQUFPLENBQUMsU0FBUyxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDO29CQUM3RCxLQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQztvQkFFM0IsSUFBSSxJQUFJLEdBQUc7d0JBQ1AsT0FBTyxFQUFFLE9BQU87d0JBRWhCLE1BQU0sRUFBRTs0QkFDSixZQUFZLENBQUUsS0FBSSxDQUFDLGFBQWEsQ0FBRSxDQUFDOzRCQUNuQyxXQUFXLENBQUMsT0FBTyxDQUFFLEtBQUksQ0FBQyxlQUFlLENBQUUsQ0FBQzt3QkFDaEQsQ0FBQzt3QkFDRCxNQUFNLEVBQUU7NEJBQ0osWUFBWSxDQUFFLEtBQUksQ0FBQyxhQUFhLENBQUUsQ0FBQzs0QkFDbkMsS0FBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7NEJBQ3ZCLEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDOzRCQUN2QixXQUFXLENBQUMsTUFBTSxFQUFFLENBQUM7d0JBQ3pCLENBQUM7cUJBQ0osQ0FBQztvQkFFRixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsT0FBTyxDQUFDO29CQUMxQixLQUFJLENBQUMsYUFBYSxHQUFHLFVBQVUsQ0FBRTt3QkFDN0IsS0FBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBRSxTQUFTLEVBQUUsRUFBRSxDQUFFLENBQUM7d0JBQ2xELElBQUcsS0FBSSxDQUFDLFdBQVcsRUFBRTs0QkFDakIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQzs0QkFDMUIsS0FBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7eUJBQzNCO3dCQUNELEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO3dCQUN2QixLQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDM0IsQ0FBQyxFQUFFLE9BQU8sR0FBRyxJQUFJLENBQUUsQ0FBQztvQkFDcEIsS0FBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBRSxVQUFVLEVBQUUsSUFBSSxDQUFFLENBQUM7Z0JBQ3pELENBQUMsQ0FBQyxDQUFDO2dCQUVILEtBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLHNCQUFzQixFQUFFLFVBQUMsV0FBVztvQkFDL0MscUJBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLGFBQWE7d0JBQ3ZDLHlCQUFXLENBQUMsNkJBQTZCLENBQUMsQ0FBQztvQkFDL0MsS0FBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7b0JBQ3ZCLEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUN2QixZQUFZLENBQUUsS0FBSSxDQUFDLGFBQWEsQ0FBRSxDQUFDO29CQUNuQyxLQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFFLFVBQVUsRUFBRSxFQUFFLENBQUUsQ0FBQztnQkFDdkQsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsS0FBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsc0JBQXNCLEVBQUUsVUFBQyxXQUFXO29CQUMvQyxZQUFZLENBQUUsS0FBSSxDQUFDLGFBQWEsQ0FBRSxDQUFDO29CQUNuQyxxQkFBUyxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsYUFBYTt3QkFDdkMseUJBQVcsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO2dCQUNsRCxDQUFDLENBQUMsQ0FBQztnQkFFSCxLQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxzQkFBc0IsRUFBRSxVQUFDLFdBQVc7b0JBQy9DLFlBQVksQ0FBRSxLQUFJLENBQUMsYUFBYSxDQUFFLENBQUM7b0JBQ25DLEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUN2QixLQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDdkIscUJBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLGFBQWE7d0JBQ3ZDLHlCQUFXLENBQUMsNEJBQTRCLENBQUMsQ0FBQztvQkFDOUMsS0FBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBRSxVQUFVLEVBQUUsRUFBRSxDQUFFLENBQUM7Z0JBQ3ZELENBQUMsQ0FBQyxDQUFDO2dCQUVILEtBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLGVBQWUsRUFBRTtvQkFDNUIscUJBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLGFBQWE7d0JBQ3ZDLHlCQUFXLENBQUMscUJBQXFCLENBQUMsQ0FBQztvQkFDdkMsS0FBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQzFELENBQUMsQ0FBQyxDQUFDO2dCQUVILEtBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLGlCQUFpQixFQUFFLFVBQUMsTUFBTTtvQkFDckMsS0FBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBRSxpQkFBaUIsRUFBRSxNQUFNLENBQUMsWUFBWSxDQUFFLENBQUM7Z0JBQy9FLENBQUMsQ0FBQyxDQUFDO2dCQUVILEtBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FDeEIsVUFBQyxLQUFVLEVBQUUsWUFBaUI7b0JBQzFCLElBQUcsS0FBSyxFQUFFO3dCQUNOLHFCQUFTLENBQUMsZUFBZSxDQUFDLEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUMzRCxxQkFBUyxDQUFDLGVBQWUsQ0FBQyxLQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQzt3QkFDOUQsT0FBTztxQkFDVjtvQkFDRCxJQUFJLElBQUksR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDO29CQUM3QixLQUFJLElBQUksQ0FBQyxHQUFDLENBQUMsRUFBRSxDQUFDLEdBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFDN0IsS0FBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztxQkFDdkQ7b0JBRUQsS0FBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLEVBQUUsVUFBQyxLQUFLLEVBQUUsTUFBTTt3QkFDdEUsSUFBRyxLQUFLLEVBQUU7NEJBQ04scUJBQVMsQ0FBQyxlQUFlLENBQUMsS0FBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7NEJBQzNELHFCQUFTLENBQUMsZUFBZSxDQUFDLEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3lCQUNqRTs2QkFBTTs0QkFDSCxxQkFBUyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7eUJBQ2pEO29CQUNMLENBQUMsQ0FBQyxDQUFDO2dCQUNQLENBQUMsQ0FDSixDQUFDO1lBQ04sQ0FBQyxDQUFDO1lBamZFLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLHVDQUFrQixFQUFFLENBQUM7UUFDdkQsQ0FBQztRQVdNLDBDQUFLLEdBQVosVUFBYSxTQUFTLEVBQUUsU0FBUyxFQUFFLE9BQU87WUFBMUMsaUJBcUNDO1lBcENHLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1lBQzNCLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDOUMscUJBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGFBQWEsR0FBRyx5QkFBVyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBRXpFLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ0gsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUTtnQkFDOUIsSUFBSSxFQUFFLE1BQU07Z0JBQ1osSUFBSSxFQUFFO29CQUNGLFVBQVUsRUFBRSxJQUFJLENBQUMsU0FBUztpQkFDN0I7Z0JBQ0QsUUFBUSxFQUFFLE1BQU07YUFDbkIsQ0FBQztpQkFDRyxJQUFJLENBQUMsVUFBQyxJQUFTO2dCQUVaLElBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBQztvQkFDckIscUJBQVMsQ0FBQyxlQUFlLENBQUMsS0FBSSxDQUFDLGFBQWEsR0FBRyx5QkFBVyxDQUFDLDBCQUEwQjt3QkFDakYsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO29CQUMxQixLQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFFLGNBQWMsRUFBRSxJQUFJLENBQUUsQ0FBQztvQkFDekQsT0FBTztpQkFDVjtnQkFDRCxJQUFHO29CQUNDLEtBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDbEMsS0FBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7aUJBQzNCO2dCQUFBLE9BQU0sU0FBUyxFQUFFO29CQUNkLHFCQUFTLENBQUMsZUFBZSxDQUFDLEtBQUksQ0FBQyxhQUFhO3dCQUN4Qyx5QkFBVyxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztvQkFDcEUsS0FBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBRSxjQUFjLEVBQUUsRUFBRSxDQUFFLENBQUM7aUJBQzFEO1lBQ0wsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBRSxVQUFDLGNBQW1CO2dCQUN2QixxQkFBUyxDQUFDLGVBQWUsQ0FBQyxLQUFJLENBQUMsYUFBYTtvQkFDeEMseUJBQVcsQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3hFLEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUUsY0FBYyxFQUFFLElBQUksQ0FBRSxDQUFDO1lBQ2pFLENBQUMsQ0FBQyxDQUFDO1FBRVAsQ0FBQztRQU1NLDJDQUFNLEdBQWI7WUFDSSxxQkFBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsYUFBYSxHQUFHLHlCQUFXLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDMUUsSUFBSSxDQUFDLGNBQWMsQ0FBQywyQkFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ2hELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1lBQ25CLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1lBQ3RCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQzFCLENBQUM7UUFNTSxtREFBYyxHQUFyQixVQUFzQixJQUFZO1lBQWxDLGlCQW1CQztZQWxCRyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFDbEI7Z0JBQ0ksTUFBSyxDQUFDLHlCQUFXLENBQUMsK0JBQStCLENBQUMsQ0FBQzthQUN0RDtZQUNELElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQzNCO2dCQUNJLHFCQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxhQUFhO29CQUN2Qyx5QkFBVyxDQUFDLCtCQUErQjtvQkFDM0MseUJBQVcsQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsQ0FBQztnQkFDekMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsVUFBQyxLQUFLLEVBQUUsTUFBTTtvQkFDbkUsSUFBRyxLQUFLLEVBQUU7d0JBQ04scUJBQVMsQ0FBQyxlQUFlLENBQUMsS0FBSSxDQUFDLGFBQWE7NEJBQ3hDLHlCQUFXLENBQUMsNkJBQTZCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO3FCQUMxRTt5QkFBTTt3QkFDSCxxQkFBUyxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztxQkFDdEU7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7YUFDTjtRQUNMLENBQUM7UUFRTSwwREFBcUIsR0FBNUI7WUFDSSxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztRQUNuQyxDQUFDO1FBU00sa0RBQWEsR0FBcEIsVUFBcUIsT0FBZSxFQUFFLFNBQWlCO1lBQXZELGlCQXNCQztZQXJCRyxxQkFBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsYUFBYTtnQkFDdkMseUJBQVcsQ0FBQyxzQkFBc0I7Z0JBQ2xDLHlCQUFXLENBQUMsZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLENBQUM7WUFDNUMsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDSCxHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsR0FBRyxjQUFjO2dCQUNwQyxJQUFJLEVBQUUsTUFBTTtnQkFDWixJQUFJLEVBQUU7b0JBQ0YsS0FBSyxFQUFFLE9BQU87b0JBQ2QsVUFBVSxFQUFFLFNBQVM7aUJBQ3hCO2FBQ0osQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFDLFlBQWlCO2dCQUN0QixxQkFBUyxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsYUFBYTtvQkFDdkMseUJBQVcsQ0FBQyw4QkFBOEI7b0JBQzFDLHlCQUFXLENBQUMsZ0JBQWdCLEdBQUcsWUFBWSxDQUFDLENBQUM7Z0JBQ2pELElBQUksZ0JBQWdCLEdBQVEsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDckQsS0FBSSxDQUFDLGFBQWEsR0FBRyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUM7Z0JBQzlDLEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMseUJBQXlCLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztZQUNsRixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxPQUFZO2dCQUNqQixxQkFBUyxDQUFDLGVBQWUsQ0FBQyxLQUFJLENBQUMsYUFBYSxHQUFHLDJCQUEyQixHQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNwRixLQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLHVCQUF1QixFQUFFLEVBQUMsT0FBTyxFQUFFLEtBQUssRUFBQyxDQUFDLENBQUM7WUFDaEYsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDO1FBT00sZ0RBQVcsR0FBbEIsVUFBbUIsT0FBZTtZQUM5QixxQkFBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsYUFBYTtnQkFDdkMseUJBQVcsQ0FBQyxlQUFlO2dCQUMzQix5QkFBVyxDQUFDLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxDQUFDO1lBQzVDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUMsRUFBRSxFQUFFLE9BQU87Z0JBQ2xDLFNBQVMsRUFBRSxVQUFVLEVBQUMsQ0FBQyxDQUFDO1FBQzVCLENBQUM7UUFTTSx1REFBa0IsR0FBekIsVUFBMEIsU0FBaUI7WUFBM0MsaUJBcUJDO1lBcEJHLHFCQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxhQUFhO2dCQUN2Qyx5QkFBVyxDQUFDLCtCQUErQixDQUFDLENBQUM7WUFDakQsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7WUFDM0IsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDSCxHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsR0FBRyxxQkFBcUI7Z0JBQzNDLElBQUksRUFBRSxNQUFNO2dCQUNaLElBQUksRUFBRTtvQkFDRixVQUFVLEVBQUUsU0FBUztpQkFDeEI7YUFDSixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsWUFBb0I7Z0JBQ3pCLHFCQUFTLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxhQUFhO29CQUN2Qyx5QkFBVyxDQUFDLDRCQUE0QjtvQkFDeEMseUJBQVcsQ0FBQyxnQkFBZ0IsR0FBRyxZQUFZLENBQUMsQ0FBQztnQkFDakQsS0FBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQywyQkFBMkIsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7WUFDNUYsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsT0FBWTtnQkFDakIscUJBQVMsQ0FBQyxlQUFlLENBQUMsS0FBSSxDQUFDLGFBQWE7b0JBQ3hDLHlCQUFXLENBQUMsNEJBQTRCO29CQUN4Qyx5QkFBVyxDQUFDLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxDQUFDO2dCQUM1QyxLQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLDJCQUEyQixFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ3RFLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQztRQVVNLGlEQUFZLEdBQW5CLFVBQW9CLFlBQW9CLEVBQUUsV0FBbUIsRUFBRSxTQUFpQjtZQUFoRixpQkEwQkM7WUF6QkcscUJBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGFBQWEsR0FBRyx5QkFBVyxDQUFDLHFCQUFxQixDQUFDLENBQUM7WUFDakYsSUFBSSxVQUFVLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDO2tCQUN4RixXQUFXLEdBQUcsZUFBZSxDQUFDO1lBRXBDLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ0gsR0FBRyxFQUFFLFVBQVU7Z0JBQ2YsSUFBSSxFQUFFLE1BQU07Z0JBQ1osSUFBSSxFQUFFO29CQUNGLFVBQVUsRUFBRSxTQUFTO2lCQUN4QjthQUNKLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxJQUFZO2dCQUNqQixJQUFJLFFBQVEsR0FBUSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNyQyxJQUFHLFFBQVEsSUFBSSxRQUFRLENBQUMsT0FBTyxFQUFDO29CQUM1QixxQkFBUyxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsYUFBYSxHQUFHLHlCQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQztvQkFDL0UsS0FBSSxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUM7aUJBQ3ZEO3FCQUFJO29CQUNELEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUNyRCxxQkFBUyxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsYUFBYSxHQUFHLHlCQUFXLENBQUMsb0JBQW9CLENBQUMsQ0FBQztpQkFDbkY7WUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxJQUFTO2dCQUNkLEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNyRCxxQkFBUyxDQUFDLGVBQWUsQ0FBQyxLQUFJLENBQUMsYUFBYTtvQkFDeEMseUJBQVcsQ0FBQyxpQ0FBaUM7b0JBQzdDLHlCQUFXLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLENBQUM7WUFDN0MsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDO1FBU00sd0RBQW1CLEdBQTFCLFVBQTJCLFNBQWlCLEVBQUUsUUFBZ0IsRUFBRSxVQUFrQjtZQUM5RSxxQkFBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsYUFBYTtnQkFDdkMseUJBQVcsQ0FBQyw2QkFBNkI7Z0JBQ3pDLHlCQUFXLENBQUMsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDLENBQUM7WUFDN0MsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7WUFDM0IsSUFBSSxNQUFNLEdBQVksS0FBSyxDQUFDO1lBQzVCLElBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFDO2dCQUNoQixNQUFNLEdBQUcsSUFBSSxDQUFDO2dCQUNkLElBQUksQ0FBQyxVQUFVLEdBQUc7b0JBQ2QsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO29CQUNyQixPQUFPLEVBQUUsSUFBSSxDQUFDLGFBQWE7b0JBQzNCLFFBQVEsRUFBRSxJQUFJO2lCQUNqQixDQUFBO2FBQ0o7WUFFRCxJQUFHLFVBQVUsRUFBQztnQkFDVixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUM7YUFDekM7aUJBQUk7Z0JBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO2FBQ25DO1lBRUQsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDSCxHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsR0FBRyxlQUFlO2dCQUNyQyxJQUFJLEVBQUUsTUFBTTtnQkFDWixJQUFJLEVBQUU7b0JBQ0YsVUFBVSxFQUFFLFNBQVM7b0JBQ3JCLFVBQVUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7b0JBQzNDLE1BQU0sRUFBRSxRQUFRO29CQUNoQixNQUFNLEVBQUUsTUFBTTtpQkFDakI7YUFDSixDQUFDLENBQUM7UUFDUCxDQUFDO1FBUU0sK0NBQVUsR0FBakIsVUFBbUIsU0FBaUI7WUFBcEMsaUJBcUNDO1lBcENHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ0MsSUFBSSxFQUFFLE1BQU07Z0JBQ1osR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLEdBQUcsY0FBYztnQkFDcEMsSUFBSSxFQUFFO29CQUNGLFVBQVUsRUFBRSxTQUFTO29CQUNyQixNQUFNLEVBQUUsZUFBZTtpQkFDMUI7YUFDSixDQUFDO2lCQUNELElBQUksQ0FBRSxVQUFDLElBQVM7Z0JBQ2IscUJBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLGFBQWEsR0FBRyx5QkFBVyxDQUFDLHFCQUFxQixDQUFDLENBQUM7Z0JBRWpGLElBQUksUUFBUSxHQUFRLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3JDLEtBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQztnQkFDbkMsS0FBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO2dCQUVuQyxxQkFBUyxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQyxDQUFDO2dCQUV4RCxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFJLENBQUMsV0FBVyxFQUFFO29CQUNsQyxVQUFVLEVBQUUsS0FBSSxDQUFDLEdBQUc7aUJBQ3ZCLENBQUMsQ0FBQztnQkFFSCxJQUFHO29CQUNDLEtBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFFLEtBQUksQ0FBQyxXQUFXLENBQUUsQ0FBQztvQkFDNUMscUJBQVMsQ0FBQyxjQUFjLENBQUMsS0FBSSxDQUFDLGFBQWEsR0FBRyx5QkFBVyxDQUFDLDZCQUE2QixDQUFDLENBQUM7aUJBQzVGO2dCQUNELE9BQU0sT0FBTyxFQUFDO29CQUNWLHFCQUFTLENBQUMsZUFBZSxDQUFDLEtBQUksQ0FBQyxhQUFhO3dCQUN4Qyx5QkFBVyxDQUFDLDRCQUE0Qjt3QkFDeEMseUJBQVcsQ0FBQyxnQkFBZ0IsR0FBRyxPQUFPLENBQUMsQ0FBQztpQkFDL0M7WUFDTCxDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLFVBQUMsT0FBWTtnQkFDZixxQkFBUyxDQUFDLGVBQWUsQ0FBQyxLQUFJLENBQUMsYUFBYTtvQkFDeEMseUJBQVcsQ0FBQyw0QkFBNEI7b0JBQ3hDLHlCQUFXLENBQUMsZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLENBQUM7WUFDaEQsQ0FBQyxDQUFDLENBQUE7UUFDVixDQUFDO1FBQUEsQ0FBQztRQVFLLG9EQUFlLEdBQXRCLFVBQXVCLFNBQWlCLEVBQUUsT0FBZTtZQUF6RCxpQkFtQkM7WUFsQkcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDQyxJQUFJLEVBQUUsTUFBTTtnQkFDWixHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsR0FBRyxnQkFBZ0I7Z0JBQ3RDLElBQUksRUFBRTtvQkFDRixVQUFVLEVBQUUsU0FBUztvQkFDckIsTUFBTSxFQUFFLE9BQU87aUJBQ2xCO2FBQ0osQ0FBQztpQkFDRCxJQUFJLENBQUUsVUFBQyxJQUFTO2dCQUNiLHFCQUFTLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxhQUFhO29CQUN2Qyx5QkFBVyxDQUFDLGtCQUFrQjtvQkFDOUIseUJBQVcsQ0FBQyxnQkFBZ0IsR0FBRyxPQUFPLENBQUMsQ0FBQztZQUNoRCxDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLFVBQUMsT0FBWTtnQkFDZixxQkFBUyxDQUFDLGVBQWUsQ0FBQyxLQUFJLENBQUMsYUFBYTtvQkFDeEMseUJBQVcsQ0FBQyx5QkFBeUI7b0JBQ3JDLHlCQUFXLENBQUMsZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLENBQUM7WUFDaEQsQ0FBQyxDQUFDLENBQUE7UUFDVixDQUFDO1FBbUxMLGlDQUFDO0lBQUQsQ0FBQyxBQTlnQkQsSUE4Z0JDO0lBOWdCWSxnRUFBMEIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAkQUNDRUxFUkFUT1JfSEVBREVSX1BMQUNFX0hPTERFUiRcbiAqICBTSEExOiAkSWQ6IDI0MTUyNDdlODhhNmIwZmMzMjZiOGIzNDM5NjdhMjVjMTMxYzZhMjAgJFxuICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgRmlsZTogJEFDQ0VMRVJBVE9SX0hFQURFUl9GSUxFX05BTUVfUExBQ0VfSE9MREVSJFxuICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqICovXG5cbi8vLzxyZWZlcmVuY2UgcGF0aD1cIi4uLy4uLy4uL2RlZmluaXRpb25zL3R3aWxpby5kLnRzXCIgLz5cblxuaW1wb3J0IHtTZXJ2ZXJFdmVudEhhbmRsZXJ9IGZyb20gXCIuL3NlcnZlckV2ZW50SGFuZGxlclwiO1xuaW1wb3J0ICQgPSByZXF1aXJlKCdqcXVlcnknKTtcbmltcG9ydCB7Q3RpQ29uc3RhbnRzfSBmcm9tIFwiLi4vdXRpbC9jdGlDb25zdGFudHNcIjtcbmltcG9ydCB7Q3RpTG9nZ2VyfSBmcm9tIFwiLi4vdXRpbC9jdGlMb2dnZXJcIjtcbmltcG9ydCB7Q29udGFjdH0gZnJvbSBcIi4uL21vZGVsL2NvbnRhY3RcIjtcbmltcG9ydCB7Q3RpTWVzc2FnZXN9IGZyb20gXCIuLi91dGlsL2N0aU1lc3NhZ2VzXCI7XG5cbi8qKlxuICogVHdpbGlvQ29tbXVuaWNhdGlvbkhhbmRsZXIgLSBBbGwgY29tbXVuaWNhdGlvbiB3aXRoIHRoZSBjdXN0b20gY29udHJvbGxlclxuICogIGlzIGhhbmRsZWQgaW4gdGhpcyBjbGFzcy4gSGVyZSB3ZSBzdWJtaXQgcmVxdWVzdHMgdG8gdGhlIHNlcnZlciBhbmQgZGVzcGF0Y2ggKHB1Ymxpc2gpXG4gKiAgYXNzb2NpYXRlZCBldmVudHMgYmFzZWQgb24gcmVzdWx0LlxuICovXG5leHBvcnQgY2xhc3MgVHdpbGlvQ29tbXVuaWNhdGlvbkhhbmRsZXIge1xuICAgIHByaXZhdGUgYWN0aXZpdGllczogYW55ID0ge307XG4gICAgcHJpdmF0ZSBsb2dnZWRJbjogYm9vbGVhbiA9IGZhbHNlO1xuXG4gICAgcHJpdmF0ZSB3b3JrZXJOYW1lOiBzdHJpbmc7XG4gICAgcHJpdmF0ZSBzZXNzaW9uSWQ6IHN0cmluZztcbiAgICBwcml2YXRlIGFnZW50SWQ6IHN0cmluZztcbiAgICBwcml2YXRlIHNlcnZlclVSSTogc3RyaW5nO1xuICAgIHByaXZhdGUgZGV2aWNlVG9rZW46IGFueTtcbiAgICBwcml2YXRlIHdvcmtlclRva2VuOiBhbnk7XG4gICAgcHJpdmF0ZSB3b3JrZXI6IGFueTtcbiAgICBwcml2YXRlIHJlc2VydmF0aW9uOiBhbnk7XG4gICAgcHJpdmF0ZSBjb250YWN0SW5mbzogYW55O1xuICAgIHByaXZhdGUgc2VydmVyRXZlbnRIYW5kbGVyOlNlcnZlckV2ZW50SGFuZGxlcjtcbiAgICBwcml2YXRlIHJvdXRlczogYW55O1xuICAgIHByaXZhdGUgaW5jaWRlbnRJZDogYW55O1xuICAgIHByaXZhdGUgYXR0cmlidXRlczogYW55O1xuICAgIHByaXZhdGUgZGVxdWV1ZUNvbmZpZ0lkOiBzdHJpbmc7XG4gICAgcHJpdmF0ZSBmaXJzdExvZ2luOiBib29sZWFuID0gdHJ1ZTtcbiAgICBwcml2YXRlIHRpbWVvdXRIYW5kbGU6IG51bWJlcjtcbiAgICBwcml2YXRlIElDRTogYW55O1xuICAgIHByaXZhdGUgZGlhbGVkQ29udGFjdDogQ29udGFjdDtcbiAgICBwcml2YXRlIGNhbGxTaWQ6IHN0cmluZztcblxuICAgIHByaXZhdGUgbG9nUHJlTWVzc2FnZTogc3RyaW5nID0gJ1R3aWxpb0NvbW11bmljYXRpb25IYW5kbGVyJyArIEN0aU1lc3NhZ2VzLk1FU1NBR0VfQVBQRU5ERVI7XG5cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5zZXJ2ZXJFdmVudEhhbmRsZXIgPSBuZXcgU2VydmVyRXZlbnRIYW5kbGVyKCk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU3VibWl0cyBhIGxvZ2luIHJlcXVlc3Qgd2l0aCBzZXJ2ZXIuIEFsc29cbiAgICAgKiBpdCBwdWJsaXNoZXMgJ2xvZ2luLnN1Y2Nlc3MnIGFuZCAnbG9naW4uZmFpbGVkJyBldmVudHNcbiAgICAgKlxuICAgICAqXG4gICAgICogQHBhcmFtIHNlcnZlclVSSVxuICAgICAqIEBwYXJhbSBzZXNzaW9uSWRcbiAgICAgKiBAcGFyYW0gYWdlbnRJZFxuICAgICAqL1xuICAgIHB1YmxpYyBsb2dpbihzZXJ2ZXJVUkksIHNlc3Npb25JZCwgYWdlbnRJZCk6IGFueSB7XG4gICAgICAgIHRoaXMuc2Vzc2lvbklkID0gc2Vzc2lvbklkO1xuICAgICAgICB0aGlzLmFnZW50SWQgPSBhZ2VudElkO1xuICAgICAgICB0aGlzLnNlcnZlclVSSSA9IHNlcnZlclVSSS5yZXBsYWNlKC9cXC8kLywgXCJcIik7XG4gICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgKyBDdGlNZXNzYWdlcy5NRVNTQUdFX0xPR0lOKTtcblxuICAgICAgICAkLmFqYXgoe1xuICAgICAgICAgICAgdXJsOiB0aGlzLnNlcnZlclVSSSArIFwiL2xvZ2luXCIsXG4gICAgICAgICAgICB0eXBlOiBcIlBPU1RcIixcbiAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICBzZXNzaW9uX2lkOiB0aGlzLnNlc3Npb25JZFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGRhdGFUeXBlOiBcIkpTT05cIlxuICAgICAgICB9KVxuICAgICAgICAgICAgLmRvbmUoKGRhdGE6IGFueSkgPT4ge1xuXG4gICAgICAgICAgICAgICAgaWYoZGF0YSAmJiAhZGF0YS5zdWNjZXNzKXtcbiAgICAgICAgICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0Vycm9yTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgKyBDdGlNZXNzYWdlcy5NRVNTQUdFX0xPR0lOX0VSUk9SX0RFVklDRSArXG4gICAgICAgICAgICAgICAgICAgICAgICBKU09OLnN0cmluZ2lmeShkYXRhKSk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2VydmVyRXZlbnRIYW5kbGVyLmRlc3BhdGNoKCAnbG9naW4uZmFpbGVkJywgZGF0YSApO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbml0aWFsaXplVHdpbGlvRGV2aWNlKGRhdGEpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmZpcnN0TG9naW4gPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9Y2F0Y2goZXhjZXB0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dFcnJvck1lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICtcbiAgICAgICAgICAgICAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfRVZFTlRfRElTUEFUQ0ggKyBKU09OLnN0cmluZ2lmeShleGNlcHRpb24pKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXJ2ZXJFdmVudEhhbmRsZXIuZGVzcGF0Y2goICdsb2dpbi5mYWlsZWQnLCB7fSApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuZmFpbCggKGZhaWx1cmVNZXNzYWdlOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgICBDdGlMb2dnZXIubG9nRXJyb3JNZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArXG4gICAgICAgICAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfTE9HSU5fRkFJTFVSRSArIEpTT04uc3RyaW5naWZ5KGZhaWx1cmVNZXNzYWdlKSk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXJ2ZXJFdmVudEhhbmRsZXIuZGVzcGF0Y2goICdsb2dpbi5mYWlsZWQnLCBuYW1lICk7XG4gICAgICAgIH0pO1xuXG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU3VibWl0cyBhIHN0YXR1cyB1cGRhdGUgdG8gdGhlIHNlcnZlciB3aXRoXG4gICAgICogc3RhdHVzIE9mZmxpbmVcbiAgICAgKi9cbiAgICBwdWJsaWMgbG9nb3V0KCk6IHZvaWQge1xuICAgICAgICBDdGlMb2dnZXIubG9nSW5mb01lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICsgQ3RpTWVzc2FnZXMuTUVTU0FHRV9MT0dPVVQpO1xuICAgICAgICB0aGlzLnVwZGF0ZUFjdGl2aXR5KEN0aUNvbnN0YW50cy5OT1RfQVZBSUxBQkxFKTtcbiAgICAgICAgdGhpcy53b3JrZXJOYW1lID0gbnVsbDtcbiAgICAgICAgdGhpcy53b3JrZXIgPSBudWxsO1xuICAgICAgICB0aGlzLnNlc3Npb25JZCA9IG51bGw7XG4gICAgICAgIHRoaXMuYWdlbnRJZCA9IG51bGw7XG4gICAgICAgIHRoaXMubG9nZ2VkSW4gPSBmYWxzZTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBTdWJtaXRzIHN0YXR1cyB1cGRhdGUgcmVxdWVzdCB0byB0aGUgc2VydmVyLlxuICAgICAqIEBwYXJhbSBuYW1lXG4gICAgICovXG4gICAgcHVibGljIHVwZGF0ZUFjdGl2aXR5KG5hbWU6IHN0cmluZyk6IHZvaWQge1xuICAgICAgICBpZiggIXRoaXMubG9nZ2VkSW4gKVxuICAgICAgICB7XG4gICAgICAgICAgICB0aHJvdyhDdGlNZXNzYWdlcy5NRVNTQUdFX05PVF9MT0dHRURJTl9GT1JfQUNUSU9OKTtcbiAgICAgICAgfVxuICAgICAgICBpZiggbmFtZSBpbiB0aGlzLmFjdGl2aXRpZXMgKVxuICAgICAgICB7XG4gICAgICAgICAgICBDdGlMb2dnZXIubG9nSW5mb01lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICtcbiAgICAgICAgICAgICAgICBDdGlNZXNzYWdlcy5NRVNTQUdFX1JFUVVFU1RfQUNUSVZJVFlfVVBEQVRFICtcbiAgICAgICAgICAgICAgICBDdGlNZXNzYWdlcy5NRVNTQUdFX0FQUEVOREVSICsgbmFtZSk7XG4gICAgICAgICAgICB0aGlzLndvcmtlci51cGRhdGUoXCJBY3Rpdml0eVNpZFwiLCB0aGlzLmFjdGl2aXRpZXNbbmFtZV0sIChlcnJvciwgd29ya2VyKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0Vycm9yTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgK1xuICAgICAgICAgICAgICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9BQ1RJVklUWV9VUERBVEVfRVJST1IgKyBKU09OLnN0cmluZ2lmeShlcnJvcikpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgKyB3b3JrZXIuYWN0aXZpdHlOYW1lKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIGN1cnJlbnRseSBhc3NvY2lhdGVkXG4gICAgICogaW5zdGFuY2Ugb2YgU2VydmVyRXZlbnRIYW5kbGVyXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyB7U2VydmVyRXZlbnRIYW5kbGVyfVxuICAgICAqL1xuICAgIHB1YmxpYyBnZXRTZXJ2ZXJFdmVudEhhbmRsZXIoKTpTZXJ2ZXJFdmVudEhhbmRsZXIge1xuICAgICAgICByZXR1cm4gdGhpcy5zZXJ2ZXJFdmVudEhhbmRsZXI7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogU2VhcmNoIGZvciBhIGdpdmVuIGNvbnRhY3QuXG4gICAgICogUHVibGlzaCBldmVudHMgJ3NlYXJjaC5jb250YWN0LmNvbXBsZXRlJyBhbmQgJ3NlYXJjaC5jb250YWN0LmZhaWxlZCdcbiAgICAgKlxuICAgICAqIEBwYXJhbSBjb250YWN0XG4gICAgICogQHBhcmFtIHNlc3Npb25JZFxuICAgICAqL1xuICAgIHB1YmxpYyBzZWFyY2hDb250YWN0KGNvbnRhY3Q6IHN0cmluZywgc2Vzc2lvbklkOiBzdHJpbmcpOiB2b2lkIHtcbiAgICAgICAgQ3RpTG9nZ2VyLmxvZ0luZm9NZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArXG4gICAgICAgICAgICBDdGlNZXNzYWdlcy5NRVNTQUdFX0NPTlRBQ1RfU0VBUkNIICtcbiAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfQVBQRU5ERVIgKyBjb250YWN0KTtcbiAgICAgICAgJC5hamF4KHtcbiAgICAgICAgICAgIHVybDogdGhpcy5zZXJ2ZXJVUkkgKyAnL3NlYXJjaFBob25lJyxcbiAgICAgICAgICAgIHR5cGU6ICdQT1NUJyxcbiAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICBwaG9uZTogY29udGFjdCxcbiAgICAgICAgICAgICAgICBzZXNzaW9uX2lkOiBzZXNzaW9uSWRcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkuZG9uZSgoc2VhcmNoUmVzdWx0OiBhbnkpID0+IHtcbiAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgK1xuICAgICAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfQ09OVEFDVF9TRUFSQ0hfU1VDQ0VTUyArXG4gICAgICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9BUFBFTkRFUiArIHNlYXJjaFJlc3VsdCk7XG4gICAgICAgICAgICB2YXIgc2VhcmNoUmVzdWx0SnNvbjogYW55ID0gSlNPTi5wYXJzZShzZWFyY2hSZXN1bHQpO1xuICAgICAgICAgICAgdGhpcy5kaWFsZWRDb250YWN0ID0gc2VhcmNoUmVzdWx0SnNvbi5jb250YWN0O1xuICAgICAgICAgICAgdGhpcy5zZXJ2ZXJFdmVudEhhbmRsZXIuZGVzcGF0Y2goJ3NlYXJjaC5jb250YWN0LmNvbXBsZXRlJywgc2VhcmNoUmVzdWx0SnNvbik7XG4gICAgICAgIH0pLmZhaWwoKG1lc3NhZ2U6IGFueSkgPT4ge1xuICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0Vycm9yTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgKyAnQ29udGFjdCBzZWFyY2ggZmFpbGVkID4+ICcrbWVzc2FnZSk7XG4gICAgICAgICAgICB0aGlzLnNlcnZlckV2ZW50SGFuZGxlci5kZXNwYXRjaCgnc2VhcmNoLmNvbnRhY3QuZmFpbGVkJywge3N1Y2Nlc3M6IGZhbHNlfSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIE1ha2UgYW4gb3V0Ym91bmQgY2FsbFxuICAgICAqXG4gICAgICogQHBhcmFtIGNvbnRhY3RcbiAgICAgKi9cbiAgICBwdWJsaWMgZGlhbEFOdW1iZXIoY29udGFjdDogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgK1xuICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9ESUFMSU5HICtcbiAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfQVBQRU5ERVIgKyBjb250YWN0KTtcbiAgICAgICAgVHdpbGlvLkRldmljZS5jb25uZWN0KHtUbzogY29udGFjdCxcbiAgICAgICAgRGlyZWN0aW9uOiAnb3V0Ym91bmQnfSk7XG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBTZWFyY2ggZm9yIGFsbCBhdmFpbGFibGUgYWdlbnRzLlxuICAgICAqIFB1Ymxpc2ggZXZlbnQgLSAnc2VhcmNoLmFnZW50bGlzdC5jb21wbGV0ZSdcbiAgICAgKlxuICAgICAqIEBwYXJhbSBzZXNzaW9uSWRcbiAgICAgKi9cbiAgICBwdWJsaWMgZ2V0QXZhaWxhYmxlQWdlbnRzKHNlc3Npb25JZDogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgK1xuICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9TRUFSQ0hfQVZBSUxBQkxFX0FHRU5UUyk7XG4gICAgICAgIHRoaXMuc2Vzc2lvbklkID0gc2Vzc2lvbklkO1xuICAgICAgICAkLmFqYXgoe1xuICAgICAgICAgICAgdXJsOiB0aGlzLnNlcnZlclVSSSArICcvZ2V0Q29ubmVjdGVkQWdlbnRzJyxcbiAgICAgICAgICAgIHR5cGU6ICdQT1NUJyxcbiAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICBzZXNzaW9uX2lkOiBzZXNzaW9uSWRcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkuZG9uZSgoc2VhcmNoUmVzdWx0OiBzdHJpbmcpID0+IHtcbiAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgK1xuICAgICAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfQUdFTlRfU0VBUkNIX1NVQ0NFU1MgK1xuICAgICAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfQVBQRU5ERVIgKyBzZWFyY2hSZXN1bHQpO1xuICAgICAgICAgICAgdGhpcy5zZXJ2ZXJFdmVudEhhbmRsZXIuZGVzcGF0Y2goJ3NlYXJjaC5hZ2VudGxpc3QuY29tcGxldGUnLCBKU09OLnBhcnNlKHNlYXJjaFJlc3VsdCkpO1xuICAgICAgICB9KS5mYWlsKChtZXNzYWdlOiBhbnkpID0+IHtcbiAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dFcnJvck1lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICtcbiAgICAgICAgICAgICAgICBDdGlNZXNzYWdlcy5NRVNTQUdFX0FHRU5UX1NFQVJDSF9GQUlMVVJFICtcbiAgICAgICAgICAgICAgICBDdGlNZXNzYWdlcy5NRVNTQUdFX0FQUEVOREVSICsgbWVzc2FnZSk7XG4gICAgICAgICAgICB0aGlzLnNlcnZlckV2ZW50SGFuZGxlci5kZXNwYXRjaCgnc2VhcmNoLmFnZW50bGlzdC5jb21wbGV0ZScsIFtdKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ2hlY2sgZm9yIENUSSBhY2Nlc3MgZm9yIHRoZSBnaXZlbiBhZ2VudC5cbiAgICAgKiBQdWJsaXNoIGV2ZW50cyAtICdjdGkuZW5hYmxlZCcgYW5kICdjdGkuZGlzYWJsZWQnXG4gICAgICpcbiAgICAgKiBAcGFyYW0gaW50ZXJmYWNlVXJsXG4gICAgICogQHBhcmFtIHNlcnZpY2VQYXRoXG4gICAgICogQHBhcmFtIHNlc3Npb25JZFxuICAgICAqL1xuICAgIHB1YmxpYyBpc0N0aUVuYWJsZWQoaW50ZXJmYWNlVXJsOiBzdHJpbmcsIHNlcnZpY2VQYXRoOiBzdHJpbmcsIHNlc3Npb25JZDogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgKyBDdGlNZXNzYWdlcy5NRVNTQUdFX0NUSV9BVVRIT1JJWkUpO1xuICAgICAgICB2YXIgcmVxdWVzdFVybCA9IGludGVyZmFjZVVybC5tYXRjaCgvXlteXFwvXSs6XFwvXFwvW15cXC9dK1xcLy8pWzBdLnJlcGxhY2UoL15odHRwKD8hcykvaSwgJ2h0dHBzJylcbiAgICAgICAgICAgICsgc2VydmljZVBhdGggKyAnL2lzQ1RJRW5hYmxlZCc7XG5cbiAgICAgICAgJC5hamF4KHtcbiAgICAgICAgICAgIHVybDogcmVxdWVzdFVybCxcbiAgICAgICAgICAgIHR5cGU6ICdQT1NUJyxcbiAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICBzZXNzaW9uX2lkOiBzZXNzaW9uSWRcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkuZG9uZSgoZGF0YTogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgICB2YXIganNvbkRhdGE6IGFueSA9IEpTT04ucGFyc2UoZGF0YSk7XG4gICAgICAgICAgICBpZihqc29uRGF0YSAmJiBqc29uRGF0YS5lbmFibGVkKXtcbiAgICAgICAgICAgICAgICBDdGlMb2dnZXIubG9nSW5mb01lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICsgQ3RpTWVzc2FnZXMuTUVTU0FHRV9DVElfRU5BQkxFRCk7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXJ2ZXJFdmVudEhhbmRsZXIuZGVzcGF0Y2goJ2N0aS5lbmFibGVkJywge30pO1xuICAgICAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXJ2ZXJFdmVudEhhbmRsZXIuZGVzcGF0Y2goJ2N0aS5kaXNhYmxlZCcsIHt9KTtcbiAgICAgICAgICAgICAgICBDdGlMb2dnZXIubG9nSW5mb01lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICsgQ3RpTWVzc2FnZXMuTUVTU0FHRV9DVElfRElTQUJMRUQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KS5mYWlsKChkYXRhOiBhbnkpID0+IHtcbiAgICAgICAgICAgIHRoaXMuc2VydmVyRXZlbnRIYW5kbGVyLmRlc3BhdGNoKCdjdGkuZGlzYWJsZWQnLCB7fSk7XG4gICAgICAgICAgICBDdGlMb2dnZXIubG9nRXJyb3JNZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArXG4gICAgICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9DVElfQVVUSE9SSVpBVElPTl9GQUlMVVJFICtcbiAgICAgICAgICAgICAgICBDdGlNZXNzYWdlcy5NRVNTQUdFX0FQUEVOREVSICsgZGF0YSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIFN1Ym1pdHMgdHJhbnNmZXIgY2FsbCByZXF1ZXN0IHRvIHRoZSBzZXJ2ZXIuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gc2Vzc2lvbklkXG4gICAgICogQHBhcmFtIHdvcmtlcklkXG4gICAgICogQHBhcmFtIGluY2lkZW50SWRcbiAgICAgKi9cbiAgICBwdWJsaWMgdHJhbnNmZXJDdXJyZW50Q2FsbChzZXNzaW9uSWQ6IHN0cmluZywgd29ya2VySWQ6IHN0cmluZywgaW5jaWRlbnRJZDogbnVtYmVyKTogdm9pZCB7XG4gICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgK1xuICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9SRVFVRVNUX0NBTExfVFJBTlNGRVIgK1xuICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9BUFBFTkRFUiArIHdvcmtlcklkKTtcbiAgICAgICAgdGhpcy5zZXNzaW9uSWQgPSBzZXNzaW9uSWQ7XG4gICAgICAgIHZhciBsb29rdXA6IGJvb2xlYW4gPSBmYWxzZTtcbiAgICAgICAgaWYoIXRoaXMuYXR0cmlidXRlcyl7IC8vT3V0Ym91bmQgY2FsbFxuICAgICAgICAgICAgbG9va3VwID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMuYXR0cmlidXRlcyA9IHtcbiAgICAgICAgICAgICAgICBjYWxsU2lkOiB0aGlzLmNhbGxTaWQsXG4gICAgICAgICAgICAgICAgY29udGFjdDogdGhpcy5kaWFsZWRDb250YWN0LFxuICAgICAgICAgICAgICAgIGluY2lkZW50OiBudWxsXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBpZihpbmNpZGVudElkKXtcbiAgICAgICAgICAgIHRoaXMuYXR0cmlidXRlcy5pbmNpZGVudCA9IGluY2lkZW50SWQ7XG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgdGhpcy5hdHRyaWJ1dGVzLmluY2lkZW50ID0gbnVsbDtcbiAgICAgICAgfVxuXG4gICAgICAgICQuYWpheCh7XG4gICAgICAgICAgICB1cmw6IHRoaXMuc2VydmVyVVJJICsgJy90cmFuc2ZlckNhbGwnLFxuICAgICAgICAgICAgdHlwZTogJ1BPU1QnLFxuICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgIHNlc3Npb25faWQ6IHNlc3Npb25JZCxcbiAgICAgICAgICAgICAgICBhdHRyaWJ1dGVzOiBKU09OLnN0cmluZ2lmeSh0aGlzLmF0dHJpYnV0ZXMpLFxuICAgICAgICAgICAgICAgIHdvcmtlcjogd29ya2VySWQsXG4gICAgICAgICAgICAgICAgbG9va3VwOiBsb29rdXBcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmVuZXdzIHRoZSBUV0lMSU8gY2FwYWJpbGl0eSB0b2tlbiBmb3JcbiAgICAgKiBXb3JrZXIgYW5kIERldmljZVxuICAgICAqXG4gICAgICogQHBhcmFtIHNlc3Npb25JZFxuICAgICAqL1xuICAgIHB1YmxpYyByZW5ld1Rva2VuIChzZXNzaW9uSWQ6IHN0cmluZyk6IHZvaWR7XG4gICAgICAgICQuYWpheCh7XG4gICAgICAgICAgICAgICAgdHlwZTogXCJQT1NUXCIsXG4gICAgICAgICAgICAgICAgdXJsOiB0aGlzLnNlcnZlclVSSSArIFwiL3JlbmV3VG9rZW5zXCIsXG4gICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgICBzZXNzaW9uX2lkOiBzZXNzaW9uSWQsXG4gICAgICAgICAgICAgICAgICAgIHRva2VuczogJ2RldmljZSx3b3JrZXInXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5kb25lKCAoZGF0YTogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0luZm9NZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArIEN0aU1lc3NhZ2VzLk1FU1NBR0VfVVBEQVRFX0RFVklDRSk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgdmFyIGpzb25EYXRhOiBhbnkgPSBKU09OLnBhcnNlKGRhdGEpO1xuICAgICAgICAgICAgICAgIHRoaXMud29ya2VyVG9rZW4gPSBqc29uRGF0YS53b3JrZXI7XG4gICAgICAgICAgICAgICAgdGhpcy5kZXZpY2VUb2tlbiA9IGpzb25EYXRhLmRldmljZTtcblxuICAgICAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgKyBqc29uRGF0YSk7XG5cbiAgICAgICAgICAgICAgICBUd2lsaW8uRGV2aWNlLnNldHVwKHRoaXMuZGV2aWNlVG9rZW4sIHtcbiAgICAgICAgICAgICAgICAgICAgaWNlU2VydmVyczogdGhpcy5JQ0VcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy53b3JrZXIudXBkYXRlVG9rZW4oIHRoaXMud29ya2VyVG9rZW4gKTtcbiAgICAgICAgICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0luZm9NZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArIEN0aU1lc3NhZ2VzLk1FU1NBR0VfVVBEQVRFX0RFVklDRV9TVUNDRVNTKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2gobWVzc2FnZSl7XG4gICAgICAgICAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dFcnJvck1lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICtcbiAgICAgICAgICAgICAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfVE9LRU5fVVBEQVRFX0ZBSUxVUkUgK1xuICAgICAgICAgICAgICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9BUFBFTkRFUiArIG1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuZmFpbCgobWVzc2FnZTogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0Vycm9yTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgK1xuICAgICAgICAgICAgICAgICAgICBDdGlNZXNzYWdlcy5NRVNTQUdFX1RPS0VOX1VQREFURV9GQUlMVVJFICtcbiAgICAgICAgICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9BUFBFTkRFUiArIG1lc3NhZ2UpO1xuICAgICAgICAgICAgfSlcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogTG9nIGEgZ2l2ZW4gbWVzc2FnZSBvbiBzZXJ2ZXJcbiAgICAgKlxuICAgICAqIEBwYXJhbSBzZXNzaW9uSWRcbiAgICAgKiBAcGFyYW0gbWVzc2FnZVxuICAgICAqL1xuICAgIHB1YmxpYyBsb2dBdWRpdE1lc3NhZ2Uoc2Vzc2lvbklkOiBzdHJpbmcsIG1lc3NhZ2U6IHN0cmluZykge1xuICAgICAgICAkLmFqYXgoe1xuICAgICAgICAgICAgICAgIHR5cGU6IFwiUE9TVFwiLFxuICAgICAgICAgICAgICAgIHVybDogdGhpcy5zZXJ2ZXJVUkkgKyBcIi9sb2dDYWxsQWN0aW9uXCIsXG4gICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgICBzZXNzaW9uX2lkOiBzZXNzaW9uSWQsXG4gICAgICAgICAgICAgICAgICAgIGFjdGlvbjogbWVzc2FnZVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuZG9uZSggKGRhdGE6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgK1xuICAgICAgICAgICAgICAgICAgICBDdGlNZXNzYWdlcy5NRVNTQUdFX0xPR19BQ1RJT04gK1xuICAgICAgICAgICAgICAgICAgICBDdGlNZXNzYWdlcy5NRVNTQUdFX0FQUEVOREVSICsgbWVzc2FnZSk7XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmZhaWwoKG1lc3NhZ2U6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dFcnJvck1lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICtcbiAgICAgICAgICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9MT0dfQVRJT05fRkFJTFVSRSArXG4gICAgICAgICAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfQVBQRU5ERVIgKyBtZXNzYWdlKTtcbiAgICAgICAgICAgIH0pXG4gICAgfVxuXG5cbiAgICAvKipcbiAgICAgKiBpbml0aWFsaXplVHdpbGlvRGV2aWNlIC0gVGhpcyBtZXRob2QgaW5pdGlhbGl6ZXMgdGhlIFR3aWxpbyBEZXZpY2Ugb24gbG9naW4gc3VjY2Vzcy5cbiAgICAgKlxuICAgICAqIEF0dGFjaGluZyBoYW5kbGVycyBmb3IgVHdpbGlvLkRldmljZS5pbmNvbWluZyBhbmQgVHdpbGlvLkRldmljZS5jb25uZWN0XG4gICAgICogaGFzIHRvIGJlIGRvbmUgb25seSBvbmNlIG9uIGZpcnN0IGxvZ2luLiBSZXBlYXRlZCBhdHRhY2htZW50cyB3aWxsIHJlc3VsdFxuICAgICAqIGluIG11bHRpcGxlIGludm9jYXRpb24gb2YgaGFuZGxlcnMuXG4gICAgICpcbiAgICAgKiBAcGFyYW0gZGF0YVxuICAgICAqL1xuICAgIHByaXZhdGUgaW5pdGlhbGl6ZVR3aWxpb0RldmljZSA9IChkYXRhOiBhbnkpID0+IHtcbiAgICAgICAgdGhpcy5kZXF1ZXVlQ29uZmlnSWQgPSBkYXRhLmNvbmZpZy5udW1iZXI7XG4gICAgICAgIHRoaXMuZGV2aWNlVG9rZW4gPSBkYXRhLmRldmljZTtcbiAgICAgICAgdGhpcy53b3JrZXJUb2tlbiA9IGRhdGEud29ya2VyO1xuICAgICAgICB0aGlzLnJvdXRlcyA9IGRhdGEuY29uZmlnLnJvdXRlcztcbiAgICAgICAgdGhpcy5JQ0UgPWRhdGEuSUNFO1xuXG4gICAgICAgIGlmKHRoaXMuZmlyc3RMb2dpbil7XG4gICAgICAgICAgICBDdGlMb2dnZXIubG9nSW5mb01lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICtcbiAgICAgICAgICAgICAgICBDdGlNZXNzYWdlcy5NRVNTQUdFX0RFVklDRV9JTklUSUFMSVpFICk7XG5cbiAgICAgICAgICAgIFR3aWxpby5EZXZpY2Uuc2V0dXAoIHRoaXMuZGV2aWNlVG9rZW4sIHtcbiAgICAgICAgICAgICAgICBpY2VTZXJ2ZXJzOiBkYXRhLklDRVxuICAgICAgICAgICAgfSApO1xuXG4gICAgICAgICAgICBUd2lsaW8uRGV2aWNlLmluY29taW5nKCAoY29ubjogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0luZm9NZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArXG4gICAgICAgICAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfSU5DT01JTkdfQ09OTkVDVElPTisgY29ubi5wYXJhbWV0ZXJzLkZyb20pO1xuICAgICAgICAgICAgICAgIGNvbm4uYWNjZXB0KCk7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgVHdpbGlvLkRldmljZS5jb25uZWN0KCAoY29ubjogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0luZm9NZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArXG4gICAgICAgICAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfQ09OTkVDVElPTl9FU1RBQkxJU0hFRCk7XG4gICAgICAgICAgICAgICAgdmFyIGRhdGEgPSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRhY3Q6IHRoaXMuY29udGFjdEluZm8sXG4gICAgICAgICAgICAgICAgICAgIGluY2lkZW50OiB0aGlzLmluY2lkZW50SWQsXG5cbiAgICAgICAgICAgICAgICAgICAgaGFuZ3VwOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25uLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlQWN0aXZpdHkoXCJSZWFkeVwiKTtcbiAgICAgICAgICAgICAgICAgICAgfSxcblxuICAgICAgICAgICAgICAgICAgICBtdXRlOiAoIGZsYWcgKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25uLm11dGUoIGZsYWcgKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgdGhpcy5jYWxsU2lkID0gY29ubi5wYXJhbWV0ZXJzLkNhbGxTaWQ7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXJ2ZXJFdmVudEhhbmRsZXIuZGVzcGF0Y2goIFwiY29ubmVjdGVkXCIsIGRhdGEgKTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBUd2lsaW8uRGV2aWNlLmRpc2Nvbm5lY3QoIChjb25uOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgICBDdGlMb2dnZXIubG9nSW5mb01lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICtcbiAgICAgICAgICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9DT05ORUNUSU9OX0JST0tFKTtcbiAgICAgICAgICAgICAgICB0aGlzLmF0dHJpYnV0ZXMgPW51bGw7XG4gICAgICAgICAgICAgICAgdGhpcy5pbmNpZGVudElkID0gbnVsbDtcbiAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZUFjdGl2aXR5KFwiUmVhZHlcIik7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXJ2ZXJFdmVudEhhbmRsZXIuZGVzcGF0Y2goIFwiZGlzY29ubmVjdGVkXCIsIHt9ICk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmKHRoaXMud29ya2VyVG9rZW4gPT0gbnVsbCl7XG4gICAgICAgICAgICB0aHJvdyhcIldvcmtlciB0b2tlbiBpcyBudWxsLiBDYW5ub3QgcHJvdmlkZSBhY2Nlc3MgdG8gVHdpbGlvIGZvciB0aGlzIHVzZXIuXCIpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy53b3JrZXIgPSBuZXcgVHdpbGlvLlRhc2tSb3V0ZXIuV29ya2VyKCB0aGlzLndvcmtlclRva2VuICk7XG5cbiAgICAgICAgdGhpcy53b3JrZXIub24oXCJyZWFkeVwiLCAgKCB3b3JrZXI6IGFueSApID0+IHtcbiAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgKyBcIldvcmtlciBcIiArIHdvcmtlci5mcmllbmRseU5hbWUgKyBcIiBpcyByZWFkeVwiKTtcbiAgICAgICAgICAgIHRoaXMubG9nZ2VkSW4gPSB0cnVlO1xuICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0luZm9NZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArXG4gICAgICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9ESVNQQVRDSF9MT0dJTl9TVUNDRVNTKTtcbiAgICAgICAgICAgIHRoaXMuc2VydmVyRXZlbnRIYW5kbGVyLmRlc3BhdGNoKCAnbG9naW4uc3VjY2VzcycsIG5hbWUgKTtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlQWN0aXZpdHkoXCJSZWFkeVwiKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy53b3JrZXIub24oXCJyZXNlcnZhdGlvbi5jcmVhdGVkXCIsIChyZXNlcnZhdGlvbjogYW55KSA9PiB7XG4gICAgICAgICAgICBDdGlMb2dnZXIubG9nSW5mb01lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICtcbiAgICAgICAgICAgICAgICBDdGlNZXNzYWdlcy5NRVNTQUdFX1JFU0VSVkFUSU9OX0NSRUFURUQpO1xuICAgICAgICAgICAgdGhpcy5yZXNlcnZhdGlvbiA9IHJlc2VydmF0aW9uO1xuICAgICAgICAgICAgdmFyIHBob25lID0gcmVzZXJ2YXRpb24udGFzay5hdHRyaWJ1dGVzLmZyb207XG4gICAgICAgICAgICB0aGlzLmF0dHJpYnV0ZXMgPSByZXNlcnZhdGlvbi50YXNrLmF0dHJpYnV0ZXM7XG4gICAgICAgICAgICBwaG9uZSA9IHBob25lLnJlcGxhY2UoXCJjbGllbnQ6XCIsXCJcIik7XG4gICAgICAgICAgICB2YXIgdGltZW91dCA9IDMwO1xuXG4gICAgICAgICAgICB2YXIgY29udGFjdDogYW55ID0gcmVzZXJ2YXRpb24udGFzay5hdHRyaWJ1dGVzLmNvbnRhY3Q7XG4gICAgICAgICAgICB0aGlzLmluY2lkZW50SWQgPSByZXNlcnZhdGlvbi50YXNrLmF0dHJpYnV0ZXMuaW5jaWRlbnQ7XG5cbiAgICAgICAgICAgIGNvbnRhY3RbJ25hbWUnXSA9IGNvbnRhY3QuZmlyc3ROYW1lICsgXCIgXCIgKyBjb250YWN0Lmxhc3ROYW1lO1xuICAgICAgICAgICAgdGhpcy5jb250YWN0SW5mbyA9IGNvbnRhY3Q7XG5cbiAgICAgICAgICAgIHZhciBkYXRhID0ge1xuICAgICAgICAgICAgICAgIHRpbWVvdXQ6IHRpbWVvdXQsXG5cbiAgICAgICAgICAgICAgICBhY2NlcHQ6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KCB0aGlzLnRpbWVvdXRIYW5kbGUgKTtcbiAgICAgICAgICAgICAgICAgICAgcmVzZXJ2YXRpb24uZGVxdWV1ZSggdGhpcy5kZXF1ZXVlQ29uZmlnSWQgKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHJlamVjdDogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQoIHRoaXMudGltZW91dEhhbmRsZSApO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmF0dHJpYnV0ZXMgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmluY2lkZW50SWQgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICByZXNlcnZhdGlvbi5yZWplY3QoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICBkYXRhW1wiY29udGFjdFwiXSA9IGNvbnRhY3Q7XG4gICAgICAgICAgICB0aGlzLnRpbWVvdXRIYW5kbGUgPSBzZXRUaW1lb3V0KCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXJ2ZXJFdmVudEhhbmRsZXIuZGVzcGF0Y2goIFwidGltZW91dFwiLCB7fSApO1xuICAgICAgICAgICAgICAgIGlmKHRoaXMucmVzZXJ2YXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yZXNlcnZhdGlvbi5yZWplY3QoKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yZXNlcnZhdGlvbiA9IG51bGw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMuYXR0cmlidXRlcyA9IG51bGw7XG4gICAgICAgICAgICAgICAgdGhpcy5pbmNpZGVudElkID0gbnVsbDtcbiAgICAgICAgICAgIH0sIHRpbWVvdXQgKiAxMDAwICk7XG4gICAgICAgICAgICB0aGlzLnNlcnZlckV2ZW50SGFuZGxlci5kZXNwYXRjaCggXCJpbmNvbWluZ1wiLCBkYXRhICk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMud29ya2VyLm9uKFwicmVzZXJ2YXRpb24uY2FuY2VsZWRcIiwgKHJlc2VydmF0aW9uKSA9PiB7XG4gICAgICAgICAgICBDdGlMb2dnZXIubG9nSW5mb01lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICtcbiAgICAgICAgICAgICAgICBDdGlNZXNzYWdlcy5NRVNTQUdFX1JFU0VSVkFUSU9OX0NBTkNFTExFRCk7XG4gICAgICAgICAgICB0aGlzLmF0dHJpYnV0ZXMgPSBudWxsO1xuICAgICAgICAgICAgdGhpcy5pbmNpZGVudElkID0gbnVsbDtcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCggdGhpcy50aW1lb3V0SGFuZGxlICk7XG4gICAgICAgICAgICB0aGlzLnNlcnZlckV2ZW50SGFuZGxlci5kZXNwYXRjaCggXCJjYW5jZWxlZFwiLCB7fSApO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLndvcmtlci5vbihcInJlc2VydmF0aW9uLmFjY2VwdGVkXCIsIChyZXNlcnZhdGlvbikgPT4ge1xuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KCB0aGlzLnRpbWVvdXRIYW5kbGUgKTtcbiAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgK1xuICAgICAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfUkVTRVJWQVRJT05fQUNDRVBURUQpO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLndvcmtlci5vbihcInJlc2VydmF0aW9uLnJlamVjdGVkXCIsIChyZXNlcnZhdGlvbikgPT4ge1xuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KCB0aGlzLnRpbWVvdXRIYW5kbGUgKTtcbiAgICAgICAgICAgIHRoaXMuYXR0cmlidXRlcyA9IG51bGw7XG4gICAgICAgICAgICB0aGlzLmluY2lkZW50SWQgPSBudWxsO1xuICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0luZm9NZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArXG4gICAgICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9SRVNFUlZBVElPTl9SRUpFQ1RFRCk7XG4gICAgICAgICAgICB0aGlzLnNlcnZlckV2ZW50SGFuZGxlci5kZXNwYXRjaCggXCJjYW5jZWxlZFwiLCB7fSApO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLndvcmtlci5vbihcInRva2VuLmV4cGlyZWRcIiwgKCkgPT4ge1xuICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0luZm9NZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArXG4gICAgICAgICAgICAgICAgQ3RpTWVzc2FnZXMuTUVTU0FHRV9UT0tFTl9FWFBJUkVEKTtcbiAgICAgICAgICAgIHRoaXMuc2VydmVyRXZlbnRIYW5kbGVyLmRlc3BhdGNoKCd0b2tlbi5leHBpcmVkJywge30pO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLndvcmtlci5vbihcImFjdGl2aXR5LnVwZGF0ZVwiLCAod29ya2VyKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnNlcnZlckV2ZW50SGFuZGxlci5kZXNwYXRjaCggJ2FjdGl2aXR5LnVwZGF0ZScsIHdvcmtlci5hY3Rpdml0eU5hbWUgKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy53b3JrZXIuYWN0aXZpdGllcy5mZXRjaChcbiAgICAgICAgICAgIChlcnJvcjogYW55LCBhY3Rpdml0eUxpc3Q6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dFcnJvck1lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICsgZXJyb3IuY29kZSk7XG4gICAgICAgICAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dFcnJvck1lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICsgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdmFyIGRhdGEgPSBhY3Rpdml0eUxpc3QuZGF0YTtcbiAgICAgICAgICAgICAgICBmb3IodmFyIGk9MDsgaTxkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWN0aXZpdGllc1tkYXRhW2ldLmZyaWVuZGx5TmFtZV0gPSBkYXRhW2ldLnNpZDtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB0aGlzLndvcmtlci51cGRhdGUoXCJBY3Rpdml0eVNpZFwiLCB0aGlzLmFjdGl2aXRpZXNbXCJSZWFkeVwiXSwgKGVycm9yLCB3b3JrZXIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dFcnJvck1lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICsgZXJyb3IuY29kZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBDdGlMb2dnZXIubG9nRXJyb3JNZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0luZm9NZXNzYWdlKHdvcmtlci5hY3Rpdml0eU5hbWUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgfTtcblxufSJdfQ==