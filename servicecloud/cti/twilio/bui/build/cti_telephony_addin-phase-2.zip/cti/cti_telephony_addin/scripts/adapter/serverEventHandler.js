define(["require", "exports", "jquery", "../util/ctiLogger", "../util/ctiMessages"], function (require, exports, $, ctiLogger_1, ctiMessages_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ServerEventHandler = void 0;
    var ServerEventHandler = (function () {
        function ServerEventHandler() {
            this.store = {
                'reservation.created': [],
                'reservation.timeout': [],
                'token.expired': [],
                'cti.enabled': [],
                'cti.disabled': [],
                'activity.update': [],
                'login.success': [],
                'login.failed': [],
                'incoming': [],
                'connected': [],
                'disconnected': [],
                'timeout': [],
                'canceled': [],
                'search.contact.complete': [],
                'search.contact.failed': [],
                'search.agentlist.complete': []
            };
            this.logPreMessage = 'ServerEventHandler' + ctiMessages_1.CtiMessages.MESSAGE_APPENDER;
        }
        ServerEventHandler.prototype.on = function (handle, event) {
            if (typeof event !== 'function') {
                if ((typeof event === 'object') && (typeof event.func !== 'function')) {
                    return;
                }
            }
            if (!(handle in this.store)) {
                return;
            }
            this.store[handle].push(event);
            return this;
        };
        ServerEventHandler.prototype.off = function (handle) {
            if (!(handle in this.store)) {
                return;
            }
            this.store[handle] = [];
            return this;
        };
        ServerEventHandler.prototype.despatch = function (handle, data) {
            var _this = this;
            if (!(handle in this.store)) {
                return;
            }
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_EVENT_DISPATCH
                + ctiMessages_1.CtiMessages.MESSAGE_APPENDER + handle + ctiMessages_1.CtiMessages.MESSAGE_WITH_DATA + ctiMessages_1.CtiMessages.MESSAGE_APPENDER + JSON.stringify(data));
            $.each(this.store[handle], function (idx) {
                var func = _this.store[handle][idx];
                if (typeof func === 'object') {
                    func.count--;
                    func.func(data);
                    if (func.count <= 0) {
                        _this.store[handle].splice(idx, 1);
                    }
                    return _this;
                }
                func(data);
            });
            return this;
        };
        return ServerEventHandler;
    }());
    exports.ServerEventHandler = ServerEventHandler;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmVyRXZlbnRIYW5kbGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsic2VydmVyRXZlbnRIYW5kbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7SUFtQkE7UUFBQTtZQUVVLFVBQUssR0FBTztnQkFFbEIscUJBQXFCLEVBQUUsRUFBRTtnQkFDekIscUJBQXFCLEVBQUUsRUFBRTtnQkFDekIsZUFBZSxFQUFFLEVBQUU7Z0JBR25CLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixjQUFjLEVBQUUsRUFBRTtnQkFDbEIsaUJBQWlCLEVBQUUsRUFBRTtnQkFDckIsZUFBZSxFQUFFLEVBQUU7Z0JBQ25CLGNBQWMsRUFBRSxFQUFFO2dCQUNsQixVQUFVLEVBQUUsRUFBRTtnQkFDZCxXQUFXLEVBQUUsRUFBRTtnQkFDZixjQUFjLEVBQUUsRUFBRTtnQkFDbEIsU0FBUyxFQUFFLEVBQUU7Z0JBQ2IsVUFBVSxFQUFFLEVBQUU7Z0JBQ2QseUJBQXlCLEVBQUUsRUFBRTtnQkFDN0IsdUJBQXVCLEVBQUUsRUFBRTtnQkFDM0IsMkJBQTJCLEVBQUUsRUFBRTthQUNoQyxDQUFDO1lBRU0sa0JBQWEsR0FBVyxvQkFBb0IsR0FBRyx5QkFBVyxDQUFDLGdCQUFnQixDQUFDO1FBbUV0RixDQUFDO1FBMURRLCtCQUFFLEdBQVQsVUFBVSxNQUFXLEVBQUUsS0FBVTtZQUMvQixJQUFJLE9BQU8sS0FBSyxLQUFLLFVBQVUsRUFBRTtnQkFDL0IsSUFBSSxDQUFFLE9BQU8sS0FBSyxLQUFLLFFBQVEsQ0FBRSxJQUFJLENBQUUsT0FBTyxLQUFLLENBQUMsSUFBSSxLQUFLLFVBQVUsQ0FBRSxFQUFFO29CQUN6RSxPQUFPO2lCQUNSO2FBQ0Y7WUFFRCxJQUFJLENBQUMsQ0FBRSxNQUFNLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBRSxFQUFFO2dCQUM3QixPQUFPO2FBQ1I7WUFFRCxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMvQixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFRTSxnQ0FBRyxHQUFWLFVBQVcsTUFBVztZQUNwQixJQUFJLENBQUMsQ0FBRSxNQUFNLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBRSxFQUFFO2dCQUM3QixPQUFPO2FBQ1I7WUFFRCxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUN4QixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFTTSxxQ0FBUSxHQUFmLFVBQWdCLE1BQVcsRUFBRSxJQUFTO1lBQXRDLGlCQW1CQztZQWxCQyxJQUFJLENBQUMsQ0FBRSxNQUFNLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBRSxFQUFFO2dCQUM3QixPQUFPO2FBQ1I7WUFDRCxxQkFBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsYUFBYSxHQUFHLHlCQUFXLENBQUMsc0JBQXNCO2tCQUM1RSx5QkFBVyxDQUFDLGdCQUFnQixHQUFHLE1BQU0sR0FBRyx5QkFBVyxDQUFDLGlCQUFpQixHQUFHLHlCQUFXLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ2pJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxVQUFDLEdBQUc7Z0JBQzdCLElBQUksSUFBSSxHQUFHLEtBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ25DLElBQUksT0FBTyxJQUFJLEtBQUssUUFBUSxFQUFFO29CQUM1QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDaEIsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsRUFBRTt3QkFDbkIsS0FBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO3FCQUNuQztvQkFDRCxPQUFPLEtBQUksQ0FBQztpQkFDYjtnQkFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDYixDQUFDLENBQUMsQ0FBQztZQUNILE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUVILHlCQUFDO0lBQUQsQ0FBQyxBQTNGRCxJQTJGQztJQTNGWSxnREFBa0IiLCJzb3VyY2VzQ29udGVudCI6WyIvKiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAkQUNDRUxFUkFUT1JfSEVBREVSX1BMQUNFX0hPTERFUiRcbiAqICBTSEExOiAkSWQ6IDM3MzZjODY1YTI4NzA3Yjg0MjdkOTdhMTgzZjNiMjMxYTYxNWFjOWQgJFxuICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgRmlsZTogJEFDQ0VMRVJBVE9SX0hFQURFUl9GSUxFX05BTUVfUExBQ0VfSE9MREVSJFxuICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqICovXG5cbmltcG9ydCAkID0gcmVxdWlyZSgnanF1ZXJ5Jyk7XG5pbXBvcnQge0N0aUxvZ2dlcn0gZnJvbSBcIi4uL3V0aWwvY3RpTG9nZ2VyXCI7XG5pbXBvcnQge0N0aU1lc3NhZ2VzfSBmcm9tIFwiLi4vdXRpbC9jdGlNZXNzYWdlc1wiO1xuLyoqXG4gKiBTZXJ2ZXJFdmVudEhhbmRsZXIgLSBUaGlzIGNsYXNzIGRlZmluZXMgYW5kIGhhbmRsZXMgdGhlIGV2ZW50cyB1c2VkIGZvciBjb21tdW5pY2F0aW9uXG4gKiBiZXR3ZWVuIGFkZGluIGFuZCB0aGUgYWRhcHRlci4gVGhpcyBhY3RzIGFzIHB1Yi1zdWIgc3lzdGVtIGZvciB0aGUgQ1RJIGFkZGluLlxuICpcbiAqIEl0IHN0b3JlcyBoYW5kbGVycyBmb3IgdmFyaW91cyBldmVudHMgYW5kIGludm9rZXMgdGhlbSB3aGVuIGFuIGV2ZW50IG9jY3Vycy5cbiAqXG4gKiBXZSBjYW4gYWRkIHJlcXVpcmVkIGV2ZW50cyBpbiB0aGUgc3RvcmUgYW5kIHJlZ2lzdGVyIGhhbmRsZXJzLiBsYXRlciB3aGVuIHdlIGRlc3BhdGNoXG4gKiBhbiBldmVudCwgdGhlIGNvcnJlc3BvbmRpbmcgaGFuZGxlciB3aWxsIGJlIGludm9rZWRcbiAqL1xuZXhwb3J0IGNsYXNzIFNlcnZlckV2ZW50SGFuZGxlciB7XG5cbiAgcHJpdmF0ZSBzdG9yZTphbnkgPSB7XG4gICAgLy8gSW50ZXJuYWwgRXZlbnRzXG4gICAgJ3Jlc2VydmF0aW9uLmNyZWF0ZWQnOiBbXSxcbiAgICAncmVzZXJ2YXRpb24udGltZW91dCc6IFtdLFxuICAgICd0b2tlbi5leHBpcmVkJzogW10sXG5cbiAgICAvLyBBcHBsaWNhdGlvbiBsZXZlbCBldmVudHNcbiAgICAnY3RpLmVuYWJsZWQnOiBbXSxcbiAgICAnY3RpLmRpc2FibGVkJzogW10sXG4gICAgJ2FjdGl2aXR5LnVwZGF0ZSc6IFtdLFxuICAgICdsb2dpbi5zdWNjZXNzJzogW10sXG4gICAgJ2xvZ2luLmZhaWxlZCc6IFtdLFxuICAgICdpbmNvbWluZyc6IFtdLFxuICAgICdjb25uZWN0ZWQnOiBbXSxcbiAgICAnZGlzY29ubmVjdGVkJzogW10sXG4gICAgJ3RpbWVvdXQnOiBbXSxcbiAgICAnY2FuY2VsZWQnOiBbXSxcbiAgICAnc2VhcmNoLmNvbnRhY3QuY29tcGxldGUnOiBbXSxcbiAgICAnc2VhcmNoLmNvbnRhY3QuZmFpbGVkJzogW10sXG4gICAgJ3NlYXJjaC5hZ2VudGxpc3QuY29tcGxldGUnOiBbXVxuICB9O1xuXG4gIHByaXZhdGUgbG9nUHJlTWVzc2FnZTogc3RyaW5nID0gJ1NlcnZlckV2ZW50SGFuZGxlcicgKyBDdGlNZXNzYWdlcy5NRVNTQUdFX0FQUEVOREVSO1xuXG4gIC8qKlxuICAgKiBCaW5kcyBoYW5kbGVyIHRvIGFuIGV2ZW50XG4gICAqXG4gICAqIEBwYXJhbSBoYW5kbGVcbiAgICogQHBhcmFtIGV2ZW50XG4gICAqIEByZXR1cm5zIHt0aGlzfVxuICAgKi9cbiAgcHVibGljIG9uKGhhbmRsZTogYW55LCBldmVudDogYW55KTpTZXJ2ZXJFdmVudEhhbmRsZXIge1xuICAgIGlmICh0eXBlb2YgZXZlbnQgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGlmICgoIHR5cGVvZiBldmVudCA9PT0gJ29iamVjdCcgKSAmJiAoIHR5cGVvZiBldmVudC5mdW5jICE9PSAnZnVuY3Rpb24nICkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICghKCBoYW5kbGUgaW4gdGhpcy5zdG9yZSApKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdGhpcy5zdG9yZVtoYW5kbGVdLnB1c2goZXZlbnQpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbW92ZXMgaGFuZGxlciBmb3IgYW4gZXZlbnRcbiAgICpcbiAgICogQHBhcmFtIGhhbmRsZVxuICAgKiBAcmV0dXJucyB7dGhpc31cbiAgICovXG4gIHB1YmxpYyBvZmYoaGFuZGxlOiBhbnkpOlNlcnZlckV2ZW50SGFuZGxlciB7XG4gICAgaWYgKCEoIGhhbmRsZSBpbiB0aGlzLnN0b3JlICkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0aGlzLnN0b3JlW2hhbmRsZV0gPSBbXTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qKlxuICAgKiBJbnZva2UgYW4gZXZlbnQgaGFuZGxlciBhbG9uZyB3aXRoIGFzc29jaWF0ZWQgZGF0YVxuICAgKlxuICAgKiBAcGFyYW0gaGFuZGxlXG4gICAqIEBwYXJhbSBkYXRhXG4gICAqIEByZXR1cm5zIHt0aGlzfVxuICAgKi9cbiAgcHVibGljIGRlc3BhdGNoKGhhbmRsZTogYW55LCBkYXRhOiBhbnkpOlNlcnZlckV2ZW50SGFuZGxlciB7XG4gICAgaWYgKCEoIGhhbmRsZSBpbiB0aGlzLnN0b3JlICkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgQ3RpTG9nZ2VyLmxvZ0luZm9NZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArIEN0aU1lc3NhZ2VzLk1FU1NBR0VfRVZFTlRfRElTUEFUQ0hcbiAgICAgICsgQ3RpTWVzc2FnZXMuTUVTU0FHRV9BUFBFTkRFUiArIGhhbmRsZSArIEN0aU1lc3NhZ2VzLk1FU1NBR0VfV0lUSF9EQVRBICsgQ3RpTWVzc2FnZXMuTUVTU0FHRV9BUFBFTkRFUiArIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcbiAgICAkLmVhY2godGhpcy5zdG9yZVtoYW5kbGVdLCAoaWR4KT0+IHtcbiAgICAgIHZhciBmdW5jID0gdGhpcy5zdG9yZVtoYW5kbGVdW2lkeF07XG4gICAgICBpZiAodHlwZW9mIGZ1bmMgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGZ1bmMuY291bnQtLTtcbiAgICAgICAgZnVuYy5mdW5jKGRhdGEpO1xuICAgICAgICBpZiAoZnVuYy5jb3VudCA8PSAwKSB7XG4gICAgICAgICAgdGhpcy5zdG9yZVtoYW5kbGVdLnNwbGljZShpZHgsIDEpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgfVxuICAgICAgZnVuYyhkYXRhKTtcbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG59XG4iXX0=