define(["require", "exports", "./../util/ctiConstants"], function (require, exports, ctiConstants_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CtiTelephonyAddinInitializer = void 0;
    var CtiTelephonyAddinInitializer = exports.CtiTelephonyAddinInitializer = (function () {
        function CtiTelephonyAddinInitializer() {
        }
        CtiTelephonyAddinInitializer.getAbsolutePath = function () {
            var base = window.location.href;
            var relative = CtiTelephonyAddinInitializer.addinFilePath;
            var stack = base.split("/"), parts = relative.split("/");
            stack.pop();
            for (var i = 0; i < parts.length; i++) {
                if (parts[i] == ".")
                    continue;
                if (parts[i] == "..")
                    stack.pop();
                else
                    stack.push(parts[i]);
            }
            return stack.join("/");
        };
        CtiTelephonyAddinInitializer.initialize = function () {
            ORACLE_SERVICE_CLOUD.extension_loader.load(ctiConstants_1.CtiConstants.BUI_CTI_ADDIN_ID, ctiConstants_1.CtiConstants.BUI_CTI_ADDIN_VERSION).then(function (sdk) {
                sdk.registerUserInterfaceExtension(function (userInterfaceContext) {
                    userInterfaceContext.getLeftSidePaneContext().then(function (leftSidePaneContext) {
                        leftSidePaneContext.getSidePane(ctiConstants_1.CtiConstants.BUI_CTI_LEFT_PANEL_MENU_ID).then(function (leftPanelMenu) {
                            leftPanelMenu.setContentUrl(CtiTelephonyAddinInitializer.getAbsolutePath());
                            leftPanelMenu.setLabel(ctiConstants_1.CtiConstants.BUI_CTI_LEFT_PANEL_MENU_DEFAULT_LABEL);
                            leftPanelMenu.setVisible(false);
                            var icon = leftPanelMenu.createIcon(ctiConstants_1.CtiConstants.BUI_CTI_LEFT_PANEL_ICON_TYPE);
                            icon.setIconClass(ctiConstants_1.CtiConstants.BUI_CTI_LEFT_PANEL_ICON);
                            leftPanelMenu.addIcon(icon);
                            leftPanelMenu.render();
                        });
                    });
                });
            });
        };
        CtiTelephonyAddinInitializer.addinFilePath = 'ctiTelephonyAddin.html';
        return CtiTelephonyAddinInitializer;
    }());
    CtiTelephonyAddinInitializer.initialize();
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3RpVGVsZXBob255QWRkaW5Jbml0aWFsaXplci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImN0aVRlbGVwaG9ueUFkZGluSW5pdGlhbGl6ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztJQW9CQTtRQUFBO1FBbURBLENBQUM7UUExQ2dCLDRDQUFlLEdBQTlCO1lBQ0UsSUFBSSxJQUFJLEdBQVcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7WUFDeEMsSUFBSSxRQUFRLEdBQVcsNEJBQTRCLENBQUMsYUFBYSxDQUFDO1lBQ2xFLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQ3pCLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzlCLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNaLEtBQUssSUFBSSxDQUFDLEdBQUMsQ0FBQyxFQUFFLENBQUMsR0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNqQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHO29CQUNqQixTQUFTO2dCQUNYLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUk7b0JBQ2xCLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQzs7b0JBRVosS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN4QjtZQUNELE9BQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN6QixDQUFDO1FBUWEsdUNBQVUsR0FBeEI7WUFDRSxvQkFBb0IsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsMkJBQVksQ0FBQyxnQkFBZ0IsRUFBRSwyQkFBWSxDQUFDLHFCQUFxQixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsR0FBRztnQkFDckgsR0FBRyxDQUFDLDhCQUE4QixDQUFDLFVBQUMsb0JBQW9CO29CQUN0RCxvQkFBb0IsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDLElBQUksQ0FDaEQsVUFBQyxtQkFBbUI7d0JBQ2xCLG1CQUFtQixDQUFDLFdBQVcsQ0FBQywyQkFBWSxDQUFDLDBCQUEwQixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsYUFBYTs0QkFDMUYsYUFBYSxDQUFDLGFBQWEsQ0FBQyw0QkFBNEIsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDOzRCQUM1RSxhQUFhLENBQUMsUUFBUSxDQUFDLDJCQUFZLENBQUMscUNBQXFDLENBQUMsQ0FBQzs0QkFDM0UsYUFBYSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQzs0QkFDaEMsSUFBSSxJQUFJLEdBQUcsYUFBYSxDQUFDLFVBQVUsQ0FBQywyQkFBWSxDQUFDLDRCQUE0QixDQUFDLENBQUM7NEJBQy9FLElBQUksQ0FBQyxZQUFZLENBQUMsMkJBQVksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDOzRCQUN4RCxhQUFhLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDOzRCQUM1QixhQUFhLENBQUMsTUFBTSxFQUFFLENBQUM7d0JBQ3pCLENBQUMsQ0FBQyxDQUFDO29CQUNMLENBQUMsQ0FDRixDQUFDO2dCQUNKLENBQUMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO1FBakRjLDBDQUFhLEdBQVUsd0JBQXdCLENBQUM7UUFrRGpFLG1DQUFDO0tBQUEsQUFuREQsSUFtREM7SUFHRCw0QkFBNEIsQ0FBQyxVQUFVLEVBQUUsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICRBQ0NFTEVSQVRPUl9IRUFERVJfUExBQ0VfSE9MREVSJFxuICogIFNIQTE6ICRJZDogMDQzMmEyZmM2NzZkZThmNTA3YmVmOGIwNWNmN2EzMDBkYTljNGUzZSAkXG4gKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICBGaWxlOiAkQUNDRUxFUkFUT1JfSEVBREVSX0ZJTEVfTkFNRV9QTEFDRV9IT0xERVIkXG4gKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogKi9cblxuLy8vPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi9kZWZpbml0aW9ucy9vc3ZjRXh0ZW5zaW9uLmQudHMnIC8+XG5cbmltcG9ydCB7Q3RpQ29uc3RhbnRzfSBmcm9tICcuLy4uL3V0aWwvY3RpQ29uc3RhbnRzJztcbi8qKlxuICogVGhpcyBjbGFzcyBpbml0aWFsaXplcyB0aGUgQ1RJIEFkZGluLlxuICogMS4gSXQgY3JhdGVzIGEgbGVmdCBTaWRlUGFuZSBhZGRpbiwgc2V0IGlpdCdzIGNvbnRlbnQgVVJMIGFuZCBzZXQgdmlzaWJpbGl0eVxuICogICAgdG8gZmFsc2UsIHNvIHRoYXQgaXQgd2lsbCBiZSByZW5kZXJlZCBvbmx5IGFmdGVyIGFnZW50IGxvZ2luIHRvIHRoZSB0b29sXG4gKlxuICogMi4gV2hlbiB0aGUgY29udGVudCBpcyBkb3dubG9hZGVkLCBpdCBleGVjdXRlcyB0aGUgQ3RpQ29uc29sZUFkZGluLmluaXRpYWxpemUoKVxuICogICAgZnVuY3Rpb24gd2hpY2ggaW4gdHVybiByZW5kZXIgdGhlIEdsb2JhbEhlYWRlck1lbnUgaWNvbiB3aXRoIHRoZVxuICogICAgbG9naW4gb3B0aW9uXG4gKlxuICovXG5leHBvcnQgY2xhc3MgQ3RpVGVsZXBob255QWRkaW5Jbml0aWFsaXplciB7XG4gIHByaXZhdGUgc3RhdGljIGFkZGluRmlsZVBhdGg6c3RyaW5nID0gJ2N0aVRlbGVwaG9ueUFkZGluLmh0bWwnO1xuXG4gIC8qKlxuICAgKiBUaGlzIGZ1bmN0aW9uIGNhbGN1bGF0ZXMgdGhlIGFic29sdXRlIGZpbGUgcGF0aFxuICAgKiBmb3IgdGhlIGFkZGluIGh0bWxcbiAgICogXG4gICAqIEByZXR1cm5zIHtzdHJpbmd9XG4gICAqL1xuICBwcml2YXRlIHN0YXRpYyBnZXRBYnNvbHV0ZVBhdGgoKTogc3RyaW5nIHtcbiAgICB2YXIgYmFzZTogc3RyaW5nID0gd2luZG93LmxvY2F0aW9uLmhyZWY7XG4gICAgdmFyIHJlbGF0aXZlOiBzdHJpbmcgPSBDdGlUZWxlcGhvbnlBZGRpbkluaXRpYWxpemVyLmFkZGluRmlsZVBhdGg7XG4gICAgdmFyIHN0YWNrID0gYmFzZS5zcGxpdChcIi9cIiksXG4gICAgICBwYXJ0cyA9IHJlbGF0aXZlLnNwbGl0KFwiL1wiKTtcbiAgICBzdGFjay5wb3AoKTtcbiAgICBmb3IgKHZhciBpPTA7IGk8cGFydHMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmIChwYXJ0c1tpXSA9PSBcIi5cIilcbiAgICAgICAgY29udGludWU7XG4gICAgICBpZiAocGFydHNbaV0gPT0gXCIuLlwiKVxuICAgICAgICBzdGFjay5wb3AoKTtcbiAgICAgIGVsc2VcbiAgICAgICAgc3RhY2sucHVzaChwYXJ0c1tpXSk7XG4gICAgfVxuICAgIHJldHVybiBzdGFjay5qb2luKFwiL1wiKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGlzIHRoZSBlbnRyeSBwb2ludCBvZiBDVEkgQWRkaW4uXG4gICAqIFRoaXMgZnVuY3Rpb24gaW5pdGlhbGl6ZSB0aGUgc2lkZXBhbmUgYWRkaW4sIHNldCBjb250ZW50IHVybCBhbmRcbiAgICogc2V0IHZpc2liaWxpdHkgdG8gZmFsc2UuXG4gICAqIFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBpbml0aWFsaXplKCk6dm9pZCB7XG4gICAgT1JBQ0xFX1NFUlZJQ0VfQ0xPVUQuZXh0ZW5zaW9uX2xvYWRlci5sb2FkKEN0aUNvbnN0YW50cy5CVUlfQ1RJX0FERElOX0lELCBDdGlDb25zdGFudHMuQlVJX0NUSV9BRERJTl9WRVJTSU9OKS50aGVuKChzZGspID0+IHtcbiAgICAgIHNkay5yZWdpc3RlclVzZXJJbnRlcmZhY2VFeHRlbnNpb24oKHVzZXJJbnRlcmZhY2VDb250ZXh0KSA9PiB7XG4gICAgICAgIHVzZXJJbnRlcmZhY2VDb250ZXh0LmdldExlZnRTaWRlUGFuZUNvbnRleHQoKS50aGVuKFxuICAgICAgICAgIChsZWZ0U2lkZVBhbmVDb250ZXh0KSA9PiB7XG4gICAgICAgICAgICBsZWZ0U2lkZVBhbmVDb250ZXh0LmdldFNpZGVQYW5lKEN0aUNvbnN0YW50cy5CVUlfQ1RJX0xFRlRfUEFORUxfTUVOVV9JRCkudGhlbigobGVmdFBhbmVsTWVudSkgPT4ge1xuICAgICAgICAgICAgICBsZWZ0UGFuZWxNZW51LnNldENvbnRlbnRVcmwoQ3RpVGVsZXBob255QWRkaW5Jbml0aWFsaXplci5nZXRBYnNvbHV0ZVBhdGgoKSk7XG4gICAgICAgICAgICAgIGxlZnRQYW5lbE1lbnUuc2V0TGFiZWwoQ3RpQ29uc3RhbnRzLkJVSV9DVElfTEVGVF9QQU5FTF9NRU5VX0RFRkFVTFRfTEFCRUwpO1xuICAgICAgICAgICAgICBsZWZ0UGFuZWxNZW51LnNldFZpc2libGUoZmFsc2UpO1xuICAgICAgICAgICAgICB2YXIgaWNvbiA9IGxlZnRQYW5lbE1lbnUuY3JlYXRlSWNvbihDdGlDb25zdGFudHMuQlVJX0NUSV9MRUZUX1BBTkVMX0lDT05fVFlQRSk7XG4gICAgICAgICAgICAgIGljb24uc2V0SWNvbkNsYXNzKEN0aUNvbnN0YW50cy5CVUlfQ1RJX0xFRlRfUEFORUxfSUNPTik7XG4gICAgICAgICAgICAgIGxlZnRQYW5lbE1lbnUuYWRkSWNvbihpY29uKTtcbiAgICAgICAgICAgICAgbGVmdFBhbmVsTWVudS5yZW5kZXIoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG59XG5cbi8vSW5pdGlhbGl6ZSB0aGUgYWRkaW5cbkN0aVRlbGVwaG9ueUFkZGluSW5pdGlhbGl6ZXIuaW5pdGlhbGl6ZSgpOyJdfQ==