define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.LogLevels = void 0;
    var LogLevels;
    (function (LogLevels) {
        LogLevels[LogLevels["INFO"] = 'INFO'] = "INFO";
        LogLevels[LogLevels["WARN"] = 'WARN'] = "WARN";
        LogLevels[LogLevels["ERROR"] = 'ERROR'] = "ERROR";
    })(LogLevels || (exports.LogLevels = LogLevels = {}));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9nTGV2ZWxzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibG9nTGV2ZWxzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7SUFPQSxJQUFZLFNBSVg7SUFKRCxXQUFZLFNBQVM7UUFDakIsOEJBQVksTUFBTSxVQUFBLENBQUE7UUFDbEIsOEJBQVksTUFBTSxVQUFBLENBQUE7UUFDbEIsK0JBQWEsT0FBTyxXQUFBLENBQUE7SUFDeEIsQ0FBQyxFQUpXLFNBQVMseUJBQVQsU0FBUyxRQUlwQiIsInNvdXJjZXNDb250ZW50IjpbIi8qICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICRBQ0NFTEVSQVRPUl9IRUFERVJfUExBQ0VfSE9MREVSJFxuICogIFNIQTE6ICRJZDogYmU5NDM3MDM1MzdjN2VmNTNhZTI3ZGQ0N2QxYTZkYjYzNDEyYjZhMCAkXG4gKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICBGaWxlOiAkQUNDRUxFUkFUT1JfSEVBREVSX0ZJTEVfTkFNRV9QTEFDRV9IT0xERVIkXG4gKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogKi9cblxuZXhwb3J0IGVudW0gTG9nTGV2ZWxzIHtcbiAgICBJTkZPID0gPGFueT4nSU5GTycsXG4gICAgV0FSTiA9IDxhbnk+J1dBUk4nLFxuICAgIEVSUk9SID0gPGFueT4nRVJST1InXG59XG4iXX0=