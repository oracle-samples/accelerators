define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.IconData = void 0;
    var IconData = (function () {
        function IconData() {
        }
        return IconData;
    }());
    exports.IconData = IconData;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbkRhdGEuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpY29uRGF0YS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0lBT0E7UUFBQTtRQUlBLENBQUM7UUFBRCxlQUFDO0lBQUQsQ0FBQyxBQUpELElBSUM7SUFKWSw0QkFBUSIsInNvdXJjZXNDb250ZW50IjpbIi8qICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICRBQ0NFTEVSQVRPUl9IRUFERVJfUExBQ0VfSE9MREVSJFxuICogIFNIQTE6ICRJZDogN2E2NTdlNTE3NTc0NGJhZGEzYTk5MDI4YjJiNWI4MDg5MTczYmFlNCAkXG4gKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICBGaWxlOiAkQUNDRUxFUkFUT1JfSEVBREVSX0ZJTEVfTkFNRV9QTEFDRV9IT0xERVIkXG4gKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogKi9cblxuZXhwb3J0IGNsYXNzIEljb25EYXRhIHtcbiAgY2xhc3M6IHN0cmluZztcbiAgY29sb3I6IHN0cmluZztcbiAgbGFiZWw6IHN0cmluZztcbn0iXX0=