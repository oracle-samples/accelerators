define(["require", "exports", "./logLevels"], function (require, exports, logLevels_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CtiLogger = void 0;
    var CtiLogger = (function () {
        function CtiLogger() {
        }
        CtiLogger.logMessage = function (logLevel, message) {
            if (logLevel) {
                switch (logLevel) {
                    case logLevels_1.LogLevels.ERROR:
                        CtiLogger.logErrorMessage(message);
                        break;
                    case logLevels_1.LogLevels.INFO:
                        CtiLogger.logInfoMessage(message);
                        break;
                    case logLevels_1.LogLevels.WARN:
                        CtiLogger.logWarningMessage(message);
                }
            }
        };
        CtiLogger.logWarningMessage = function (message) {
            console.warn('CTILogger >> WARNING >> ' + message);
        };
        CtiLogger.logErrorMessage = function (message) {
            console.error('CTILogger >> ERROR >> ' + message);
        };
        CtiLogger.logInfoMessage = function (message) {
            console.log('CTILogger >> INFO >> ' + message);
        };
        return CtiLogger;
    }());
    exports.CtiLogger = CtiLogger;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3RpTG9nZ2VyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY3RpTG9nZ2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7SUFRQTtRQUFBO1FBNEJBLENBQUM7UUEzQmlCLG9CQUFVLEdBQXhCLFVBQXlCLFFBQW1CLEVBQUUsT0FBZTtZQUN6RCxJQUFHLFFBQVEsRUFBRTtnQkFDVCxRQUFRLFFBQVEsRUFBQztvQkFDYixLQUFLLHFCQUFTLENBQUMsS0FBSzt3QkFDaEIsU0FBUyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQzt3QkFDbkMsTUFBTTtvQkFDVixLQUFLLHFCQUFTLENBQUMsSUFBSTt3QkFDZixTQUFTLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3dCQUNsQyxNQUFNO29CQUNWLEtBQUsscUJBQVMsQ0FBQyxJQUFJO3dCQUNmLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDNUM7YUFDSjtRQUNMLENBQUM7UUFFYSwyQkFBaUIsR0FBL0IsVUFBZ0MsT0FBZTtZQUMzQyxPQUFPLENBQUMsSUFBSSxDQUFDLDBCQUEwQixHQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3JELENBQUM7UUFFYSx5QkFBZSxHQUE3QixVQUE4QixPQUFlO1lBQ3pDLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0JBQXdCLEdBQUMsT0FBTyxDQUFDLENBQUM7UUFDcEQsQ0FBQztRQUVhLHdCQUFjLEdBQTVCLFVBQTZCLE9BQWU7WUFDeEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsR0FBQyxPQUFPLENBQUMsQ0FBQztRQUNqRCxDQUFDO1FBRUwsZ0JBQUM7SUFBRCxDQUFDLEFBNUJELElBNEJDO0lBNUJZLDhCQUFTIiwic291cmNlc0NvbnRlbnQiOlsiLyogKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgJEFDQ0VMRVJBVE9SX0hFQURFUl9QTEFDRV9IT0xERVIkXG4gKiAgU0hBMTogJElkOiA3YWVlNzVmYmE5Y2MwYzdlNGJkY2ZmMTBjYWQ1YzQwYTgxZDAzMjUzICRcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogIEZpbGU6ICRBQ0NFTEVSQVRPUl9IRUFERVJfRklMRV9OQU1FX1BMQUNFX0hPTERFUiRcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xuXG5pbXBvcnQge0xvZ0xldmVsc30gZnJvbSBcIi4vbG9nTGV2ZWxzXCI7XG5leHBvcnQgY2xhc3MgQ3RpTG9nZ2VyIHtcbiAgICBwdWJsaWMgc3RhdGljIGxvZ01lc3NhZ2UobG9nTGV2ZWw6IExvZ0xldmVscywgbWVzc2FnZTogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIGlmKGxvZ0xldmVsKSB7XG4gICAgICAgICAgICBzd2l0Y2ggKGxvZ0xldmVsKXtcbiAgICAgICAgICAgICAgICBjYXNlIExvZ0xldmVscy5FUlJPUjpcbiAgICAgICAgICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0Vycm9yTWVzc2FnZShtZXNzYWdlKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBMb2dMZXZlbHMuSU5GTzpcbiAgICAgICAgICAgICAgICAgICAgQ3RpTG9nZ2VyLmxvZ0luZm9NZXNzYWdlKG1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIExvZ0xldmVscy5XQVJOOlxuICAgICAgICAgICAgICAgICAgICBDdGlMb2dnZXIubG9nV2FybmluZ01lc3NhZ2UobWVzc2FnZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwdWJsaWMgc3RhdGljIGxvZ1dhcm5pbmdNZXNzYWdlKG1lc3NhZ2U6IHN0cmluZyk6IHZvaWQge1xuICAgICAgICBjb25zb2xlLndhcm4oJ0NUSUxvZ2dlciA+PiBXQVJOSU5HID4+ICcrbWVzc2FnZSk7XG4gICAgfVxuXG4gICAgcHVibGljIHN0YXRpYyBsb2dFcnJvck1lc3NhZ2UobWVzc2FnZTogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0NUSUxvZ2dlciA+PiBFUlJPUiA+PiAnK21lc3NhZ2UpO1xuICAgIH1cblxuICAgIHB1YmxpYyBzdGF0aWMgbG9nSW5mb01lc3NhZ2UobWVzc2FnZTogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdDVElMb2dnZXIgPj4gSU5GTyA+PiAnK21lc3NhZ2UpO1xuICAgIH1cblxufSJdfQ==