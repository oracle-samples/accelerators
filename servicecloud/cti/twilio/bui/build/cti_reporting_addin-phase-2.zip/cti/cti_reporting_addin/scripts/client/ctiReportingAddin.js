define(["require", "exports", "jquery", "./../model/reportRow", "../util/ctiMessages", "../util/ctiLogger", "../model/pagination"], function (require, exports, $, reportRow_1, ctiMessages_1, ctiLogger_1, pagination_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CtiReportingAddin = void 0;
    var CtiReportingAddin = (function () {
        function CtiReportingAddin() {
            this.completedCount = 0;
            this.workerData = {};
            this.logPreMessage = 'CtiReportingAddin ' + ctiMessages_1.CtiMessages.MESSAGE_APPENDER;
        }
        CtiReportingAddin.prototype.registerCtiReportingAdin = function () {
            var _this = this;
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_ADDIN_REGISTER);
            ORACLE_SERVICE_CLOUD.extension_loader.load('DataListenerApp').then(function (extensionProvider) {
                extensionProvider.registerAnalyticsExtension(function (analyticsContext) {
                    analyticsContext.addTableDataRequestListener('accelerator$CtiAgentStats', function (report) { return _this.reportDataSourceHandler(report); });
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_ADDIN_INITIALIZED);
                });
                extensionProvider.getGlobalContext().then(function (globalContext) {
                    _this.globalContext = globalContext;
                    _this.serverURI = globalContext.getInterfaceUrl().match(/^[^\/]+:\/\/[^\/]+\//)[0].replace(/^http(?!s)/i, 'https') +
                        'cc/CTI/twilioProxy';
                    globalContext.getSessionToken().then(function (sessionToken) {
                        _this.sessionId = sessionToken;
                    });
                });
            });
        };
        CtiReportingAddin.prototype.reportDataSourceHandler = function (report) {
            var _this = this;
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_START_REPORT_EXECUTION);
            return new ExtensionPromise(function (resolve, reject) {
                var startDate;
                var endDate;
                var pageNumber;
                var rowsPerPage;
                var filterList = report.getReportFilters().getFilterList();
                pageNumber = report.getReportFilters().getPageNumber();
                rowsPerPage = report.getReportFilters().getRowsPerPage();
                for (var i = 0; i < filterList.length; i++) {
                    var filter = filterList[i];
                    if (filter.getColumnReference() === 'accelerator$CtiAgentStats.fromDate') {
                        startDate = filter.getValue();
                    }
                    else if (filter.getColumnReference() === 'accelerator$CtiAgentStats.toDate') {
                        endDate = filter.getValue();
                    }
                }
                var reportData = report.createReportData();
                _this.getReportData(_this.sessionId, startDate, endDate).then(function (reportRows) {
                    var totalRecordsCount = reportRows.length;
                    reportData.setTotalRecordCount(totalRecordsCount);
                    if (!pageNumber) {
                        pageNumber = 0;
                    }
                    if (!rowsPerPage) {
                        rowsPerPage = 10;
                    }
                    var pagination = _this.getPaginationData(pageNumber, rowsPerPage, totalRecordsCount);
                    for (var i = pagination.lowerBound; i < pagination.upperBound; i++) {
                        var reportRow = reportRows[i];
                        var row = report.createReportDataRow();
                        var agentId = reportRow.agentName;
                        if (!isNaN(agentId)) {
                            var cellName = report.createReportDataCell();
                            cellName.setData(reportRow.agentName);
                            row.cells.push(cellName);
                            var cellAccceptedCalls = report.createReportDataCell();
                            cellAccceptedCalls.setData(reportRow.reservationAccepted);
                            row.cells.push(cellAccceptedCalls);
                            var cellCancelledCalls = report.createReportDataCell();
                            cellCancelledCalls.setData(reportRow.reservationCancelled);
                            row.cells.push(cellCancelledCalls);
                            var cellTimedOutCalls = report.createReportDataCell();
                            cellTimedOutCalls.setData(reportRow.reservationTimedOut);
                            row.cells.push(cellTimedOutCalls);
                            var cellRejectedCalls = report.createReportDataCell();
                            cellRejectedCalls.setData(reportRow.reservationRejected);
                            row.cells.push(cellRejectedCalls);
                            var cellReservationsCreated = report.createReportDataCell();
                            cellReservationsCreated.setData(reportRow.reservationCreated);
                            row.cells.push(cellReservationsCreated);
                            var cellReservedDuation = report.createReportDataCell();
                            cellReservedDuation.setData(reportRow.reservedDuration);
                            row.cells.push(cellReservedDuation);
                            var cellAvailableDuration = report.createReportDataCell();
                            cellAvailableDuration.setData(reportRow.readyDuration);
                            row.cells.push(cellAvailableDuration);
                            var cellBusyDuration = report.createReportDataCell();
                            cellBusyDuration.setData(reportRow.busyDuration);
                            row.cells.push(cellBusyDuration);
                            var cellNotAvailableDuration = report.createReportDataCell();
                            cellNotAvailableDuration.setData(reportRow.offlineDuration);
                            row.cells.push(cellNotAvailableDuration);
                            reportData.rows.push(row);
                        }
                    }
                    resolve(reportData);
                });
            });
        };
        CtiReportingAddin.prototype.getPaginationData = function (pageNumber, recordsPerPage, totalRecords) {
            var pagination = new pagination_1.Pagination;
            pagination.lowerBound = 0;
            pagination.upperBound = 0;
            pagination.totalRecords = totalRecords;
            pagination.recordsPerPage = recordsPerPage;
            if (recordsPerPage >= totalRecords || (pageNumber * recordsPerPage) >= totalRecords) {
                pagination.upperBound = totalRecords;
            }
            else {
                if (pageNumber) {
                    pagination.upperBound = pageNumber * recordsPerPage;
                    pagination.lowerBound = pagination.upperBound - recordsPerPage;
                    pagination.nextPage = pageNumber++;
                }
                else {
                    pagination.upperBound = recordsPerPage;
                }
            }
            return pagination;
        };
        CtiReportingAddin.prototype.getReportData = function (sessionId, startDate, endDate) {
            var _this = this;
            var promiseObj = new ExtensionPromise(function (resolve, reject) {
                _this.resolveRef = resolve;
                _this.rejectRef = reject;
            });
            var startDateTime;
            var endDateTime;
            if (startDate) {
                startDateTime = new Date(startDate);
            }
            else {
                startDateTime = new Date();
                startDateTime.setHours(startDateTime.getHours() - 8);
            }
            if (endDate) {
                endDateTime = new Date(endDate);
            }
            else {
                endDateTime = new Date();
            }
            this.fetchReportData(this.serverURI, this.sessionId, startDateTime.toISOString(), endDateTime.toISOString());
            return promiseObj;
        };
        CtiReportingAddin.prototype.fetchReportData = function (serverUri, sessionId, startDate, endDate) {
            var _this = this;
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_GET_AGENT_DATA);
            var apiGetWorkers = 'https://taskrouter.twilio.com/v1/Workspaces/{WORKSPACE_SID}/Workers';
            $.ajax({
                type: "POST",
                url: serverUri,
                data: {
                    session_id: sessionId,
                    uri: apiGetWorkers
                }
            })
                .done(function (workersResult) {
                var allWorkerData = JSON.parse(workersResult);
                if (allWorkerData && allWorkerData.workers && allWorkerData.workers.length > 0) {
                    _this.workerCount = allWorkerData.workers.length;
                    _this.fetchWorkerStatistics(allWorkerData.workers, serverUri, sessionId, startDate, endDate);
                }
                else {
                    ctiLogger_1.CtiLogger.logInfoMessage(_this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_NO_AGENTS_FOUND);
                }
            })
                .fail(function (message) {
                ctiLogger_1.CtiLogger.logErrorMessage(_this.logPreMessage +
                    ctiMessages_1.CtiMessages.MESSAGE_APPENDER + ctiMessages_1.CtiMessages.MESSAGE_REPORT_EXECUTION_FAILED + message);
            });
        };
        CtiReportingAddin.prototype.fetchWorkerStatistics = function (allWorkers, serverUri, sessionId, startDate, endDate) {
            var _this = this;
            var workerCount = allWorkers.length;
            for (var count = 0; count < workerCount; count++) {
                var worker = allWorkers[count];
                this.workerData[worker.sid] = { name: worker.friendly_name };
                var apiWorkerStat = 'https://taskrouter.twilio.com/v1/Workspaces/{WORKSPACE_SID}/Workers/' + worker.sid + '/Statistics?StartDate=' + startDate + '&EndDate=' + endDate;
                $.ajax({
                    type: "POST",
                    url: serverUri,
                    data: {
                        session_id: sessionId,
                        uri: apiWorkerStat
                    }
                })
                    .done(function (workerResult) {
                    var workDetail = JSON.parse(workerResult);
                    _this.addWorkDetails(workDetail);
                })
                    .fail(function (data) {
                    _this.addWorkDetails(null);
                });
            }
        };
        CtiReportingAddin.prototype.addWorkDetails = function (workDetail) {
            if (workDetail && workDetail.worker_sid) {
                this.workerData[workDetail.worker_sid]['work'] = workDetail;
            }
            this.completedCount++;
            if (this.completedCount >= this.workerCount) {
                ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_GET_AGENT_DATA_COMPLETED);
                this.processWorkerData();
            }
        };
        CtiReportingAddin.prototype.processWorkerData = function () {
            var report = [];
            var rowCount = 0;
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_PROCESSING_DATA);
            for (var key in this.workerData) {
                if (this.workerData.hasOwnProperty(key)) {
                    var workDetails = this.workerData[key];
                    var reportRow = new reportRow_1.ReportRow();
                    report[rowCount] = reportRow;
                    reportRow.agentName = workDetails.name.substring(workDetails.name.lastIndexOf('_') + 1, workDetails.name.length);
                    rowCount++;
                    if (workDetails.work && workDetails.work.cumulative) {
                        var statistics = workDetails.work.cumulative;
                        reportRow.reservationAccepted = statistics.reservations_accepted;
                        reportRow.reservationCancelled = statistics.reservations_canceled;
                        reportRow.reservationCreated = statistics.reservations_created;
                        reportRow.reservationRejected = statistics.reservations_rejected;
                        reportRow.reservationTimedOut = statistics.reservations_timed_out;
                        var activityDurations = statistics.activity_durations;
                        if (activityDurations && activityDurations.length > 0) {
                            for (var index in activityDurations) {
                                if (activityDurations.hasOwnProperty(index)) {
                                    var activityData = activityDurations[index];
                                    var duration = (activityData.total / 60).toFixed(2);
                                    switch (activityData.friendly_name) {
                                        case 'Not Available':
                                            reportRow.offlineDuration = duration;
                                            break;
                                        case 'Busy':
                                            reportRow.busyDuration = duration;
                                            break;
                                        case 'Reserved':
                                            reportRow.reservedDuration = duration;
                                            break;
                                        case 'Ready':
                                            reportRow.readyDuration = duration;
                                            break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            this.resolveRef(report);
            this.workerCount = null;
            this.completedCount = 0;
            this.workerData = {};
            ctiLogger_1.CtiLogger.logInfoMessage(this.logPreMessage + ctiMessages_1.CtiMessages.MESSAGE_PROCESSING_DATA_COMPLETED);
        };
        return CtiReportingAddin;
    }());
    exports.CtiReportingAddin = CtiReportingAddin;
    new CtiReportingAddin().registerCtiReportingAdin();
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3RpUmVwb3J0aW5nQWRkaW4uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjdGlSZXBvcnRpbmdBZGRpbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0lBY0E7UUFBQTtZQUdZLG1CQUFjLEdBQVcsQ0FBQyxDQUFDO1lBQzNCLGVBQVUsR0FBeUIsRUFBRSxDQUFDO1lBS3RDLGtCQUFhLEdBQVcsb0JBQW9CLEdBQUcseUJBQVcsQ0FBQyxnQkFBZ0IsQ0FBQztRQWtTeEYsQ0FBQztRQWhTVSxvREFBd0IsR0FBL0I7WUFBQSxpQkEwQkM7WUF6QkcscUJBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGFBQWEsR0FBRyx5QkFBVyxDQUFDLHNCQUFzQixDQUFDLENBQUM7WUFDbEYsb0JBQW9CLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUM5RCxVQUFDLGlCQUEyRDtnQkFDeEQsaUJBQWlCLENBQUMsMEJBQTBCLENBQ3hDLFVBQUMsZ0JBQXFCO29CQUNsQixnQkFBZ0IsQ0FBQywyQkFBMkIsQ0FDeEMsMkJBQTJCLEVBQUUsVUFBQyxNQUE2QyxJQUFLLE9BQUEsS0FBSSxDQUFDLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxFQUFwQyxDQUFvQyxDQUN2SCxDQUFDO29CQUNGLHFCQUFTLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxhQUFhLEdBQUcseUJBQVcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO2dCQUN6RixDQUFDLENBQ0osQ0FBQztnQkFDRixpQkFBaUIsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksQ0FDckMsVUFBQyxhQUEyRDtvQkFDeEQsS0FBSSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7b0JBQ25DLEtBQUksQ0FBQyxTQUFTLEdBQUcsYUFBYSxDQUFDLGVBQWUsRUFBRSxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDO3dCQUN6RyxvQkFBb0IsQ0FBQztvQkFDN0IsYUFBYSxDQUFDLGVBQWUsRUFBRSxDQUFDLElBQUksQ0FDaEMsVUFBQyxZQUFvQjt3QkFDakIsS0FBSSxDQUFDLFNBQVMsR0FBRyxZQUFZLENBQUM7b0JBQ2xDLENBQUMsQ0FDSixDQUFDO2dCQUNOLENBQUMsQ0FDSixDQUFBO1lBQ0wsQ0FBQyxDQUNKLENBQUM7UUFDTixDQUFDO1FBRU0sbURBQXVCLEdBQTlCLFVBQStCLE1BQTZDO1lBQTVFLGlCQXdGQztZQXZGRyxxQkFBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsYUFBYSxHQUFHLHlCQUFXLENBQUMsOEJBQThCLENBQUMsQ0FBQztZQUMxRixPQUFPLElBQUksZ0JBQWdCLENBQUUsVUFBQyxPQUFZLEVBQUUsTUFBVztnQkFDbkQsSUFBSSxTQUFjLENBQUM7Z0JBQ25CLElBQUksT0FBWSxDQUFDO2dCQUNqQixJQUFJLFVBQWtCLENBQUM7Z0JBQ3ZCLElBQUksV0FBbUIsQ0FBQztnQkFFeEIsSUFBSSxVQUFVLEdBQTRDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUNwRyxVQUFVLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixFQUFFLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3ZELFdBQVcsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQkFFekQsS0FBSSxJQUFJLENBQUMsR0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUM7b0JBQ2xDLElBQUksTUFBTSxHQUEwQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2xFLElBQUcsTUFBTSxDQUFDLGtCQUFrQixFQUFFLEtBQUssb0NBQW9DLEVBQUM7d0JBQ3BFLFNBQVMsR0FBRyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ2pDO3lCQUFLLElBQUcsTUFBTSxDQUFDLGtCQUFrQixFQUFFLEtBQUssa0NBQWtDLEVBQUM7d0JBQ3hFLE9BQU8sR0FBRyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQy9CO2lCQUNKO2dCQUNELElBQUksVUFBVSxHQUFHLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUUzQyxLQUFJLENBQUMsYUFBYSxDQUFDLEtBQUksQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FDdkQsVUFBQyxVQUF1QjtvQkFDcEIsSUFBSSxpQkFBaUIsR0FBVyxVQUFVLENBQUMsTUFBTSxDQUFDO29CQUNsRCxVQUFVLENBQUMsbUJBQW1CLENBQUMsaUJBQWlCLENBQUMsQ0FBQztvQkFDbEQsSUFBRyxDQUFDLFVBQVUsRUFBQzt3QkFDWCxVQUFVLEdBQUcsQ0FBQyxDQUFDO3FCQUNsQjtvQkFDRCxJQUFHLENBQUMsV0FBVyxFQUFDO3dCQUNaLFdBQVcsR0FBRyxFQUFFLENBQUM7cUJBQ3BCO29CQUNELElBQUksVUFBVSxHQUFlLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFFLGlCQUFpQixDQUFDLENBQUM7b0JBRWhHLEtBQUksSUFBSSxDQUFDLEdBQUcsVUFBVSxDQUFDLFVBQVUsRUFBRSxDQUFDLEdBQUUsVUFBVSxDQUFDLFVBQVUsRUFBRSxDQUFDLEVBQUUsRUFBQzt3QkFDN0QsSUFBSSxTQUFTLEdBQWMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN6QyxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsbUJBQW1CLEVBQUUsQ0FBQzt3QkFFdkMsSUFBSSxPQUFPLEdBQVEsU0FBUyxDQUFDLFNBQVMsQ0FBQzt3QkFDdkMsSUFBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBQzs0QkFDZixJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsb0JBQW9CLEVBQUUsQ0FBQzs0QkFDN0MsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7NEJBQ3RDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUV6QixJQUFJLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRSxDQUFDOzRCQUN2RCxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLENBQUM7NEJBQzFELEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7NEJBRW5DLElBQUksa0JBQWtCLEdBQUcsTUFBTSxDQUFDLG9CQUFvQixFQUFFLENBQUM7NEJBQ3ZELGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsb0JBQW9CLENBQUMsQ0FBQzs0QkFDM0QsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQzs0QkFFbkMsSUFBSSxpQkFBaUIsR0FBRyxNQUFNLENBQUMsb0JBQW9CLEVBQUUsQ0FBQzs0QkFDdEQsaUJBQWlCLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDOzRCQUN6RCxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDOzRCQUVsQyxJQUFJLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRSxDQUFDOzRCQUN0RCxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLENBQUM7NEJBQ3pELEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7NEJBRWxDLElBQUksdUJBQXVCLEdBQUcsTUFBTSxDQUFDLG9CQUFvQixFQUFFLENBQUM7NEJBQzVELHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQUMsQ0FBQzs0QkFDOUQsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQzs0QkFHeEMsSUFBSSxtQkFBbUIsR0FBRyxNQUFNLENBQUMsb0JBQW9CLEVBQUUsQ0FBQzs0QkFDeEQsbUJBQW1CLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDOzRCQUN4RCxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDOzRCQUVwQyxJQUFJLHFCQUFxQixHQUFHLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRSxDQUFDOzRCQUMxRCxxQkFBcUIsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxDQUFDOzRCQUN2RCxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDOzRCQUV0QyxJQUFJLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRSxDQUFDOzRCQUNyRCxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDOzRCQUNqRCxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDOzRCQUVqQyxJQUFJLHdCQUF3QixHQUFHLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRSxDQUFDOzRCQUM3RCx3QkFBd0IsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxDQUFDOzRCQUM1RCxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDOzRCQUV6QyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzt5QkFDN0I7cUJBQ0o7b0JBQ0QsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUN4QixDQUFDLENBQ0osQ0FBQztZQUNOLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQztRQUVPLDZDQUFpQixHQUF6QixVQUEwQixVQUFrQixFQUFFLGNBQXNCLEVBQUUsWUFBb0I7WUFDdEYsSUFBSSxVQUFVLEdBQWUsSUFBSSx1QkFBVSxDQUFDO1lBQzVDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO1lBQzFCLFVBQVUsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO1lBQzFCLFVBQVUsQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO1lBQ3ZDLFVBQVUsQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFDO1lBRTNDLElBQUcsY0FBYyxJQUFJLFlBQVksSUFBSSxDQUFDLFVBQVUsR0FBRyxjQUFjLENBQUMsSUFBSSxZQUFZLEVBQUM7Z0JBQy9FLFVBQVUsQ0FBQyxVQUFVLEdBQUcsWUFBWSxDQUFDO2FBQ3hDO2lCQUFJO2dCQUNELElBQUcsVUFBVSxFQUFFO29CQUNYLFVBQVUsQ0FBQyxVQUFVLEdBQUcsVUFBVSxHQUFHLGNBQWMsQ0FBQztvQkFDcEQsVUFBVSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUMsVUFBVSxHQUFHLGNBQWMsQ0FBQztvQkFDL0QsVUFBVSxDQUFDLFFBQVEsR0FBRyxVQUFVLEVBQUUsQ0FBQztpQkFDdEM7cUJBQUk7b0JBQ0QsVUFBVSxDQUFDLFVBQVUsR0FBRyxjQUFjLENBQUM7aUJBQzFDO2FBQ0o7WUFFRCxPQUFPLFVBQVUsQ0FBQztRQUN0QixDQUFDO1FBRU0seUNBQWEsR0FBcEIsVUFBcUIsU0FBaUIsRUFBRSxTQUFjLEVBQUUsT0FBWTtZQUFwRSxpQkF3QkM7WUF2QkcsSUFBSSxVQUFVLEdBQUksSUFBSSxnQkFBZ0IsQ0FBQyxVQUFDLE9BQU8sRUFBQyxNQUFNO2dCQUNwRCxLQUFJLENBQUMsVUFBVSxHQUFHLE9BQU8sQ0FBQztnQkFDMUIsS0FBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLGFBQW1CLENBQUM7WUFDeEIsSUFBSSxXQUFpQixDQUFDO1lBRXRCLElBQUcsU0FBUyxFQUFDO2dCQUNULGFBQWEsR0FBRyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUN2QztpQkFBSTtnQkFDRCxhQUFhLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDM0IsYUFBYSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7YUFDeEQ7WUFFRCxJQUFHLE9BQU8sRUFBQztnQkFDUCxXQUFXLEdBQUcsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDbkM7aUJBQUk7Z0JBQ0QsV0FBVyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7YUFDNUI7WUFFRCxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxhQUFhLENBQUMsV0FBVyxFQUFFLEVBQUUsV0FBVyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7WUFDN0csT0FBTyxVQUFVLENBQUM7UUFDdEIsQ0FBQztRQUVPLDJDQUFlLEdBQXZCLFVBQXdCLFNBQWlCLEVBQUUsU0FBaUIsRUFBRSxTQUFpQixFQUFFLE9BQWU7WUFBaEcsaUJBd0JDO1lBdkJHLHFCQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxhQUFhLEdBQUcseUJBQVcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1lBQ2xGLElBQUksYUFBYSxHQUFXLHFFQUFxRSxDQUFDO1lBQ2xHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ0MsSUFBSSxFQUFFLE1BQU07Z0JBQ1osR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsSUFBSSxFQUFFO29CQUNGLFVBQVUsRUFBRSxTQUFTO29CQUNyQixHQUFHLEVBQUUsYUFBYTtpQkFDckI7YUFDSixDQUFDO2lCQUNELElBQUksQ0FBQyxVQUFDLGFBQXFCO2dCQUN4QixJQUFJLGFBQWEsR0FBUSxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUNuRCxJQUFHLGFBQWEsSUFBSSxhQUFhLENBQUMsT0FBTyxJQUFJLGFBQWEsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBQztvQkFDMUUsS0FBSSxDQUFDLFdBQVcsR0FBRyxhQUFhLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztvQkFDaEQsS0FBSSxDQUFDLHFCQUFxQixDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUE7aUJBQzlGO3FCQUFJO29CQUNELHFCQUFTLENBQUMsY0FBYyxDQUFDLEtBQUksQ0FBQyxhQUFhLEdBQUcseUJBQVcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO2lCQUN0RjtZQUNMLENBQUMsQ0FBQztpQkFDRCxJQUFJLENBQUMsVUFBQyxPQUFZO2dCQUNmLHFCQUFTLENBQUMsZUFBZSxDQUFDLEtBQUksQ0FBQyxhQUFhO29CQUN4Qyx5QkFBVyxDQUFDLGdCQUFnQixHQUFHLHlCQUFXLENBQUMsK0JBQStCLEdBQUcsT0FBTyxDQUFDLENBQUM7WUFDOUYsQ0FBQyxDQUFDLENBQUM7UUFDWCxDQUFDO1FBRU8saURBQXFCLEdBQTdCLFVBQThCLFVBQWlCLEVBQUUsU0FBaUIsRUFBRSxTQUFpQixFQUN2RCxTQUFpQixFQUFFLE9BQWU7WUFEaEUsaUJBMkJDO1lBeEJHLElBQUksV0FBVyxHQUFXLFVBQVUsQ0FBQyxNQUFNLENBQUM7WUFFNUMsS0FBSSxJQUFJLEtBQUssR0FBRSxDQUFDLEVBQUUsS0FBSyxHQUFDLFdBQVcsRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDMUMsSUFBSSxNQUFNLEdBQVEsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNwQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFDLElBQUksRUFBRSxNQUFNLENBQUMsYUFBYSxFQUFDLENBQUM7Z0JBRTNELElBQUksYUFBYSxHQUFXLHNFQUFzRSxHQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUMsd0JBQXdCLEdBQUMsU0FBUyxHQUFDLFdBQVcsR0FBQyxPQUFPLENBQUM7Z0JBQ3JLLENBQUMsQ0FBQyxJQUFJLENBQUM7b0JBQ0MsSUFBSSxFQUFFLE1BQU07b0JBQ1osR0FBRyxFQUFFLFNBQVM7b0JBQ2QsSUFBSSxFQUFFO3dCQUNGLFVBQVUsRUFBRSxTQUFTO3dCQUNyQixHQUFHLEVBQUUsYUFBYTtxQkFDckI7aUJBQ0osQ0FBQztxQkFDRCxJQUFJLENBQUMsVUFBQyxZQUFvQjtvQkFDdkIsSUFBSSxVQUFVLEdBQVEsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDL0MsS0FBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDcEMsQ0FBQyxDQUFDO3FCQUNELElBQUksQ0FBQyxVQUFDLElBQVM7b0JBQ1osS0FBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDOUIsQ0FBQyxDQUFDLENBQUM7YUFDVjtRQUVMLENBQUM7UUFFTywwQ0FBYyxHQUF0QixVQUF1QixVQUFlO1lBQ2xDLElBQUcsVUFBVSxJQUFJLFVBQVUsQ0FBQyxVQUFVLEVBQUM7Z0JBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLFVBQVUsQ0FBQzthQUMvRDtZQUNELElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN0QixJQUFHLElBQUksQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBQztnQkFDdkMscUJBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGFBQWEsR0FBRyx5QkFBVyxDQUFDLGdDQUFnQyxDQUFDLENBQUM7Z0JBQzVGLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO2FBQzVCO1FBQ0wsQ0FBQztRQUVPLDZDQUFpQixHQUF6QjtZQUNJLElBQUksTUFBTSxHQUFnQixFQUFFLENBQUM7WUFDN0IsSUFBSSxRQUFRLEdBQVcsQ0FBQyxDQUFDO1lBQ3pCLHFCQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxhQUFhLEdBQUcseUJBQVcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1lBRW5GLEtBQUksSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBQztnQkFDM0IsSUFBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBQztvQkFDbkMsSUFBSSxXQUFXLEdBQVEsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDNUMsSUFBSSxTQUFTLEdBQWMsSUFBSSxxQkFBUyxFQUFFLENBQUM7b0JBQzNDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxTQUFTLENBQUM7b0JBQzdCLFNBQVMsQ0FBQyxTQUFTLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEdBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQy9HLFFBQVEsRUFBRSxDQUFDO29CQUNYLElBQUcsV0FBVyxDQUFDLElBQUksSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBQzt3QkFDL0MsSUFBSSxVQUFVLEdBQVEsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7d0JBQ2xELFNBQVMsQ0FBQyxtQkFBbUIsR0FBRyxVQUFVLENBQUMscUJBQXFCLENBQUM7d0JBQ2pFLFNBQVMsQ0FBQyxvQkFBb0IsR0FBRyxVQUFVLENBQUMscUJBQXFCLENBQUM7d0JBQ2xFLFNBQVMsQ0FBQyxrQkFBa0IsR0FBRyxVQUFVLENBQUMsb0JBQW9CLENBQUM7d0JBQy9ELFNBQVMsQ0FBQyxtQkFBbUIsR0FBRyxVQUFVLENBQUMscUJBQXFCLENBQUM7d0JBQ2pFLFNBQVMsQ0FBQyxtQkFBbUIsR0FBRyxVQUFVLENBQUMsc0JBQXNCLENBQUM7d0JBRWxFLElBQUksaUJBQWlCLEdBQVUsVUFBVSxDQUFDLGtCQUFrQixDQUFDO3dCQUM3RCxJQUFHLGlCQUFpQixJQUFJLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUM7NEJBQ2pELEtBQUksSUFBSSxLQUFLLElBQUksaUJBQWlCLEVBQUM7Z0NBQy9CLElBQUcsaUJBQWlCLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFDO29DQUN2QyxJQUFJLFlBQVksR0FBUSxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQ0FDakQsSUFBSSxRQUFRLEdBQVcsQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDMUQsUUFBTyxZQUFZLENBQUMsYUFBYSxFQUFDO3dDQUM5QixLQUFLLGVBQWU7NENBQ2hCLFNBQVMsQ0FBQyxlQUFlLEdBQUcsUUFBUSxDQUFDOzRDQUNyQyxNQUFNO3dDQUNWLEtBQUssTUFBTTs0Q0FDUCxTQUFTLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQzs0Q0FDbEMsTUFBTTt3Q0FDVixLQUFLLFVBQVU7NENBQ1gsU0FBUyxDQUFDLGdCQUFnQixHQUFHLFFBQVEsQ0FBQzs0Q0FDdEMsTUFBTTt3Q0FDVixLQUFLLE9BQU87NENBQ1IsU0FBUyxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUM7NENBQ25DLE1BQU07cUNBQ2I7aUNBQ0o7NkJBRUo7eUJBQ0o7cUJBQ0o7aUJBQ0o7YUFDSjtZQUVELElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDeEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7WUFDeEIsSUFBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUM7WUFDeEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7WUFDckIscUJBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGFBQWEsR0FBRyx5QkFBVyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7UUFFakcsQ0FBQztRQUVMLHdCQUFDO0lBQUQsQ0FBQyxBQTNTRCxJQTJTQztJQTNTWSw4Q0FBaUI7SUE0UzlCLElBQUksaUJBQWlCLEVBQUUsQ0FBQyx3QkFBd0IsRUFBRSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyogKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgJEFDQ0VMRVJBVE9SX0hFQURFUl9QTEFDRV9IT0xERVIkXG4gKiAgU0hBMTogJElkOiA5N2EzZmI5MDYzNDZmOTI4ODAyZGY5YWMxZmIwZjMyZDBiNTEyYmU4ICRcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogIEZpbGU6ICRBQ0NFTEVSQVRPUl9IRUFERVJfRklMRV9OQU1FX1BMQUNFX0hPTERFUiRcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xuXG4vLy88cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uL2RlZmluaXRpb25zL29zdmNFeHRlbnNpb24uZC50cycgLz5cblxuaW1wb3J0ICQgPSByZXF1aXJlKCdqcXVlcnknKTtcbmltcG9ydCB7UmVwb3J0Um93fSBmcm9tIFwiLi8uLi9tb2RlbC9yZXBvcnRSb3dcIjtcbmltcG9ydCB7Q3RpTWVzc2FnZXN9IGZyb20gXCIuLi91dGlsL2N0aU1lc3NhZ2VzXCI7XG5pbXBvcnQge0N0aUxvZ2dlcn0gZnJvbSBcIi4uL3V0aWwvY3RpTG9nZ2VyXCI7XG5pbXBvcnQge1BhZ2luYXRpb259IGZyb20gXCIuLi9tb2RlbC9wYWdpbmF0aW9uXCI7XG5leHBvcnQgY2xhc3MgQ3RpUmVwb3J0aW5nQWRkaW4ge1xuXG4gICAgcHJpdmF0ZSB3b3JrZXJDb3VudDogbnVtYmVyO1xuICAgIHByaXZhdGUgY29tcGxldGVkQ291bnQ6IG51bWJlciA9IDA7XG4gICAgcHJpdmF0ZSB3b3JrZXJEYXRhOiB7W2tleTogc3RyaW5nXTogYW55fSA9IHt9O1xuICAgIHByaXZhdGUgc2VydmVyVVJJOiBzdHJpbmc7XG4gICAgcHJpdmF0ZSByZXNvbHZlUmVmOiBhbnk7IHByaXZhdGUgcmVqZWN0UmVmOmFueTtcbiAgICBwcml2YXRlIHNlc3Npb25JZDogc3RyaW5nO1xuICAgIHByaXZhdGUgZ2xvYmFsQ29udGV4dDogT1JBQ0xFX1NFUlZJQ0VfQ0xPVUQuSUV4dGVuc2lvbkdsb2JhbENvbnRleHQ7XG4gICAgcHJpdmF0ZSBsb2dQcmVNZXNzYWdlOiBzdHJpbmcgPSAnQ3RpUmVwb3J0aW5nQWRkaW4gJyArIEN0aU1lc3NhZ2VzLk1FU1NBR0VfQVBQRU5ERVI7XG5cbiAgICBwdWJsaWMgcmVnaXN0ZXJDdGlSZXBvcnRpbmdBZGluKCk6IHZvaWR7XG4gICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgKyBDdGlNZXNzYWdlcy5NRVNTQUdFX0FERElOX1JFR0lTVEVSKTtcbiAgICAgICAgT1JBQ0xFX1NFUlZJQ0VfQ0xPVUQuZXh0ZW5zaW9uX2xvYWRlci5sb2FkKCdEYXRhTGlzdGVuZXJBcHAnKS50aGVuKFxuICAgICAgICAgICAgKGV4dGVuc2lvblByb3ZpZGVyIDogT1JBQ0xFX1NFUlZJQ0VfQ0xPVUQuSUV4dGVuc2lvblByb3ZpZGVyKSA9PntcbiAgICAgICAgICAgICAgICBleHRlbnNpb25Qcm92aWRlci5yZWdpc3RlckFuYWx5dGljc0V4dGVuc2lvbihcbiAgICAgICAgICAgICAgICAgICAgKGFuYWx5dGljc0NvbnRleHQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzQ29udGV4dC5hZGRUYWJsZURhdGFSZXF1ZXN0TGlzdGVuZXIoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2FjY2VsZXJhdG9yJEN0aUFnZW50U3RhdHMnLCAocmVwb3J0OiBPUkFDTEVfU0VSVklDRV9DTE9VRC5JRXh0ZW5zaW9uUmVwb3J0KSA9PiB0aGlzLnJlcG9ydERhdGFTb3VyY2VIYW5kbGVyKHJlcG9ydClcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICBDdGlMb2dnZXIubG9nSW5mb01lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICsgQ3RpTWVzc2FnZXMuTUVTU0FHRV9BRERJTl9JTklUSUFMSVpFRCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIGV4dGVuc2lvblByb3ZpZGVyLmdldEdsb2JhbENvbnRleHQoKS50aGVuKFxuICAgICAgICAgICAgICAgICAgICAoZ2xvYmFsQ29udGV4dDogT1JBQ0xFX1NFUlZJQ0VfQ0xPVUQuSUV4dGVuc2lvbkdsb2JhbENvbnRleHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2xvYmFsQ29udGV4dCA9IGdsb2JhbENvbnRleHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNlcnZlclVSSSA9IGdsb2JhbENvbnRleHQuZ2V0SW50ZXJmYWNlVXJsKCkubWF0Y2goL15bXlxcL10rOlxcL1xcL1teXFwvXStcXC8vKVswXS5yZXBsYWNlKC9eaHR0cCg/IXMpL2ksICdodHRwcycpICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2NjL0NUSS90d2lsaW9Qcm94eSc7XG4gICAgICAgICAgICAgICAgICAgICAgICBnbG9iYWxDb250ZXh0LmdldFNlc3Npb25Ub2tlbigpLnRoZW4oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKHNlc3Npb25Ub2tlbjogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2Vzc2lvbklkID0gc2Vzc2lvblRva2VuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgcHVibGljIHJlcG9ydERhdGFTb3VyY2VIYW5kbGVyKHJlcG9ydDogT1JBQ0xFX1NFUlZJQ0VfQ0xPVUQuSUV4dGVuc2lvblJlcG9ydCk6IGFueXtcbiAgICAgICAgQ3RpTG9nZ2VyLmxvZ0luZm9NZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArIEN0aU1lc3NhZ2VzLk1FU1NBR0VfU1RBUlRfUkVQT1JUX0VYRUNVVElPTik7XG4gICAgICAgIHJldHVybiBuZXcgRXh0ZW5zaW9uUHJvbWlzZSggKHJlc29sdmU6IGFueSwgcmVqZWN0OiBhbnkpID0+IHtcbiAgICAgICAgICAgIHZhciBzdGFydERhdGU6IGFueTtcbiAgICAgICAgICAgIHZhciBlbmREYXRlOiBhbnk7XG4gICAgICAgICAgICB2YXIgcGFnZU51bWJlcjogbnVtYmVyO1xuICAgICAgICAgICAgdmFyIHJvd3NQZXJQYWdlOiBudW1iZXI7XG5cbiAgICAgICAgICAgIGxldCBmaWx0ZXJMaXN0OiBPUkFDTEVfU0VSVklDRV9DTE9VRC5JRXh0ZW5zaW9uRmlsdGVyW10gPSByZXBvcnQuZ2V0UmVwb3J0RmlsdGVycygpLmdldEZpbHRlckxpc3QoKTtcbiAgICAgICAgICAgIHBhZ2VOdW1iZXIgPSByZXBvcnQuZ2V0UmVwb3J0RmlsdGVycygpLmdldFBhZ2VOdW1iZXIoKTtcbiAgICAgICAgICAgIHJvd3NQZXJQYWdlID0gcmVwb3J0LmdldFJlcG9ydEZpbHRlcnMoKS5nZXRSb3dzUGVyUGFnZSgpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBmb3IobGV0IGk9MDsgaTxmaWx0ZXJMaXN0Lmxlbmd0aDsgaSsrKXtcbiAgICAgICAgICAgICAgICBsZXQgZmlsdGVyOiBPUkFDTEVfU0VSVklDRV9DTE9VRC5JRXh0ZW5zaW9uRmlsdGVyID0gZmlsdGVyTGlzdFtpXTtcbiAgICAgICAgICAgICAgICBpZihmaWx0ZXIuZ2V0Q29sdW1uUmVmZXJlbmNlKCkgPT09ICdhY2NlbGVyYXRvciRDdGlBZ2VudFN0YXRzLmZyb21EYXRlJyl7XG4gICAgICAgICAgICAgICAgICAgIHN0YXJ0RGF0ZSA9IGZpbHRlci5nZXRWYWx1ZSgpO1xuICAgICAgICAgICAgICAgIH1lbHNlIGlmKGZpbHRlci5nZXRDb2x1bW5SZWZlcmVuY2UoKSA9PT0gJ2FjY2VsZXJhdG9yJEN0aUFnZW50U3RhdHMudG9EYXRlJyl7XG4gICAgICAgICAgICAgICAgICAgIGVuZERhdGUgPSBmaWx0ZXIuZ2V0VmFsdWUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgcmVwb3J0RGF0YSA9IHJlcG9ydC5jcmVhdGVSZXBvcnREYXRhKCk7XG5cbiAgICAgICAgICAgIHRoaXMuZ2V0UmVwb3J0RGF0YSh0aGlzLnNlc3Npb25JZCwgc3RhcnREYXRlLCBlbmREYXRlKS50aGVuKFxuICAgICAgICAgICAgICAgIChyZXBvcnRSb3dzOiBSZXBvcnRSb3dbXSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB2YXIgdG90YWxSZWNvcmRzQ291bnQ6IG51bWJlciA9IHJlcG9ydFJvd3MubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICByZXBvcnREYXRhLnNldFRvdGFsUmVjb3JkQ291bnQodG90YWxSZWNvcmRzQ291bnQpO1xuICAgICAgICAgICAgICAgICAgICBpZighcGFnZU51bWJlcil7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYWdlTnVtYmVyID0gMDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZighcm93c1BlclBhZ2Upe1xuICAgICAgICAgICAgICAgICAgICAgICAgcm93c1BlclBhZ2UgPSAxMDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB2YXIgcGFnaW5hdGlvbjogUGFnaW5hdGlvbiA9IHRoaXMuZ2V0UGFnaW5hdGlvbkRhdGEocGFnZU51bWJlciwgcm93c1BlclBhZ2UsIHRvdGFsUmVjb3Jkc0NvdW50KTtcblxuICAgICAgICAgICAgICAgICAgICBmb3IodmFyIGkgPSBwYWdpbmF0aW9uLmxvd2VyQm91bmQ7IGk8IHBhZ2luYXRpb24udXBwZXJCb3VuZDsgaSsrKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXBvcnRSb3c6IFJlcG9ydFJvdyA9IHJlcG9ydFJvd3NbaV07XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcm93ID0gcmVwb3J0LmNyZWF0ZVJlcG9ydERhdGFSb3coKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGFnZW50SWQ6IGFueSA9IHJlcG9ydFJvdy5hZ2VudE5hbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZighaXNOYU4oYWdlbnRJZCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjZWxsTmFtZSA9IHJlcG9ydC5jcmVhdGVSZXBvcnREYXRhQ2VsbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNlbGxOYW1lLnNldERhdGEocmVwb3J0Um93LmFnZW50TmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93LmNlbGxzLnB1c2goY2VsbE5hbWUpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNlbGxBY2NjZXB0ZWRDYWxscyA9IHJlcG9ydC5jcmVhdGVSZXBvcnREYXRhQ2VsbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNlbGxBY2NjZXB0ZWRDYWxscy5zZXREYXRhKHJlcG9ydFJvdy5yZXNlcnZhdGlvbkFjY2VwdGVkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3cuY2VsbHMucHVzaChjZWxsQWNjY2VwdGVkQ2FsbHMpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNlbGxDYW5jZWxsZWRDYWxscyA9IHJlcG9ydC5jcmVhdGVSZXBvcnREYXRhQ2VsbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNlbGxDYW5jZWxsZWRDYWxscy5zZXREYXRhKHJlcG9ydFJvdy5yZXNlcnZhdGlvbkNhbmNlbGxlZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93LmNlbGxzLnB1c2goY2VsbENhbmNlbGxlZENhbGxzKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjZWxsVGltZWRPdXRDYWxscyA9IHJlcG9ydC5jcmVhdGVSZXBvcnREYXRhQ2VsbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNlbGxUaW1lZE91dENhbGxzLnNldERhdGEocmVwb3J0Um93LnJlc2VydmF0aW9uVGltZWRPdXQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdy5jZWxscy5wdXNoKGNlbGxUaW1lZE91dENhbGxzKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjZWxsUmVqZWN0ZWRDYWxscyA9IHJlcG9ydC5jcmVhdGVSZXBvcnREYXRhQ2VsbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNlbGxSZWplY3RlZENhbGxzLnNldERhdGEocmVwb3J0Um93LnJlc2VydmF0aW9uUmVqZWN0ZWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdy5jZWxscy5wdXNoKGNlbGxSZWplY3RlZENhbGxzKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjZWxsUmVzZXJ2YXRpb25zQ3JlYXRlZCA9IHJlcG9ydC5jcmVhdGVSZXBvcnREYXRhQ2VsbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNlbGxSZXNlcnZhdGlvbnNDcmVhdGVkLnNldERhdGEocmVwb3J0Um93LnJlc2VydmF0aW9uQ3JlYXRlZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93LmNlbGxzLnB1c2goY2VsbFJlc2VydmF0aW9uc0NyZWF0ZWQpO1xuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgY2VsbFJlc2VydmVkRHVhdGlvbiA9IHJlcG9ydC5jcmVhdGVSZXBvcnREYXRhQ2VsbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNlbGxSZXNlcnZlZER1YXRpb24uc2V0RGF0YShyZXBvcnRSb3cucmVzZXJ2ZWREdXJhdGlvbik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93LmNlbGxzLnB1c2goY2VsbFJlc2VydmVkRHVhdGlvbik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgY2VsbEF2YWlsYWJsZUR1cmF0aW9uID0gcmVwb3J0LmNyZWF0ZVJlcG9ydERhdGFDZWxsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2VsbEF2YWlsYWJsZUR1cmF0aW9uLnNldERhdGEocmVwb3J0Um93LnJlYWR5RHVyYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdy5jZWxscy5wdXNoKGNlbGxBdmFpbGFibGVEdXJhdGlvbik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgY2VsbEJ1c3lEdXJhdGlvbiA9IHJlcG9ydC5jcmVhdGVSZXBvcnREYXRhQ2VsbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNlbGxCdXN5RHVyYXRpb24uc2V0RGF0YShyZXBvcnRSb3cuYnVzeUR1cmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3cuY2VsbHMucHVzaChjZWxsQnVzeUR1cmF0aW9uKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjZWxsTm90QXZhaWxhYmxlRHVyYXRpb24gPSByZXBvcnQuY3JlYXRlUmVwb3J0RGF0YUNlbGwoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjZWxsTm90QXZhaWxhYmxlRHVyYXRpb24uc2V0RGF0YShyZXBvcnRSb3cub2ZmbGluZUR1cmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3cuY2VsbHMucHVzaChjZWxsTm90QXZhaWxhYmxlRHVyYXRpb24pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVwb3J0RGF0YS5yb3dzLnB1c2gocm93KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHJlcG9ydERhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBcbiAgICBwcml2YXRlIGdldFBhZ2luYXRpb25EYXRhKHBhZ2VOdW1iZXI6IG51bWJlciwgcmVjb3Jkc1BlclBhZ2U6IG51bWJlciwgdG90YWxSZWNvcmRzOiBudW1iZXIpOiBQYWdpbmF0aW9uIHtcbiAgICAgICAgdmFyIHBhZ2luYXRpb246IFBhZ2luYXRpb24gPSBuZXcgUGFnaW5hdGlvbjtcbiAgICAgICAgcGFnaW5hdGlvbi5sb3dlckJvdW5kID0gMDtcbiAgICAgICAgcGFnaW5hdGlvbi51cHBlckJvdW5kID0gMDtcbiAgICAgICAgcGFnaW5hdGlvbi50b3RhbFJlY29yZHMgPSB0b3RhbFJlY29yZHM7XG4gICAgICAgIHBhZ2luYXRpb24ucmVjb3Jkc1BlclBhZ2UgPSByZWNvcmRzUGVyUGFnZTtcblxuICAgICAgICBpZihyZWNvcmRzUGVyUGFnZSA+PSB0b3RhbFJlY29yZHMgfHwgKHBhZ2VOdW1iZXIgKiByZWNvcmRzUGVyUGFnZSkgPj0gdG90YWxSZWNvcmRzKXtcbiAgICAgICAgICAgIHBhZ2luYXRpb24udXBwZXJCb3VuZCA9IHRvdGFsUmVjb3JkcztcbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICBpZihwYWdlTnVtYmVyKSB7XG4gICAgICAgICAgICAgICAgcGFnaW5hdGlvbi51cHBlckJvdW5kID0gcGFnZU51bWJlciAqIHJlY29yZHNQZXJQYWdlO1xuICAgICAgICAgICAgICAgIHBhZ2luYXRpb24ubG93ZXJCb3VuZCA9IHBhZ2luYXRpb24udXBwZXJCb3VuZCAtIHJlY29yZHNQZXJQYWdlO1xuICAgICAgICAgICAgICAgIHBhZ2luYXRpb24ubmV4dFBhZ2UgPSBwYWdlTnVtYmVyKys7XG4gICAgICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgICAgICBwYWdpbmF0aW9uLnVwcGVyQm91bmQgPSByZWNvcmRzUGVyUGFnZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBwYWdpbmF0aW9uO1xuICAgIH1cblxuICAgIHB1YmxpYyBnZXRSZXBvcnREYXRhKHNlc3Npb25JZDogc3RyaW5nLCBzdGFydERhdGU6IGFueSwgZW5kRGF0ZTogYW55KTogT1JBQ0xFX1NFUlZJQ0VfQ0xPVUQuSUV4dGVuc2lvblByb21pc2U8YW55PiB7XG4gICAgICAgIHZhciBwcm9taXNlT2JqID0gIG5ldyBFeHRlbnNpb25Qcm9taXNlKChyZXNvbHZlLHJlamVjdCkgPT4ge1xuICAgICAgICAgIHRoaXMucmVzb2x2ZVJlZiA9IHJlc29sdmU7XG4gICAgICAgICAgdGhpcy5yZWplY3RSZWYgPSByZWplY3Q7XG4gICAgICAgIH0pO1xuICAgICAgICBcbiAgICAgICAgdmFyIHN0YXJ0RGF0ZVRpbWU6IERhdGU7XG4gICAgICAgIHZhciBlbmREYXRlVGltZTogRGF0ZTtcblxuICAgICAgICBpZihzdGFydERhdGUpe1xuICAgICAgICAgICAgc3RhcnREYXRlVGltZSA9IG5ldyBEYXRlKHN0YXJ0RGF0ZSk7XG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgc3RhcnREYXRlVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICBzdGFydERhdGVUaW1lLnNldEhvdXJzKHN0YXJ0RGF0ZVRpbWUuZ2V0SG91cnMoKSAtIDgpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYoZW5kRGF0ZSl7XG4gICAgICAgICAgICBlbmREYXRlVGltZSA9IG5ldyBEYXRlKGVuZERhdGUpO1xuICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgIGVuZERhdGVUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuZmV0Y2hSZXBvcnREYXRhKHRoaXMuc2VydmVyVVJJLCB0aGlzLnNlc3Npb25JZCwgc3RhcnREYXRlVGltZS50b0lTT1N0cmluZygpLCBlbmREYXRlVGltZS50b0lTT1N0cmluZygpKTtcbiAgICAgICAgcmV0dXJuIHByb21pc2VPYmo7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBmZXRjaFJlcG9ydERhdGEoc2VydmVyVXJpOiBzdHJpbmcsIHNlc3Npb25JZDogc3RyaW5nLCBzdGFydERhdGU6IHN0cmluZywgZW5kRGF0ZTogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgKyBDdGlNZXNzYWdlcy5NRVNTQUdFX0dFVF9BR0VOVF9EQVRBKTtcbiAgICAgICAgdmFyIGFwaUdldFdvcmtlcnM6IHN0cmluZyA9ICdodHRwczovL3Rhc2tyb3V0ZXIudHdpbGlvLmNvbS92MS9Xb3Jrc3BhY2VzL3tXT1JLU1BBQ0VfU0lEfS9Xb3JrZXJzJztcbiAgICAgICAgJC5hamF4KHtcbiAgICAgICAgICAgICAgICB0eXBlOiBcIlBPU1RcIixcbiAgICAgICAgICAgICAgICB1cmw6IHNlcnZlclVyaSxcbiAgICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgICAgIHNlc3Npb25faWQ6IHNlc3Npb25JZCxcbiAgICAgICAgICAgICAgICAgICAgdXJpOiBhcGlHZXRXb3JrZXJzXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5kb25lKCh3b3JrZXJzUmVzdWx0OiBzdHJpbmcpID0+IHtcbiAgICAgICAgICAgICAgICB2YXIgYWxsV29ya2VyRGF0YTogYW55ID0gSlNPTi5wYXJzZSh3b3JrZXJzUmVzdWx0KTtcbiAgICAgICAgICAgICAgICBpZihhbGxXb3JrZXJEYXRhICYmIGFsbFdvcmtlckRhdGEud29ya2VycyAmJiBhbGxXb3JrZXJEYXRhLndvcmtlcnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMud29ya2VyQ291bnQgPSBhbGxXb3JrZXJEYXRhLndvcmtlcnMubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmZldGNoV29ya2VyU3RhdGlzdGljcyhhbGxXb3JrZXJEYXRhLndvcmtlcnMsIHNlcnZlclVyaSwgc2Vzc2lvbklkLCBzdGFydERhdGUsIGVuZERhdGUpXG4gICAgICAgICAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgKyBDdGlNZXNzYWdlcy5NRVNTQUdFX05PX0FHRU5UU19GT1VORCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5mYWlsKChtZXNzYWdlOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgICBDdGlMb2dnZXIubG9nRXJyb3JNZXNzYWdlKHRoaXMubG9nUHJlTWVzc2FnZSArXG4gICAgICAgICAgICAgICAgICAgIEN0aU1lc3NhZ2VzLk1FU1NBR0VfQVBQRU5ERVIgKyBDdGlNZXNzYWdlcy5NRVNTQUdFX1JFUE9SVF9FWEVDVVRJT05fRkFJTEVEICsgbWVzc2FnZSk7XG4gICAgICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGZldGNoV29ya2VyU3RhdGlzdGljcyhhbGxXb3JrZXJzOiBhbnlbXSwgc2VydmVyVXJpOiBzdHJpbmcsIHNlc3Npb25JZDogc3RyaW5nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXJ0RGF0ZTogc3RyaW5nLCBlbmREYXRlOiBzdHJpbmcpOiB2b2lkIHtcblxuICAgICAgICB2YXIgd29ya2VyQ291bnQ6IG51bWJlciA9IGFsbFdvcmtlcnMubGVuZ3RoO1xuXG4gICAgICAgIGZvcih2YXIgY291bnQ9IDA7IGNvdW50PHdvcmtlckNvdW50OyBjb3VudCsrKSB7XG4gICAgICAgICAgICB2YXIgd29ya2VyOiBhbnkgPSBhbGxXb3JrZXJzW2NvdW50XTtcbiAgICAgICAgICAgIHRoaXMud29ya2VyRGF0YVt3b3JrZXIuc2lkXSA9IHtuYW1lOiB3b3JrZXIuZnJpZW5kbHlfbmFtZX07XG5cbiAgICAgICAgICAgIHZhciBhcGlXb3JrZXJTdGF0OiBzdHJpbmcgPSAnaHR0cHM6Ly90YXNrcm91dGVyLnR3aWxpby5jb20vdjEvV29ya3NwYWNlcy97V09SS1NQQUNFX1NJRH0vV29ya2Vycy8nK3dvcmtlci5zaWQrJy9TdGF0aXN0aWNzP1N0YXJ0RGF0ZT0nK3N0YXJ0RGF0ZSsnJkVuZERhdGU9JytlbmREYXRlO1xuICAgICAgICAgICAgJC5hamF4KHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJQT1NUXCIsXG4gICAgICAgICAgICAgICAgICAgIHVybDogc2VydmVyVXJpLFxuICAgICAgICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXNzaW9uX2lkOiBzZXNzaW9uSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICB1cmk6IGFwaVdvcmtlclN0YXRcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgLmRvbmUoKHdvcmtlclJlc3VsdDogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHZhciB3b3JrRGV0YWlsOiBhbnkgPSBKU09OLnBhcnNlKHdvcmtlclJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkV29ya0RldGFpbHMod29ya0RldGFpbCk7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAuZmFpbCgoZGF0YTogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkV29ya0RldGFpbHMobnVsbCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgIH1cblxuICAgIHByaXZhdGUgYWRkV29ya0RldGFpbHMod29ya0RldGFpbDogYW55KTogdm9pZCB7XG4gICAgICAgIGlmKHdvcmtEZXRhaWwgJiYgd29ya0RldGFpbC53b3JrZXJfc2lkKXtcbiAgICAgICAgICAgIHRoaXMud29ya2VyRGF0YVt3b3JrRGV0YWlsLndvcmtlcl9zaWRdWyd3b3JrJ10gPSB3b3JrRGV0YWlsO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuY29tcGxldGVkQ291bnQrKztcbiAgICAgICAgaWYodGhpcy5jb21wbGV0ZWRDb3VudCA+PSB0aGlzLndvcmtlckNvdW50KXtcbiAgICAgICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgKyBDdGlNZXNzYWdlcy5NRVNTQUdFX0dFVF9BR0VOVF9EQVRBX0NPTVBMRVRFRCk7XG4gICAgICAgICAgICB0aGlzLnByb2Nlc3NXb3JrZXJEYXRhKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIHByb2Nlc3NXb3JrZXJEYXRhKCk6IHZvaWQge1xuICAgICAgICB2YXIgcmVwb3J0OiBSZXBvcnRSb3dbXSA9IFtdO1xuICAgICAgICB2YXIgcm93Q291bnQ6IG51bWJlciA9IDA7XG4gICAgICAgIEN0aUxvZ2dlci5sb2dJbmZvTWVzc2FnZSh0aGlzLmxvZ1ByZU1lc3NhZ2UgKyBDdGlNZXNzYWdlcy5NRVNTQUdFX1BST0NFU1NJTkdfREFUQSk7XG5cbiAgICAgICAgZm9yKHZhciBrZXkgaW4gdGhpcy53b3JrZXJEYXRhKXtcbiAgICAgICAgICAgIGlmKHRoaXMud29ya2VyRGF0YS5oYXNPd25Qcm9wZXJ0eShrZXkpKXtcbiAgICAgICAgICAgICAgICB2YXIgd29ya0RldGFpbHM6IGFueSA9IHRoaXMud29ya2VyRGF0YVtrZXldO1xuICAgICAgICAgICAgICAgIHZhciByZXBvcnRSb3c6IFJlcG9ydFJvdyA9IG5ldyBSZXBvcnRSb3coKTtcbiAgICAgICAgICAgICAgICByZXBvcnRbcm93Q291bnRdID0gcmVwb3J0Um93O1xuICAgICAgICAgICAgICAgIHJlcG9ydFJvdy5hZ2VudE5hbWUgPSB3b3JrRGV0YWlscy5uYW1lLnN1YnN0cmluZyh3b3JrRGV0YWlscy5uYW1lLmxhc3RJbmRleE9mKCdfJykrMSwgd29ya0RldGFpbHMubmFtZS5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIHJvd0NvdW50Kys7XG4gICAgICAgICAgICAgICAgaWYod29ya0RldGFpbHMud29yayAmJiB3b3JrRGV0YWlscy53b3JrLmN1bXVsYXRpdmUpe1xuICAgICAgICAgICAgICAgICAgICB2YXIgc3RhdGlzdGljczogYW55ID0gd29ya0RldGFpbHMud29yay5jdW11bGF0aXZlO1xuICAgICAgICAgICAgICAgICAgICByZXBvcnRSb3cucmVzZXJ2YXRpb25BY2NlcHRlZCA9IHN0YXRpc3RpY3MucmVzZXJ2YXRpb25zX2FjY2VwdGVkO1xuICAgICAgICAgICAgICAgICAgICByZXBvcnRSb3cucmVzZXJ2YXRpb25DYW5jZWxsZWQgPSBzdGF0aXN0aWNzLnJlc2VydmF0aW9uc19jYW5jZWxlZDtcbiAgICAgICAgICAgICAgICAgICAgcmVwb3J0Um93LnJlc2VydmF0aW9uQ3JlYXRlZCA9IHN0YXRpc3RpY3MucmVzZXJ2YXRpb25zX2NyZWF0ZWQ7XG4gICAgICAgICAgICAgICAgICAgIHJlcG9ydFJvdy5yZXNlcnZhdGlvblJlamVjdGVkID0gc3RhdGlzdGljcy5yZXNlcnZhdGlvbnNfcmVqZWN0ZWQ7XG4gICAgICAgICAgICAgICAgICAgIHJlcG9ydFJvdy5yZXNlcnZhdGlvblRpbWVkT3V0ID0gc3RhdGlzdGljcy5yZXNlcnZhdGlvbnNfdGltZWRfb3V0O1xuXG4gICAgICAgICAgICAgICAgICAgIHZhciBhY3Rpdml0eUR1cmF0aW9uczogYW55W10gPSBzdGF0aXN0aWNzLmFjdGl2aXR5X2R1cmF0aW9ucztcbiAgICAgICAgICAgICAgICAgICAgaWYoYWN0aXZpdHlEdXJhdGlvbnMgJiYgYWN0aXZpdHlEdXJhdGlvbnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IodmFyIGluZGV4IGluIGFjdGl2aXR5RHVyYXRpb25zKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZihhY3Rpdml0eUR1cmF0aW9ucy5oYXNPd25Qcm9wZXJ0eShpbmRleCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgYWN0aXZpdHlEYXRhOiBhbnkgPSBhY3Rpdml0eUR1cmF0aW9uc1tpbmRleF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBkdXJhdGlvbjogc3RyaW5nID0gKGFjdGl2aXR5RGF0YS50b3RhbC82MCkudG9GaXhlZCgyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoKGFjdGl2aXR5RGF0YS5mcmllbmRseV9uYW1lKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgJ05vdCBBdmFpbGFibGUnOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcG9ydFJvdy5vZmZsaW5lRHVyYXRpb24gPSBkdXJhdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgJ0J1c3knOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcG9ydFJvdy5idXN5RHVyYXRpb24gPSBkdXJhdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgJ1Jlc2VydmVkJzpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXBvcnRSb3cucmVzZXJ2ZWREdXJhdGlvbiA9IGR1cmF0aW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAnUmVhZHknOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcG9ydFJvdy5yZWFkeUR1cmF0aW9uID0gZHVyYXRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMucmVzb2x2ZVJlZihyZXBvcnQpO1xuICAgICAgICB0aGlzLndvcmtlckNvdW50ID0gbnVsbDtcbiAgICAgICAgdGhpcy5jb21wbGV0ZWRDb3VudCA9IDA7XG4gICAgICAgIHRoaXMud29ya2VyRGF0YSA9IHt9O1xuICAgICAgICBDdGlMb2dnZXIubG9nSW5mb01lc3NhZ2UodGhpcy5sb2dQcmVNZXNzYWdlICsgQ3RpTWVzc2FnZXMuTUVTU0FHRV9QUk9DRVNTSU5HX0RBVEFfQ09NUExFVEVEKTtcblxuICAgIH1cblxufVxubmV3IEN0aVJlcG9ydGluZ0FkZGluKCkucmVnaXN0ZXJDdGlSZXBvcnRpbmdBZGluKCk7XG4iXX0=