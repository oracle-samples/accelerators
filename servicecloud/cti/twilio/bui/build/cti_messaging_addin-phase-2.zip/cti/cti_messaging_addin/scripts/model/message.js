define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Message = void 0;
    var Message = (function () {
        function Message() {
        }
        return Message;
    }());
    exports.Message = Message;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIm1lc3NhZ2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztJQVFBO1FBQUE7UUFLQSxDQUFDO1FBQUQsY0FBQztJQUFELENBQUMsQUFMRCxJQUtDO0lBTFksMEJBQU8iLCJzb3VyY2VzQ29udGVudCI6WyIvKiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAkQUNDRUxFUkFUT1JfSEVBREVSX1BMQUNFX0hPTERFUiRcbiAqICBTSEExOiAkSWQ6IDc5NTMyNDg5ZmQ5MWQ0M2NlZjMzMTBhZjJiMzM0NGIyYzc5YTY2ZTggJFxuICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgRmlsZTogJEFDQ0VMRVJBVE9SX0hFQURFUl9GSUxFX05BTUVfUExBQ0VfSE9MREVSJFxuICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqICovXG5cbmltcG9ydCB7Q29udGFjdH0gZnJvbSBcIi4vY29udGFjdFwiO1xuZXhwb3J0IGNsYXNzIE1lc3NhZ2Uge1xuICAgIGtleTogc3RyaW5nO1xuICAgIG1lc3NhZ2U6IHN0cmluZztcbiAgICBjb250YWN0OiBDb250YWN0O1xuICAgIGluY2lkZW50V29ya3NwYWNlOiBhbnk7XG59Il19