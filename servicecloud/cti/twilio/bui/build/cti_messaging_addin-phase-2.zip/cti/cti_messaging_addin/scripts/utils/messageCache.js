define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.MessageCache = void 0;
    var MessageCache = exports.MessageCache = (function () {
        function MessageCache() {
        }
        MessageCache.get = function (key) {
            return MessageCache.messages[key];
        };
        MessageCache.put = function (key, message) {
            MessageCache.messages[key] = message;
            MessageCache.cacheSize++;
        };
        MessageCache.remove = function (key) {
            if (MessageCache.messages[key]) {
                MessageCache.messages[key] = null;
                MessageCache.cacheSize--;
            }
        };
        MessageCache.clearMessage = function (key) {
            if (MessageCache.messages[key]) {
                MessageCache.messages[key].message = '';
            }
        };
        MessageCache.clearCache = function () {
            MessageCache.messages = {};
            MessageCache.cacheSize = 0;
        };
        MessageCache.getCacheSize = function () {
            return MessageCache.cacheSize;
        };
        MessageCache.messages = {};
        MessageCache.cacheSize = 0;
        return MessageCache;
    }());
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZUNhY2hlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibWVzc2FnZUNhY2hlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7SUFZQTtRQUFBO1FBNERBLENBQUM7UUFsRGlCLGdCQUFHLEdBQWpCLFVBQWtCLEdBQVc7WUFDekIsT0FBTyxZQUFZLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3RDLENBQUM7UUFRYSxnQkFBRyxHQUFqQixVQUFrQixHQUFXLEVBQUUsT0FBZ0I7WUFDM0MsWUFBWSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxPQUFPLENBQUM7WUFDckMsWUFBWSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQzdCLENBQUM7UUFPYSxtQkFBTSxHQUFwQixVQUFxQixHQUFXO1lBQzVCLElBQUcsWUFBWSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBQztnQkFDMUIsWUFBWSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUM7Z0JBQ2xDLFlBQVksQ0FBQyxTQUFTLEVBQUUsQ0FBQzthQUM1QjtRQUNMLENBQUM7UUFFYSx5QkFBWSxHQUExQixVQUEyQixHQUFXO1lBQ2xDLElBQUcsWUFBWSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBQztnQkFDMUIsWUFBWSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO2FBQzNDO1FBQ0wsQ0FBQztRQU1hLHVCQUFVLEdBQXhCO1lBQ0ksWUFBWSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7WUFDM0IsWUFBWSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7UUFDL0IsQ0FBQztRQU9hLHlCQUFZLEdBQTFCO1lBQ0ksT0FBTyxZQUFZLENBQUMsU0FBUyxDQUFDO1FBQ2xDLENBQUM7UUExRGMscUJBQVEsR0FBNkIsRUFBRSxDQUFDO1FBQ3hDLHNCQUFTLEdBQVcsQ0FBQyxDQUFDO1FBMER6QyxtQkFBQztLQUFBLEFBNURELElBNERDIiwic291cmNlc0NvbnRlbnQiOlsiLyogKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgJEFDQ0VMRVJBVE9SX0hFQURFUl9QTEFDRV9IT0xERVIkXG4gKiAgU0hBMTogJElkOiAxZGEwZjk1ZGE2NTFkOTEwMzFjMjg3Y2UzZTBkMzY4YTdlOGU3ODY4ICRcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogIEZpbGU6ICRBQ0NFTEVSQVRPUl9IRUFERVJfRklMRV9OQU1FX1BMQUNFX0hPTERFUiRcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xuXG5pbXBvcnQge01lc3NhZ2V9IGZyb20gXCIuLi9tb2RlbC9tZXNzYWdlXCI7XG4vKipcbiAqIFRoaXMgY2xhc3Mga2VlcHMgYWxsIG1lc3NhZ2VzIGZvclxuICogY3VycmVudGx5IG9wZW5lZCB3b3Jrc3BhY2VzXG4gKi9cbmV4cG9ydCBjbGFzcyBNZXNzYWdlQ2FjaGUge1xuICAgIHByaXZhdGUgc3RhdGljIG1lc3NhZ2VzOiB7W2tleTogc3RyaW5nXTogTWVzc2FnZX0gPSB7fTtcbiAgICBwcml2YXRlIHN0YXRpYyBjYWNoZVNpemU6IG51bWJlciA9IDA7XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRoZSBtZXNzYWdlIHdpdGggZ2l2ZW4ga2V5XG4gICAgICpcbiAgICAgKiBAcGFyYW0ga2V5XG4gICAgICogQHJldHVybnMge01lc3NhZ2V9XG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXQoa2V5OiBzdHJpbmcpOiBNZXNzYWdlIHtcbiAgICAgICAgcmV0dXJuIE1lc3NhZ2VDYWNoZS5tZXNzYWdlc1trZXldO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIEFkZCBhIG1lc3NhZ2UgdG8gdGhlIGNhY2hlLCB3aXRoIGdpdmVuIGtleVxuICAgICAqXG4gICAgICogQHBhcmFtIGtleVxuICAgICAqIEBwYXJhbSBtZXNzYWdlXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBwdXQoa2V5OiBzdHJpbmcsIG1lc3NhZ2U6IE1lc3NhZ2UpOiB2b2lkIHtcbiAgICAgICAgTWVzc2FnZUNhY2hlLm1lc3NhZ2VzW2tleV0gPSBtZXNzYWdlO1xuICAgICAgICBNZXNzYWdlQ2FjaGUuY2FjaGVTaXplKys7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogUmVtb3ZlcyAgbWVzc2FnZSB3aXRoIGdpdmVuIGtleVxuICAgICAqXG4gICAgICogQHBhcmFtIGtleVxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgcmVtb3ZlKGtleTogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIGlmKE1lc3NhZ2VDYWNoZS5tZXNzYWdlc1trZXldKXtcbiAgICAgICAgICAgIE1lc3NhZ2VDYWNoZS5tZXNzYWdlc1trZXldID0gbnVsbDtcbiAgICAgICAgICAgIE1lc3NhZ2VDYWNoZS5jYWNoZVNpemUtLTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHB1YmxpYyBzdGF0aWMgY2xlYXJNZXNzYWdlKGtleTogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIGlmKE1lc3NhZ2VDYWNoZS5tZXNzYWdlc1trZXldKXtcbiAgICAgICAgICAgIE1lc3NhZ2VDYWNoZS5tZXNzYWdlc1trZXldLm1lc3NhZ2UgPSAnJztcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENsZWFyIGFsbCBtZXNzYWdlcyBmcm9tIGNhY2hlXG4gICAgICpcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGNsZWFyQ2FjaGUoKTogdm9pZCB7XG4gICAgICAgIE1lc3NhZ2VDYWNoZS5tZXNzYWdlcyA9IHt9O1xuICAgICAgICBNZXNzYWdlQ2FjaGUuY2FjaGVTaXplID0gMDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm4gdGhlIG51bWJlciBvZiBtZXNzYWdlcyBpbiBjYWNoZVxuICAgICAqIFxuICAgICAqIEByZXR1cm5zIHtudW1iZXJ9XG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRDYWNoZVNpemUoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIE1lc3NhZ2VDYWNoZS5jYWNoZVNpemU7XG4gICAgfVxufSJdfQ==