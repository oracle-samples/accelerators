define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.TwilioMessagingAdapter = void 0;
    var TwilioMessagingAdapter = (function () {
        function TwilioMessagingAdapter() {
            this.messageConfiguration = {
                providerName: 'Twilio',
                providerPath: 'cc/CTI'
            };
        }
        TwilioMessagingAdapter.prototype.sendMessage = function (message, profileData) {
            var messageUrl = profileData.interfaceUrl.match(/^[^\/]+:\/\/[^\/]+\//)[0].replace(/^http(?!s)/i, 'https')
                + this.messageConfiguration.providerPath + '/sendSMS';
            var incidentId = null;
            if (message.incidentWorkspace && message.incidentWorkspace.getWorkspaceRecordId() > 0) {
                incidentId = message.incidentWorkspace.getWorkspaceRecordId();
            }
            return $.ajax({
                url: messageUrl,
                type: "POST",
                data: {
                    session_id: profileData.sessionId,
                    message: message.message,
                    number: message.contact.phone,
                    incident: incidentId
                },
                dataType: "JSON"
            });
        };
        TwilioMessagingAdapter.prototype.searchContact = function (phone, cId, sessionId, serverUri) {
            var searchUrl = serverUri.match(/^[^\/]+:\/\/[^\/]+\//)[0].replace(/^http(?!s)/i, 'https')
                + this.messageConfiguration.providerPath + '/searchPhone';
            return $.ajax({
                url: searchUrl,
                type: 'POST',
                data: {
                    phone: phone,
                    session_id: sessionId,
                    id: cId
                }
            });
        };
        return TwilioMessagingAdapter;
    }());
    exports.TwilioMessagingAdapter = TwilioMessagingAdapter;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHdpbGlvTWVzc2FnaW5nQWRhcHRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInR3aWxpb01lc3NhZ2luZ0FkYXB0ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztJQWdCQTtRQUlJO1lBQ0ksSUFBSSxDQUFDLG9CQUFvQixHQUE2QjtnQkFDbEQsWUFBWSxFQUFFLFFBQVE7Z0JBQ3RCLFlBQVksRUFBRSxRQUFRO2FBQ3pCLENBQUM7UUFDTixDQUFDO1FBVU0sNENBQVcsR0FBbEIsVUFBbUIsT0FBZ0IsRUFBRSxXQUF5QjtZQUUxRCxJQUFJLFVBQVUsR0FBRyxXQUFXLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDO2tCQUNwRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsWUFBWSxHQUFDLFVBQVUsQ0FBQztZQUN4RCxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUM7WUFDdEIsSUFBRyxPQUFPLENBQUMsaUJBQWlCLElBQUksT0FBTyxDQUFDLGlCQUFpQixDQUFDLG9CQUFvQixFQUFFLEdBQUcsQ0FBQyxFQUFDO2dCQUNqRixVQUFVLEdBQUcsT0FBTyxDQUFDLGlCQUFpQixDQUFDLG9CQUFvQixFQUFFLENBQUM7YUFDakU7WUFFRixPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ1QsR0FBRyxFQUFFLFVBQVU7Z0JBQ2YsSUFBSSxFQUFFLE1BQU07Z0JBQ1osSUFBSSxFQUFFO29CQUNGLFVBQVUsRUFBRSxXQUFXLENBQUMsU0FBUztvQkFDakMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPO29CQUN4QixNQUFNLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLO29CQUM3QixRQUFRLEVBQUUsVUFBVTtpQkFDdkI7Z0JBQ0QsUUFBUSxFQUFFLE1BQU07YUFDbkIsQ0FBQyxDQUFDO1FBQ1AsQ0FBQztRQVVNLDhDQUFhLEdBQXBCLFVBQXFCLEtBQWEsRUFBRSxHQUFXLEVBQUUsU0FBaUIsRUFBRSxTQUFpQjtZQUNqRixJQUFJLFNBQVMsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUM7a0JBQ3BGLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLEdBQUMsY0FBYyxDQUFDO1lBRTVELE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDVixHQUFHLEVBQUUsU0FBUztnQkFDZCxJQUFJLEVBQUUsTUFBTTtnQkFDWixJQUFJLEVBQUU7b0JBQ0YsS0FBSyxFQUFFLEtBQUs7b0JBQ1osVUFBVSxFQUFFLFNBQVM7b0JBQ3JCLEVBQUUsRUFBRSxHQUFHO2lCQUNWO2FBQ0osQ0FBQyxDQUFDO1FBQ1AsQ0FBQztRQUVMLDZCQUFDO0lBQUQsQ0FBQyxBQWhFRCxJQWdFQztJQWhFWSx3REFBc0IiLCJzb3VyY2VzQ29udGVudCI6WyIvKiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAkQUNDRUxFUkFUT1JfSEVBREVSX1BMQUNFX0hPTERFUiRcbiAqICBTSEExOiAkSWQ6IDdjYjQ2Mjg4ZDFmNjhlNjYwNDlkYWU4NzIyMjkwMzg1ZTNjMjkwMTkgJFxuICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgRmlsZTogJEFDQ0VMRVJBVE9SX0hFQURFUl9GSUxFX05BTUVfUExBQ0VfSE9MREVSJFxuICogKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqICovXG5cbmltcG9ydCB7SUN0aU1lc3NhZ2luZ0FkYXB0ZXJ9IGZyb20gXCIuLi9jb250cmFjdHMvaUN0aU1lc3NhZ2luZ0FkYXB0ZXJcIjtcbmltcG9ydCB7TWVzc2FnZX0gZnJvbSBcIi4uL21vZGVsL21lc3NhZ2VcIjtcbmltcG9ydCB7Q3RpTWVzc2FnZUNvbmZpZ3VyYXRpb259IGZyb20gXCIuLi9tb2RlbC9jdGlNZXNzYWdlQ29uZmlndXJhdGlvblwiO1xuaW1wb3J0IHtBZ2VudFByb2ZpbGV9IGZyb20gXCIuLi9tb2RlbC9hZ2VudFByb2ZpbGVcIjtcblxuLyoqXG4gKiBJbXBsZW1lbnRzIHRoZSBmdW5jdGlvbmFsaXR5IGRlZmluZWQgYnkgSUN0aU1lc3NhZ2luZ0FkYXB0ZXJcbiAqIFxuICovXG5leHBvcnQgY2xhc3MgVHdpbGlvTWVzc2FnaW5nQWRhcHRlciBpbXBsZW1lbnRzIElDdGlNZXNzYWdpbmdBZGFwdGVyIHtcblxuICAgIHByaXZhdGUgbWVzc2FnZUNvbmZpZ3VyYXRpb246IEN0aU1lc3NhZ2VDb25maWd1cmF0aW9uO1xuXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMubWVzc2FnZUNvbmZpZ3VyYXRpb24gPSA8Q3RpTWVzc2FnZUNvbmZpZ3VyYXRpb24+IHtcbiAgICAgICAgICAgIHByb3ZpZGVyTmFtZTogJ1R3aWxpbycsXG4gICAgICAgICAgICBwcm92aWRlclBhdGg6ICdjYy9DVEknXG4gICAgICAgIH07XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVGhpcyBtZXRob2Qgc3VibWl0cyBhIHJlcXVlc3QgdG8gc2VuZCBtZXNzYWdlIGFuZFxuICAgICAqIHJldHVybnMgdGhlIGpxdWVyeSBwcm9taXNlXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbWVzc2FnZVxuICAgICAqIEBwYXJhbSBwcm9maWxlRGF0YVxuICAgICAqIEByZXR1cm5zIHthbnl9XG4gICAgICovXG4gICAgcHVibGljIHNlbmRNZXNzYWdlKG1lc3NhZ2U6IE1lc3NhZ2UsIHByb2ZpbGVEYXRhOiBBZ2VudFByb2ZpbGUpOiBhbnkge1xuXG4gICAgICAgIHZhciBtZXNzYWdlVXJsID0gcHJvZmlsZURhdGEuaW50ZXJmYWNlVXJsLm1hdGNoKC9eW15cXC9dKzpcXC9cXC9bXlxcL10rXFwvLylbMF0ucmVwbGFjZSgvXmh0dHAoPyFzKS9pLCAnaHR0cHMnKVxuICAgICAgICAgICAgKyB0aGlzLm1lc3NhZ2VDb25maWd1cmF0aW9uLnByb3ZpZGVyUGF0aCsnL3NlbmRTTVMnO1xuICAgICAgICB2YXIgaW5jaWRlbnRJZCA9IG51bGw7XG4gICAgICAgIGlmKG1lc3NhZ2UuaW5jaWRlbnRXb3Jrc3BhY2UgJiYgbWVzc2FnZS5pbmNpZGVudFdvcmtzcGFjZS5nZXRXb3Jrc3BhY2VSZWNvcmRJZCgpID4gMCl7XG4gICAgICAgICAgICBpbmNpZGVudElkID0gbWVzc2FnZS5pbmNpZGVudFdvcmtzcGFjZS5nZXRXb3Jrc3BhY2VSZWNvcmRJZCgpO1xuICAgICAgICB9XG5cbiAgICAgICByZXR1cm4gJC5hamF4KHtcbiAgICAgICAgICAgIHVybDogbWVzc2FnZVVybCxcbiAgICAgICAgICAgIHR5cGU6IFwiUE9TVFwiLFxuICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgIHNlc3Npb25faWQ6IHByb2ZpbGVEYXRhLnNlc3Npb25JZCxcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBtZXNzYWdlLm1lc3NhZ2UsXG4gICAgICAgICAgICAgICAgbnVtYmVyOiBtZXNzYWdlLmNvbnRhY3QucGhvbmUsXG4gICAgICAgICAgICAgICAgaW5jaWRlbnQ6IGluY2lkZW50SWRcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBkYXRhVHlwZTogXCJKU09OXCJcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogdGhpcyBmdW5jdGlvbiBzZWFyY2ggZm9yIGEgY29udGFjdFxuICAgICAqXG4gICAgICogQHBhcmFtIGNJZFxuICAgICAqIEBwYXJhbSBzZXNzaW9uSWRcbiAgICAgKiBAcGFyYW0gc2VydmVyVXJpXG4gICAgICogQHBhcmFtIHBob25lXG4gICAgICovXG4gICAgcHVibGljIHNlYXJjaENvbnRhY3QocGhvbmU6IHN0cmluZywgY0lkOiBzdHJpbmcsIHNlc3Npb25JZDogc3RyaW5nLCBzZXJ2ZXJVcmk6IHN0cmluZyk6IGFueSB7XG4gICAgICAgIHZhciBzZWFyY2hVcmwgPSBzZXJ2ZXJVcmkubWF0Y2goL15bXlxcL10rOlxcL1xcL1teXFwvXStcXC8vKVswXS5yZXBsYWNlKC9eaHR0cCg/IXMpL2ksICdodHRwcycpXG4gICAgICAgICAgICArIHRoaXMubWVzc2FnZUNvbmZpZ3VyYXRpb24ucHJvdmlkZXJQYXRoKycvc2VhcmNoUGhvbmUnO1xuXG4gICAgICAgIHJldHVybiAkLmFqYXgoe1xuICAgICAgICAgICAgdXJsOiBzZWFyY2hVcmwsXG4gICAgICAgICAgICB0eXBlOiAnUE9TVCcsXG4gICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgcGhvbmU6IHBob25lLFxuICAgICAgICAgICAgICAgIHNlc3Npb25faWQ6IHNlc3Npb25JZCxcbiAgICAgICAgICAgICAgICBpZDogY0lkXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cblxufSJdfQ==