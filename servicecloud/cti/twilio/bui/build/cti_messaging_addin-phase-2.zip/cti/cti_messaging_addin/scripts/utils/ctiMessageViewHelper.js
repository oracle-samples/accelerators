define(["require", "exports", "jquery"], function (require, exports, $) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CtiMessageViewHelper = void 0;
    var CtiMessageViewHelper = (function () {
        function CtiMessageViewHelper() {
        }
        CtiMessageViewHelper.enableMessagingView = function (message, inputListener, buttonClickHandler) {
            var inputElement = $("#messaging_content");
            $("#messaging_contact_image").attr('src', message.contact.dp);
            $("#messaging_name").html(message.contact.name);
            $('#messaging_contact_number').html(message.contact.phone);
            inputElement.val(message.message);
            inputElement.off().on('change', function (event) {
                inputListener(message.key, event);
            });
            var sendButtonElement = $("#message_send_btn");
            sendButtonElement.off().on('click', function (event) {
                sendButtonElement.attr('class', 'button button-green disabled');
                buttonClickHandler(message.key);
            });
        };
        CtiMessageViewHelper.enableSendButtonControlOnSuccess = function () {
            var sendButtonElement = $("#message_send_btn");
            var inputElement = $("#messaging_content");
            inputElement.val('');
            sendButtonElement.attr('class', 'button button-green');
        };
        CtiMessageViewHelper.enableSendButtonControlOnFailure = function () {
            var sendButtonElement = $("#message_send_btn");
            alert('Unable to send message.');
            sendButtonElement.attr('class', 'button button-green');
        };
        return CtiMessageViewHelper;
    }());
    exports.CtiMessageViewHelper = CtiMessageViewHelper;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3RpTWVzc2FnZVZpZXdIZWxwZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjdGlNZXNzYWdlVmlld0hlbHBlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0lBYUE7UUFBQTtRQTJDQSxDQUFDO1FBbkNpQix3Q0FBbUIsR0FBakMsVUFBa0MsT0FBZ0IsRUFBRSxhQUFrQixFQUFFLGtCQUF1QjtZQUMzRixJQUFJLFlBQVksR0FBUSxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUNoRCxDQUFDLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDOUQsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDaEQsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDM0QsWUFBWSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDbEMsWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsVUFBQyxLQUFVO2dCQUN2QyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN0QyxDQUFDLENBQUMsQ0FBQztZQUNILElBQUksaUJBQWlCLEdBQVEsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFDcEQsaUJBQWlCLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFDLEtBQVU7Z0JBQzNDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsOEJBQThCLENBQUMsQ0FBQztnQkFDaEUsa0JBQWtCLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3BDLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQztRQUthLHFEQUFnQyxHQUE5QztZQUNJLElBQUksaUJBQWlCLEdBQVEsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFDcEQsSUFBSSxZQUFZLEdBQVEsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDaEQsWUFBWSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNyQixpQkFBaUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLHFCQUFxQixDQUFDLENBQUM7UUFDM0QsQ0FBQztRQUthLHFEQUFnQyxHQUE5QztZQUNJLElBQUksaUJBQWlCLEdBQVEsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFDcEQsS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUM7WUFDakMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO1FBQzNELENBQUM7UUFFTCwyQkFBQztJQUFELENBQUMsQUEzQ0QsSUEyQ0M7SUEzQ1ksb0RBQW9CIiwic291cmNlc0NvbnRlbnQiOlsiLyogKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgJEFDQ0VMRVJBVE9SX0hFQURFUl9QTEFDRV9IT0xERVIkXG4gKiAgU0hBMTogJElkOiA3MWFjZmM3ZDEzNzU0YjBmNGYyMmViMzQ0NGU2NzNmYzVjODA5NjA5ICRcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogIEZpbGU6ICRBQ0NFTEVSQVRPUl9IRUFERVJfRklMRV9OQU1FX1BMQUNFX0hPTERFUiRcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xuXG5pbXBvcnQgJCA9IHJlcXVpcmUoJ2pxdWVyeScpO1xuaW1wb3J0IHtNZXNzYWdlfSBmcm9tIFwiLi4vbW9kZWwvbWVzc2FnZVwiO1xuXG4vKipcbiAqIFRoaXMgdXRpbGl0eSBjbGFzcyBpcyB1c2VkIHRvIHVwZGF0ZSB0aGUgVUlcbiAqL1xuZXhwb3J0IGNsYXNzIEN0aU1lc3NhZ2VWaWV3SGVscGVyIHtcbiAgICAvKipcbiAgICAgKiBFbmFibGUgbWVzc2FnaW5nIGZvciBhIHdvcmtzcGFjZVxuICAgICAqXG4gICAgICogQHBhcmFtIG1lc3NhZ2VcbiAgICAgKiBAcGFyYW0gaW5wdXRMaXN0ZW5lclxuICAgICAqIEBwYXJhbSBidXR0b25DbGlja0hhbmRsZXJcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGVuYWJsZU1lc3NhZ2luZ1ZpZXcobWVzc2FnZTogTWVzc2FnZSwgaW5wdXRMaXN0ZW5lcjogYW55LCBidXR0b25DbGlja0hhbmRsZXI6IGFueSk6IHZvaWQge1xuICAgICAgICB2YXIgaW5wdXRFbGVtZW50OiBhbnkgPSAkKFwiI21lc3NhZ2luZ19jb250ZW50XCIpO1xuICAgICAgICAkKFwiI21lc3NhZ2luZ19jb250YWN0X2ltYWdlXCIpLmF0dHIoJ3NyYycsIG1lc3NhZ2UuY29udGFjdC5kcCk7XG4gICAgICAgICQoXCIjbWVzc2FnaW5nX25hbWVcIikuaHRtbChtZXNzYWdlLmNvbnRhY3QubmFtZSk7XG4gICAgICAgICQoJyNtZXNzYWdpbmdfY29udGFjdF9udW1iZXInKS5odG1sKG1lc3NhZ2UuY29udGFjdC5waG9uZSk7XG4gICAgICAgIGlucHV0RWxlbWVudC52YWwobWVzc2FnZS5tZXNzYWdlKTtcbiAgICAgICAgaW5wdXRFbGVtZW50Lm9mZigpLm9uKCdjaGFuZ2UnLCAoZXZlbnQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgaW5wdXRMaXN0ZW5lcihtZXNzYWdlLmtleSwgZXZlbnQpO1xuICAgICAgICB9KTtcbiAgICAgICAgdmFyIHNlbmRCdXR0b25FbGVtZW50OiBhbnkgPSAkKFwiI21lc3NhZ2Vfc2VuZF9idG5cIik7XG4gICAgICAgIHNlbmRCdXR0b25FbGVtZW50Lm9mZigpLm9uKCdjbGljaycsIChldmVudDogYW55KSA9PiB7XG4gICAgICAgICAgICBzZW5kQnV0dG9uRWxlbWVudC5hdHRyKCdjbGFzcycsICdidXR0b24gYnV0dG9uLWdyZWVuIGRpc2FibGVkJyk7XG4gICAgICAgICAgICBidXR0b25DbGlja0hhbmRsZXIobWVzc2FnZS5rZXkpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBDaGFuZ2UgVUkgd2hlbiBzZW5kaW5nIG1lc3NhZ2UgaXMgc3VjY2Vzc1xuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZW5hYmxlU2VuZEJ1dHRvbkNvbnRyb2xPblN1Y2Nlc3MoKTogdm9pZCB7XG4gICAgICAgIHZhciBzZW5kQnV0dG9uRWxlbWVudDogYW55ID0gJChcIiNtZXNzYWdlX3NlbmRfYnRuXCIpO1xuICAgICAgICB2YXIgaW5wdXRFbGVtZW50OiBhbnkgPSAkKFwiI21lc3NhZ2luZ19jb250ZW50XCIpO1xuICAgICAgICBpbnB1dEVsZW1lbnQudmFsKCcnKTtcbiAgICAgICAgc2VuZEJ1dHRvbkVsZW1lbnQuYXR0cignY2xhc3MnLCAnYnV0dG9uIGJ1dHRvbi1ncmVlbicpO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIENoYW5nZSBVSSB3aGVuIHNlbmRpbmcgbWVzc2FnZSBpcyBmYWlsdXJlXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBlbmFibGVTZW5kQnV0dG9uQ29udHJvbE9uRmFpbHVyZSgpOiB2b2lkIHtcbiAgICAgICAgdmFyIHNlbmRCdXR0b25FbGVtZW50OiBhbnkgPSAkKFwiI21lc3NhZ2Vfc2VuZF9idG5cIik7XG4gICAgICAgIGFsZXJ0KCdVbmFibGUgdG8gc2VuZCBtZXNzYWdlLicpO1xuICAgICAgICBzZW5kQnV0dG9uRWxlbWVudC5hdHRyKCdjbGFzcycsICdidXR0b24gYnV0dG9uLWdyZWVuJyk7XG4gICAgfVxuXG59XG4iXX0=