define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CtiFilePathUtil = void 0;
    var CtiFilePathUtil = (function () {
        function CtiFilePathUtil() {
        }
        CtiFilePathUtil.getAbsolutePath = function (addinFilePath) {
            var base = window.location.href;
            var relative = addinFilePath;
            var stack = base.split("/"), parts = relative.split("/");
            stack.pop();
            for (var i = 0; i < parts.length; i++) {
                if (parts[i] == ".")
                    continue;
                if (parts[i] == "..")
                    stack.pop();
                else
                    stack.push(parts[i]);
            }
            return stack.join("/");
        };
        return CtiFilePathUtil;
    }());
    exports.CtiFilePathUtil = CtiFilePathUtil;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3RpRmlsZVBhdGhVdGlsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY3RpRmlsZVBhdGhVdGlsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7SUFPQTtRQUFBO1FBd0JBLENBQUM7UUFoQmlCLCtCQUFlLEdBQTdCLFVBQThCLGFBQXFCO1lBQy9DLElBQUksSUFBSSxHQUFXLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO1lBQ3hDLElBQUksUUFBUSxHQUFXLGFBQWEsQ0FBQztZQUNyQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUN2QixLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNoQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDWixLQUFLLElBQUksQ0FBQyxHQUFDLENBQUMsRUFBRSxDQUFDLEdBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDL0IsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRztvQkFDZixTQUFTO2dCQUNiLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUk7b0JBQ2hCLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQzs7b0JBRVosS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM1QjtZQUNELE9BQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMzQixDQUFDO1FBQ0wsc0JBQUM7SUFBRCxDQUFDLEFBeEJELElBd0JDO0lBeEJZLDBDQUFlIiwic291cmNlc0NvbnRlbnQiOlsiLyogKiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgJEFDQ0VMRVJBVE9SX0hFQURFUl9QTEFDRV9IT0xERVIkXG4gKiAgU0hBMTogJElkOiBmZTMyOGFmZTU2YTQ1MmZiMTI5ZWVlOGNjOTdmODRjNjczMWI4Yjc1ICRcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogIEZpbGU6ICRBQ0NFTEVSQVRPUl9IRUFERVJfRklMRV9OQU1FX1BMQUNFX0hPTERFUiRcbiAqICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xuXG5leHBvcnQgY2xhc3MgQ3RpRmlsZVBhdGhVdGlsIHtcbiAgICAvKipcbiAgICAgKiBUaGlzIGZ1bmN0aW9uIGNhbGN1bGF0ZXMgdGhlIGFic29sdXRlIGZpbGUgcGF0aFxuICAgICAqIGZvciB0aGUgYWRkaW4gaHRtbFxuICAgICAqXG4gICAgICogQHJldHVybnMge3N0cmluZ31cbiAgICAgKi9cblxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0QWJzb2x1dGVQYXRoKGFkZGluRmlsZVBhdGg6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgICAgIHZhciBiYXNlOiBzdHJpbmcgPSB3aW5kb3cubG9jYXRpb24uaHJlZjtcbiAgICAgICAgdmFyIHJlbGF0aXZlOiBzdHJpbmcgPSBhZGRpbkZpbGVQYXRoO1xuICAgICAgICB2YXIgc3RhY2sgPSBiYXNlLnNwbGl0KFwiL1wiKSxcbiAgICAgICAgICAgIHBhcnRzID0gcmVsYXRpdmUuc3BsaXQoXCIvXCIpO1xuICAgICAgICBzdGFjay5wb3AoKTtcbiAgICAgICAgZm9yICh2YXIgaT0wOyBpPHBhcnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAocGFydHNbaV0gPT0gXCIuXCIpXG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICBpZiAocGFydHNbaV0gPT0gXCIuLlwiKVxuICAgICAgICAgICAgICAgIHN0YWNrLnBvcCgpO1xuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgIHN0YWNrLnB1c2gocGFydHNbaV0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzdGFjay5qb2luKFwiL1wiKTtcbiAgICB9XG59Il19